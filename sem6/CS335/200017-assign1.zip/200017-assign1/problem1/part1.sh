#!/bin/bash

flex++ part1.l
g++ lex.yy.cc -o assign1

./assign1 $2 < $1 | awk NF

rm assign1 lex.yy.cc
