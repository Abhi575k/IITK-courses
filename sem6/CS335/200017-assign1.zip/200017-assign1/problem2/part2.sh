#!/bin/bash

flex++ part2.l
g++ lex.yy.cc -o assign2

./assign2 $2 < $1 | awk NF

rm assign2 lex.yy.cc
