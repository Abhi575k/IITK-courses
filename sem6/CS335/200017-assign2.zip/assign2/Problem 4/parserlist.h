#include<stdio.h>
#include<stdlib.h>

struct node
{
    int level;
    char* s;
    struct node *next;
};

struct node *head, *tail;

void instPrint(char* s, int level){
    for(int i=0;i<level;i++) printf("\t");
    printf("%s", s);
    return;
}

void insertNode(char* s, int level){
    struct node *cur;
    if(head==NULL){
        head=(struct node*)malloc(sizeof(struct node));
        cur=head;
        tail=cur;
    }else{
        cur=(struct node*)malloc(sizeof(struct node));
        tail->next=cur;
        tail=cur;
    }
    cur->s=s;
    cur->level=level;
    return;
}
void printList(struct node* cur){
    if(cur==NULL) return;
    for(int i=0;i<cur->level;i++) printf("\t");
    printf("%s", cur->s);
    printList(cur->next);
    return;
}