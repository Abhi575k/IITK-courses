# Compiler Assignment

Current command line arguements:

1) -i or --input: requires input file name just after the option
2) -o or --output: requires output file name just after the option, output file for 3ac
3) -a or --ast: optional, output file for DOT file for ast
4) -v or --verbose: verbose

## Updates(31 March):

1) Added better implementation of command line arguements
2) Only leaf nodes contain line number
3) Added "id" attribute for each unique production rule
4) If the symbol table is associated to a function definition, it stores the parameters in a vector to maintain sequence.
5) Tokens are assigned a synthesised attribute: datatype(incomplete)

## Updates(1 April)

1) Functions can only return, at max, 1D array

## Updates(13 April)

1) Typechecking still not implemented
2) Does not deal with multiple functions/variables declared with same name in different classes.
3) Assuming variables are only initialized inside functions.