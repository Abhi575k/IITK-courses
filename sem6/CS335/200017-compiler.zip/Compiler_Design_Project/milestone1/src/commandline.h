#include <stdio.h>
#include <string.h>

int checkHelp(char* str){
    if(strcmp(str,"-help")==0||strcmp(str,"-h")==0) return 1;
    return 0;
}

int checkInput(char* str){
    if(strcmp(str,"-i")==0||strcmp(str,"-input")==0) return 1;
    return 0;
}

int checkOutput(char* str){
    if(strcmp(str,"-o")==0||strcmp(str,"-output")==0) return 1;
    return 0;
}

int checkVerbose(char* str){
    if(strcmp(str,"-v")==0||strcmp(str,"-verbose")==0) return 1;
    return 0;
}

void printError(){
    printf("Error\n");
    return;
}


void printUsage(){
    printf("Usage: ./run -i <input file> -o <output file>\n");
    return;
}