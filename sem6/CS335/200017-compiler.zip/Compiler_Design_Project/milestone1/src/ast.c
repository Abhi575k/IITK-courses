#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "ast.h"
#include "commandline.h"
#include <string.h>

int opt;
int cnt;

int key_count, sep_count, opt_count, id_count, lit_count;

struct ast *newast0(char *nodetype, struct ast* n0)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    return a;
}

struct ast *newast1(char *nodetype, struct ast* n0, struct ast *n1)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    return a;
}

struct ast *newast2(char *nodetype, struct ast* n0, struct ast *n1, struct ast *n2)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    a->n2 = n2;
    return a;
}

struct ast *newast3(char *nodetype, struct ast* n0, struct ast *n1, struct ast *n2, struct ast *n3)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    a->n2 = n2;
    a->n3 = n3;
    return a;
}

struct ast *newast4(char *nodetype, struct ast* n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    a->n2 = n2;
    a->n3 = n3;
    a->n4 = n4;
    return a;
}

struct ast *newast5(char *nodetype, struct ast* n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    a->n2 = n2;
    a->n3 = n3;
    a->n4 = n4;
    a->n5 = n5;
    return a;
}

struct ast *newast6(char *nodetype, struct ast* n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5, struct ast *n6)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    a->n2 = n2;
    a->n3 = n3;
    a->n4 = n4;
    a->n5 = n5;
    a->n6 = n6;
    return a;
}

struct ast *newast7(char *nodetype, struct ast* n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5, struct ast *n6, struct ast *n7)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    a->n2 = n2;
    a->n3 = n3;
    a->n4 = n4;
    a->n5 = n5;
    a->n6 = n6;
    a->n7 = n7;
    return a;
}

struct ast *newast8(char *nodetype, struct ast* n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5, struct ast *n6, struct ast *n7, struct ast *n8)
{
    struct ast *a = newnum(nodetype);
    a->n0 = n0;
    a->n1 = n1;
    a->n2 = n2;
    a->n3 = n3;
    a->n4 = n4;
    a->n5 = n5;
    a->n6 = n6;
    a->n7 = n7;
    a->n8 = n8;
    return a;
}

struct ast *newnum(char* d)
{
    struct ast *a = malloc(sizeof(struct ast));
    if (!a) {
        yyerror("out of space");
        exit(0);
    }
    strcpy(a->nodetype, d);
    a->node_num = cnt;
    cnt++;
    a->n0 = NULL;
    a->n1 = NULL;
    a->n2 = NULL;
    a->n3 = NULL;
    a->n4 = NULL;
    a->n5 = NULL;
    a->n6 = NULL;
    a->n7 = NULL;
    a->n8 = NULL;
    return a;
}

void printtree(struct ast *a)
{
    
    if(a==NULL) return;

    fprintf(yyout, "\tn%d [label=\"%s\"]\n", a->node_num, a->nodetype);
    
    if(a->n0 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n0->node_num);
    if(a->n1 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n1->node_num);
    if(a->n2 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n2->node_num);
    if(a->n3 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n3->node_num);
    if(a->n4 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n4->node_num);
    if(a->n5 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n5->node_num);
    if(a->n6 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n6->node_num);  
    if(a->n7 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n7->node_num);
    if(a->n8 != NULL) fprintf(yyout, "\tn%d -> n%d;\n", a->node_num, a->n8->node_num);

    printtree(a->n0);
    printtree(a->n1);
    printtree(a->n2);
    printtree(a->n3);
    printtree(a->n4);
    printtree(a->n5);
    printtree(a->n6);
    printtree(a->n7);
    printtree(a->n8);
    return;
}

void printTerminal(){
    printf("Abstract Syntax Tree Generated Successfully\n");
    printf("Total number of nodes: %d\n", cnt);
    printf("Keywords: %d\n", key_count);
    printf("Operators: %d\n", opt_count);
    printf("Identifiers: %d\n", id_count);
    printf("Separators: %d\n", sep_count);
    printf("Literal: %d\n", lit_count);

    return;
}

void treefree(struct ast *a)
{
    if(a->n0 != NULL) treefree(a->n0);
    if(a->n1 != NULL) treefree(a->n1);
    if(a->n2 != NULL) treefree(a->n2);
    if(a->n3 != NULL) treefree(a->n3);
    if(a->n4 != NULL) treefree(a->n4);
    if(a->n5 != NULL) treefree(a->n5);
    if(a->n6 != NULL) treefree(a->n6);
    if(a->n7 != NULL) treefree(a->n7);
    if(a->n8 != NULL) treefree(a->n8);
    free(a);
    return;
}

void yyerror(char *s){
    fprintf(stderr, "error: %s on line %d\n", s, yylineno);
    return;
}

int main(int argc, char **argv){
    cnt = 0;
    key_count = 0, opt_count = 0, id_count = 0, sep_count = 0, lit_count = 0;
    if (argc == 2)
    {
        if (checkHelp(argv[1])){
            printUsage();
        }else{
            printError();
            printUsage();
        }
    }else if (argc == 5){
        if ((checkInput(argv[1]) && checkOutput(argv[3])) || (checkInput(argv[3]) && checkOutput(argv[1]))){
            yyin = fopen(argv[2], "r");
            yyout = fopen(argv[4], "w");
            if (yyin == NULL || yyout == NULL){
                printError();
                printUsage();
                return 0;
            }
            opt = 0;
            fprintf(yyout, "digraph G{\n");
            yyparse();
            fprintf(yyout, "}");
            fclose(yyin);
            fclose(yyout);
        }else{
            printError();
            printUsage();
        }
    }else if (argc == 6){
        if (checkInput(argv[1]) && checkOutput(argv[3]) && checkVerbose(argv[5])){
            yyin = fopen(argv[2], "r");
            yyout = fopen(argv[4], "w");
            if (yyin == NULL || yyout == NULL){
                printError();
                printUsage();
                return 0;
            }
            opt = 1;
            fprintf(yyout, "digraph G{\n");
            yyparse();
            fprintf(yyout, "}");
            fclose(yyin);
            fclose(yyout);
            printTerminal();
        }else if (checkInput(argv[3]) && checkOutput(argv[1]) && checkVerbose(argv[5])){
            yyin = fopen(argv[4], "r");
            yyout = fopen(argv[2], "w");
            if (yyin == NULL || yyout == NULL){
                printError();
                printUsage();
                return 0;
            }
            opt = 1;
            fprintf(yyout, "digraph G{\n");
            yyparse();
            fprintf(yyout, "}");
            fclose(yyin);
            fclose(yyout);
            printTerminal();
        }else{
            printError();
            printUsage();
        }
    }else{
        printError();
        printUsage();
    }
    return 0;
}