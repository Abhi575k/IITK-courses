extern int yylineno;

extern FILE *yyin;
extern FILE *yyout;

extern int yylex();
extern int yyparse();


void yyerror(char* s);

extern int key_count, sep_count, opt_count, id_count, lit_count;

struct ast {
    int node_num;
    char nodetype[30];
    struct ast *n0, *n1, *n2, *n3, *n4, *n5, *n6, *n7, *n8;
};

struct ast *newnum(char* data);
struct ast *newast0(char* nodetype, struct ast *n0);
struct ast *newast1(char *nodetype, struct ast *n0, struct ast *n1);
struct ast *newast2(char *nodetype, struct ast *n0, struct ast *n1, struct ast *n2);
struct ast *newast3(char *nodetype, struct ast *n0, struct ast *n1, struct ast *n2, struct ast *n3);
struct ast *newast4(char *nodetype, struct ast *n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4);
struct ast *newast5(char *nodetype, struct ast *n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5);
struct ast *newast6(char *nodetype, struct ast *n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5, struct ast *n6);
struct ast *newast7(char *nodetype, struct ast *n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5, struct ast *n6, struct ast *n7);
struct ast *newast8(char *nodetype, struct ast *n0, struct ast *n1, struct ast *n2, struct ast *n3, struct ast *n4, struct ast *n5, struct ast *n6, struct ast *n7, struct ast *n8);


void printtree(struct ast *head);

void printTerminal();

void treefree(struct ast *head);