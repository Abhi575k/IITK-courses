public class Main {
  public static void main(int args) {
    // Declare and initialize an array of integers
    int nums[] = {4, 8, 2, 10, 5, 1};

    // Find the minimum value in the array
    int min = nums[0];
    for (int i = 1; i < nums.length; i++) {
      if (nums[i] < min) {
        min = nums[i];
      }
    }
    System.out.println(min);

    // Find the maximum value in the array
    int max = nums[0];
    for (int i = 1; i < nums.length; i++) {
      if (nums[i] > max) {
        max = nums[i];
      }
    }
    System.out.println(max);

    // Calculate the sum and average of the array
    int sum = 0;
    for (int i = 0; i < nums.length; i++) {
      sum += nums[i];
    }
    int average =  (int)a + b;
    System.out.println(sum);
    System.out.println(average);
  }
}