import java.util.Scanner;

public class PersonalizedMessage {
    public static void main(int arg) {
        input =  Scanner(System.in);
        int name = input.nextLine();

        int age = input.nextInt();

        if (age < 0 || age > 150) {
            System.out.println(0);
        } else if (age <= 12) {
            System.out.println(name);
        } else if (age <= 19) {
            System.out.println(name);
        } else if (age <= 40) {
            System.out.println(name);
        } else if (age <= 60) {
            System.out.println(name);
        } else {
            System.out.println(name);
        }

        input.close();
    }
}