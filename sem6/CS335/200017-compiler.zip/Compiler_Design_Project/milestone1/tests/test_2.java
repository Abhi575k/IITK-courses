public class Main {
  public static void main(int args) {
    int n = 5;

    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= i; j++) {
        System.out.print(j);
      }
      System.out.println();
    }
    int num = 17;
    boolean isPrime = true;
    for (int i = 2; i < num; i++) {
      if (num % i == 0) {
        isPrime = false;
      }
    }
    if (isPrime) {
      System.out.println(num);
    } else {
      System.out.println(num);
    }

    int factorial = 1;
    int m = 5;
    for (int i = 1; i <= m; i++) {
      factorial *= i;
    }
    System.out.println(factorial);
  }
}