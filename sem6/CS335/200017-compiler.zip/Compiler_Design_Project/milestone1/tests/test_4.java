import java.util.Scanner;

public class Main {
  public static void main(int args[]) {
    input = 5;

    System.out.print();
    int num = input.nextInt();

    int fact = 1;

    if (num < 0) {
      System.out.println();
      return;
    }

    for (int i = 1; i <= num; i++) {
      fact *= i;
    }

    System.out.println();

    input.close();
  }
}