import java.util.Scanner;
import java.util.*;

public class Main {
  public void main(int args[5]) {
    // Declare and initialize variables
    int num1 = 5;
    int num2 = 10;
    double pi = 3.14159;
    boolean isTrue = true;

    // Use loops to print numbers
    for (int i = 1; i <= 10; i++) {
      System.out.print(i);
    }
    System.out.println();

    int j = 1;
    while (j <= 10) {
      System.out.print(j);
      j++;
    }
    System.out.println();

    int k = 1;

    System.out.println();

    // Use conditional statements to print messages
    if (num1 < num2) {
      System.out.println(num1 );
    } else if (num1 > num2) {
      System.out.println(num1 );
    } else {
      System.out.println(num1);
    }

    // Use switch statement to print message
    int dayOfWeek = 3;

    // Use math library to calculate square root
    double num3 = 25.0;
    double sqrt = Math.sqrt(num3);
    System.out.println( num3);

    // Use string methods to manipulate strings
    System.out.println( message.length());
    System.out.println( message.toUpperCase());
    System.out.println( message.indexOf());
  }
}