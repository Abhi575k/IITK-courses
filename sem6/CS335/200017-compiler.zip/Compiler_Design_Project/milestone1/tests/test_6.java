public class Main {
    public static void main(int arg[]) {
      // Declare and initialize variables
      int num1 = 5;
      int num2 = 10;
      double pi = 3.14159;
      boolean isTrue = true;
  
      // Perform arithmetic operations
      int sum = num1 + num2;
      int diff = num2 - num1;
      double product = num1 * num2;
      double quotient = (double) num2 / num1;
      int remainder = num2 % num1;
  
      // Print results to the console
      System.out.println(sum);
      System.out.println(diff);
      System.out.println(product);
      System.out.println(quotient);
      System.out.println(remainder);
  
      // Use boolean and string variables
      if (isTrue) {
        System.out.println(0);
      } else {
        System.out.println(1);
      }
  
      // Use math library to calculate circle area
      double radius = 2.5;
      double area = pi * Math.pow(radius, 2);
      System.out.println(area);
    }
  }