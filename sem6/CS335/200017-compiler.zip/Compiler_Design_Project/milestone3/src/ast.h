#ifndef AST_H
#define AST_H

#include <bits/stdc++.h>

using namespace std;

extern int yylineno;

extern FILE *yyin;
extern FILE *yyout;

extern int yylex();
extern int yyparse();

extern void yyerror(char *s);
extern void yyerror(char *s, int lineno);

extern int cnt;
extern int key_count, sep_count, opt_count, id_count, lit_count;

class ast
{
public:
    int num;
    string label;
    int lineno;
    int id;
    string datatype;
    vector<ast *> children;

    int dims;
    bool is_variable;
    bool is_function_param;
    bool is_array;

    ast(char *label, int lineno, int id);
    ast(char *label, vector<ast *> children, int id);

    ast(char *label, vector<ast *> children, int id, char* datatype);
    ast(char *label, vector<ast *> children, int id, string datatype);

    void printtree();

    void sendTypes();
};

void printTerminal();

#endif