#ifndef GLOBALVARIABLES_H
#define GLOBALVARIABLES_H

#include "3ac.h"

extern int cnt;
extern int key_count, sep_count, opt_count, id_count, lit_count;

extern ast *parse_tree_root;
extern ast *ast_root;
extern SymbolTable *symbol_table_root;
extern threeAC *tac;

extern FILE *out;

extern map<string, string> var_list;

extern vector<threeAC *> threeACList;

#endif