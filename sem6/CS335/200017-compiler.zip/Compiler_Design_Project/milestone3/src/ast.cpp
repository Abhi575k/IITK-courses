#include "ast.h"

ast::ast(char* label, int lineno, int id){
    this->label = string(label);
    this->num = cnt;
    cnt++;
    this->lineno = lineno;
    this->id = id;
    this->datatype = "void";
    this->dims = 0;
    this->is_variable = true;
    this->is_function_param = false;
}

ast::ast(char* label, vector<ast*> children, int id){
    this->label = string(label);
    this->num = cnt;
    cnt++;
    for(int i=0;i<children.size();i++){
        if(children[i]->label!="NULL") this->children.push_back(children[i]);
    }
    this->lineno = 0;
    this->id = id;
    this->datatype = "void";
    this->dims = 0;
    this->is_variable = true;
    this->is_function_param = false;
}

ast::ast(char* label, vector<ast*> children, int id, char* datatype){
    this->label = string(label);
    this->num = cnt;
    cnt++;
    for(int i=0;i<children.size();i++){
        if(children[i]->label!="NULL") this->children.push_back(children[i]);
    }
    this->lineno = 0;
    this->id = id;
    this->datatype = string(datatype);
    this->dims = 0;
    this->is_variable = true;
    this->is_function_param = false;
}

ast::ast(char* label, vector<ast*> children, int id, string datatype){
    this->label = string(label);
    this->num = cnt;
    cnt++;
    for(int i=0;i<children.size();i++){
        if(children[i]->label!="NULL") this->children.push_back(children[i]);
    }
    this->lineno = 0;
    this->id = id;
    this->datatype = datatype;
    this->dims = 0;
    this->is_variable = true;
    this->is_function_param = false;
}

void ast::printtree(){
    if(label=="NULL") return;
    fprintf(yyout, "\tn%d [label=\"%s, %d\n%s\"]\n", num, label.c_str(), id, datatype.c_str());
    for(int i=0;i<children.size();i++){
        fprintf(yyout, "\tn%d -> n%d;\n", num, children[i]->num);
        children[i]->printtree();
    }
    return;
}

void ast::sendTypes(){
    if(children.size()!=0){
        if(datatype!="void"){
            for(int i=0;i<children.size();i++){
                if(children[i]->datatype=="void"){
                    children[i]->datatype = datatype;
                }
            }
        }
    }
    for(auto u: children){
        u->sendTypes();
    }
}

void printTerminal(){
    printf("\n[VERBOSE]Parse Tree Info:\n\n");
    printf("Total number of nodes: %d\n", cnt);
    printf("Keywords: %d\n", key_count);
    printf("Operators: %d\n", opt_count);
    printf("Identifiers: %d\n", id_count);
    printf("Separators: %d\n", sep_count);
    printf("Literal: %d\n", lit_count);
    return;
}