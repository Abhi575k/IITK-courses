#ifndef TAC_H
#define TAC_H

#include "typecheck.h"

class threeAC{
public:
    string op;
    string arg1;
    string arg2;
    string res;

    string datatype;
    string comment;
    int lineno;
    int id;

    bool is_label;
    bool is_expr;

    string label;

    threeAC *next;

    threeAC();
    void print();
    void append(threeAC *tac);
};

class threeACStack{
public:
    string var_name;
    bool is_useful;
};

threeAC* create3AC(ast *root, int val);

void dumpThreeAC(FILE *out);

#endif