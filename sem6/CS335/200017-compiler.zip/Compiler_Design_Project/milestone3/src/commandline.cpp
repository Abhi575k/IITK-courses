#include "commandline.h"

bool checkArguements(int argc, char* argv[]){
    for(int i=1;i<argc;i++){
        if(strcmp(argv[i],"--help")==0||strcmp(argv[i],"-h")==0) continue;
        else if(strcmp(argv[i],"--ast")==0||strcmp(argv[i],"-a")==0){
            if(i+1>=argc) return false;
            i++;
        }
        else if(strcmp(argv[i],"--input")==0||strcmp(argv[i],"-i")==0){
            if(i+1>=argc) return false;
            i++;
        }
        else if(strcmp(argv[i],"--output")==0||strcmp(argv[i],"-o")==0){
            if(i+1>=argc) return false;
            i++;
        }
        else if(strcmp(argv[i],"--verbose")==0||strcmp(argv[i],"-v")==0) continue;
        else if(strcmp(argv[i],"--sym")==0||strcmp(argv[i],"-s")==0){
            if(i+1>=argc) return false;
            i++;
        }
        else return false;
    }
    return true;
}

bool checkHelp(int argc, char* argv[]){
    for (int i=1;i<argc;i++){
        if (strcmp(argv[i],"--help")==0||strcmp(argv[i],"-h")==0) return 1;
    }
    return 0;
}

bool printAst(int argc, char* argv[], string &ast_output_file){
    for (int i=1;i<argc;i++){
        if ((strcmp(argv[i],"--ast")==0||strcmp(argv[i],"-a")==0)&&(i+1<argc)){
            ast_output_file = argv[i+1];
            return true;
        }
    }
    return false;
}

bool checkInput(int argc, char* argv[], string &input_file){
    for (int i=1;i<argc;i++){
        if ((strcmp(argv[i],"--input")==0||strcmp(argv[i],"-i")==0)&&(i+1<argc)){
            input_file = argv[i+1];
            return true;
        }
    }
    return false;
}

bool checkOutput(int argc, char* argv[], string &output_file){
    for (int i=1;i<argc;i++){
        if ((strcmp(argv[i],"--output")==0||strcmp(argv[i],"-o")==0)&&(i+1<argc)){
            output_file = argv[i+1];
            return true;
        }
    }
    return false;
}

bool checkVerbose(int argc, char* argv[]){
    for (int i=1;i<argc;i++){
        if (strcmp(argv[i],"--verbose")==0||strcmp(argv[i],"-v")==0) return true;
    }
    return false;
}

bool checkSymbolTable(int argc, char* argv[], string &symbol_table_output_folder){
    for (int i=1;i<argc;i++){
        if ((strcmp(argv[i],"--sym")==0||strcmp(argv[i],"-s")==0)&&(i+1<argc)){
            symbol_table_output_folder = argv[i+1];
            return true;
        }
    }
    return false;
}

void printError(){
    printf("[!] Error. Wrong command line options\n");
    return;
}


void printUsage(){
    cout << "Usage: ./run -i <input file> -o <output file>\n";
    cout << "[REQUIRED]-i or --input <input file>: input file name\n";
    cout << "[REQUIRED]-o or --output <output file>: output file name\n";
    cout << "[OPTIONAL]-v or --verbose: verbose mode\n";
    cout << "[OPTIONAL]-a or --ast <DOT output file name>: print ast\n";
    cout << "[OPTIONAL]-s or --sym <symbol table output folder>: print symbol table\n";
    return;
}