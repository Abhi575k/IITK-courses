#include "typecheck.h"

int getDimsCount(ast *ast_root){
    // TYPE: REFERENCE_TYPE
    if(ast_root->id == 11){
        return getDimsCount(ast_root->children[0]);
    }
    // REFERENCE_TYPE: ARRAY_TYPE
    else if(ast_root->id == 25){
        return getDimsCount(ast_root->children[0]);
    }
    // ARRAY_TYPE: PRIMITIVE_TYPE DIMS
    else if(ast_root->id == 29){
        return get_DIMS_dims(ast_root->children[1]);
    }
    // ARRAY_TYPE: NAME DIMS
    else if(ast_root->id == 30){
        return get_DIMS_dims(ast_root->children[1]);
    }
    // ARRAY_TYPE: ARRAY_TYPE DIMS
    else if(ast_root->id == 31){
        return get_DIMS_dims(ast_root->children[1]);
    }
    return 0;
}

int get_DIMS_dims(ast *ast_root){
    // DIMS: LBRACKET RBRACKET
    if(ast_root->id == 402){
        return 1;
    }
    // DIMS: DIMS LBRACKET RBRACKET
    else if(ast_root->id == 405){
        return 1 + getDimsCount(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_DIMS_dims() called with wrong ast_root->id\n";
        return 0;
    }
}

string get_METHOD_HEADER_name(ast *ast_root){
    // MODIFIERS TYPE METHOD_DECLARATOR
    if (ast_root->id == 124){
        return get_METHOD_DECLARATOR_name(ast_root->children[2]);
    }
    // TYPE METHOD_DECLARATOR
    else if (ast_root->id == 126){
        return get_METHOD_DECLARATOR_name(ast_root->children[1]);
    }
    // MODIFIERS VOID METHOD_DECLARATOR
    else if (ast_root->id == 129){
        return get_METHOD_DECLARATOR_name(ast_root->children[2]);
    }
    // VOID METHOD_DECLARATOR
    else if (ast_root->id == 133){
        return get_METHOD_DECLARATOR_name(ast_root->children[1]);
    }
    else{
        cout << "[!!] Implementation error, get_METHOD_HEADER_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_METHOD_DECLARATOR_name(ast *ast_root){
    // IDENTIFIER LPAREN FORMAL_PARAMETER_LIST RPAREN
    if (ast_root->id == 135){
        return ast_root->children[0]->label;
    }
    // IDENTIFIER LPAREN RPAREN
    else if (ast_root->id == 139){
        return ast_root->children[0]->label;
    }
    // IDENTIFIER LBRACKET RBRACKET LPAREN FORMAL_PARAMETER_LIST RPAREN
    else if (ast_root->id == 557){
        return ast_root->children[0]->label;
    }
    // IDENTIFIER LBRACKET RBRACKET LPAREN RPAREN
    else if (ast_root->id == 563){
        return ast_root->children[0]->label;
    }
    else{
        cout << "[!!] Implementation error, get_METHOD_DECLARATOR_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_TYPE_type(ast *ast_root){
    // TYPE: PRIMITIVE_TYPE
    if(ast_root->id == 10){
        return get_TYPE_type(ast_root->children[0]);
    }
    // TYPE: REFERENCE_TYPE
    else if(ast_root->id == 11){
        return get_TYPE_type(ast_root->children[0]);
    }
    // PRIMITIVE_TYPE: NUMERIC_TYPE
    else if(ast_root->id == 12){
        return get_TYPE_type(ast_root->children[0]);
    }
    // PRIMITIVE_TYPE: BOOLEAN
    else if(ast_root->id == 13){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: INT
    else if(ast_root->id == 15){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: FLOAT
    else if(ast_root->id == 17){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: LONG
    else if(ast_root->id == 19){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: DOUBLE
    else if(ast_root->id == 21){
        return ast_root->children[0]->label;
    }
    // REFERENCE_TYPE: CLASS_OR_INTERFACE_TYPE
    else if(ast_root->id == 24){
        return get_TYPE_type(ast_root->children[0]);
    }
    // REFERENCE_TYPE: ARRAY_TYPE
    else if(ast_root->id == 25){
        return get_TYPE_type(ast_root->children[0]);
    }
    // CLASS_OR_INTERFACE_TYPE: NAME
    else if(ast_root->id == 26){
        return get_NAME_name(ast_root->children[0]);
    }
    // ARRAY_TYPE: PRIMITIVE_TYPE DIMS
    else if(ast_root->id == 29){
        return get_TYPE_type(ast_root->children[0]);
    }
    // ARRAY_TYPE: NAME DIMS
    else if(ast_root->id == 30){
        return get_NAME_name(ast_root->children[0]);
    }
    // ARRAY_TYPE: ARRAY_TYPE DIMS
    else if(ast_root->id == 31){
        return get_TYPE_type(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_TYPE_type() called with wrong ast_root->id\n";
        return "";
    }
}

string get_NAME_name(ast *ast_root){
    // SIMPLE_NAME
    if(ast_root->id == 32){
        return get_NAME_name(ast_root->children[0]);
    }
    // QUALIFIED NAME
    else if(ast_root->id == 33){
        return get_NAME_name(ast_root->children[0]) + "." + get_NAME_name(ast_root->children[2]);
    }
    // SIMPLE_NAME: IDENTIFIER
    else if(ast_root->id == 35){
        return ast_root->children[0]->label;
    }
    else{
        cout << "[!!] Implementation error, get_NAME_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_VARIABLE_DECLARATOR_ID_name(ast *ast_root){
    // VARIABLE_DECLARATOR_ID: IDENTIFIER
    if(ast_root->id == 115){
        return ast_root->children[0]->label;
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET RBRACKET
    else if(ast_root->id == 117){
        return get_VARIABLE_DECLARATOR_ID_name(ast_root->children[0]);
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET EXPRESSION RBRACKET
    else if(ast_root->id == 554){
        return get_VARIABLE_DECLARATOR_ID_name(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_VARIABLE_DECLARATOR_ID_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_LEFT_HAND_SIDE_name(ast *ast_root){
    // NAME
    if(ast_root->id == 528){
        return get_NAME_name(ast_root->children[0]);
    }
    // FIELD_ACCESS
    else if(ast_root->id == 529){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    // ARRAY_ACCESS
    else if(ast_root->id == 530){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    // FIELD_ACCESS: PRIMARY DOT IDENTIFIER
    else if(ast_root->id == 408){
        return get_PRIMARY_name(ast_root->children[0]) + "." + ast_root->children[2]->label;
    }
    // ARRAY_ACCESS: PRIMARY LBRACKET EXPRESSION RBRACKET
    else if(ast_root->id == 430){
        threeAC *t0 = create3AC(ast_root->children[2], 0);
        return get_PRIMARY_name(ast_root->children[0]) + "[" + t0->res + "]";
    }
    // ARRAY_ACCESS: NAME LBRACKET EXPRESSION RBRACKET
    else if(ast_root->id == 433){
        threeAC *t0 = create3AC(ast_root->children[2], 0);
        return get_NAME_name(ast_root->children[0]) + "[" + t0->res + "]";
    }
    else{
        cout << "[!!] Implementation error, get_LEFT_HAND_SIDE_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_PRIMARY_name(ast *ast_root){
    // PRIMARY_NO_NEW_ARRAY
    if(ast_root->id == 368){
        return get_PRIMARY_name(ast_root->children[0]);
    }
    // PRIMARY_NO_NEW_ARRAY: FIELD_ACCESS
    else if(ast_root->id == 375){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    // PRIMARY_NO_NEW_ARRAY: ARRAY_ACCESS
    else if(ast_root->id == 376){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_PRIMARY_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_CLASS_TYPE_name(ast *ast_root){
    // CLASS_TYPE: CLASS_OR_INTERFACE_TYPE
    if(ast_root->id == 27){
        return get_CLASS_TYPE_name(ast_root->children[0]);
    }
    // CLASS_OR_INTERFACE_TYPE: NAME 
    else if(ast_root->id == 26){
        return get_NAME_name(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_CLASS_TYPE_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_FIELD_ACCESS_name(ast *ast_root){
    // FIELD_ACCESS: PRIMARY DOT IDENTIFIER
    if(ast_root->id == 408){
        return get_PRIMARY_name(ast_root->children[0]) + "." + ast_root->children[2]->label;
    }
    else{
        cout << "[!!] Implementation error, get_FIELD_ACCESS_name() called with wrong ast_root->id\n";
    }
}


// void checkFunctionParam(ast *ast_root, vector<SymbolTableEntry *> param_table){

// }

// string typeCheck(ast *root){
//     // LITERAL: INTEGERLITERAL|LONGLITERAL|FLOATLITERAL|DOUBLELITERAL|BOOLEANLITERAL
//     if(root->id == 1|| root->id == 3 || root->id == 5 || root->id == 7 || root->id == 9){
//         if(root->id == 1) return "int";
//         else if(root->id == 3) return "long";
//         else if(root->id == 5) return "float";
//         else if(root->id == 7) return "double";
//         else if(root->id == 9) return "boolean";
//     }
//     // PRIMITIVE_TYPE: BOOLEAN
//     else if(root->id == 13){
//         return "boolean";
//     }
//     // NUMERIC_TYPE: INT|FLOAT|LONG|DOUBLE
//     else if(root->id == 15 || root->id == 17 || root->id == 19 || root->id == 21){   
//         if(root->id == 15) return "int";
//         else if(root->id == 17) return "float";
//         else if(root->id == 19) return "long";
//         else if(root->id == 21) return "double";
//     }
//     // ARRAY_TYPE: PRIMITIVE_TYPE DIMS|NAME DIMS|ARRAY_TYPE DIMS
//     else if(root->id == 29 || root->id == 30 || root->id == 31){
//         string t0 = typeCheck(root->children[0]);
//         string t1 = typeCheck(root->children[1]);

//         if((t1 != "int" && t1 != "void")){
//             yyerror("Array index must be of type int", root->lineno);
//         }

//         root->children[0]->sendTypes();

//         return t0;
//     }
//     // SIMPLE_NAME: IDENTIFIER
//     else if(root->id == 35){
//         return root->children[0]->label;
//     }
//     // QUALIFIED_NAME: NAME DOT IDENTIFIER
//     else if(root->id == 36){
//         string t0 = typeCheck(root->children[0]) + "." + root->children[2]->label;

//         return t0;
//     }
//     // FIELD_DECLARATION: MODIFIERS TYPE VARIABLE_DECLARATORS SEMICOLON
//     else if(root->id == 105){
//         string t0 = get_TYPE_type(root->children[1]);
//         string t1 = typeCheck(root->children[2]);

//         if (t1 != t0){
//             yyerror("Type mismatch", root->lineno);
//         }

//         root->children[2]->sendTypes();

//         return t0;
//     }
//     // FIELD_DECLARATION: TYPE VARIABLE_DECLARATORS SEMICOLON
//     else if(root->id == 107){
//         string t0 = get_TYPE_type(root->children[0]);
//         string t1 = typeCheck(root->children[1]);

//         if (t1 != t0){
//             yyerror("Type mismatch", root->lineno);
//         }

//         root->children[1]->sendTypes();

//         return t0;
//     }
//     // VARIABLE_DECLARATORS: VARIABLE_DECLARATORS COMMA VARIABLE_DECLARATOR
//     else if(root->id == 110){

//         string t0 = typeCheck(root->children[0]);
//         string t1 = typeCheck(root->children[2]);

//         if (t1 != t0){
//             yyerror("Type mismatch", root->lineno);
//         }

//         root->children[0]->sendTypes();
//         root->children[2]->sendTypes();

//         return t0;

//     }
//     // VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID
//     else if(root->id == 112){
//         string t0 = symbol_table_root->getEntry(get_VARIABLE_DECLARATOR_ID_name(root->children[0]))->type;
//         root->datatype = t0;
//         root->sendTypes();
//         return t0;
//     }
//     // VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID ASSIGN VARIABLE_INITIALIZER
//     else if(root->id == 113){

//         string t0 = symbol_table_root->getEntry(get_VARIABLE_DECLARATOR_ID_name(root->children[0]))->type;
//         string t1 = typeCheck(root->children[2]);

//         if(t0 != t1){
//             yyerror("Type mismatch", root->lineno);
//         }

//         root->datatype = t0;
//         root->sendTypes();

//         return t0;
//     }
//     // VARIABLE_DECLARATOR_ID: IDENTIFIER
//     else if(root->id == 115){
//         return root->children[0]->label;
//     }
//     // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET RBRACKET
//     else if(root->id == 117){
//         string t0 = symbol_table_root->getEntry(get_VARIABLE_DECLARATOR_ID_name(root->children[0]))->type;
//         root->datatype = t0;
//         root->sendTypes();
//         return t0;
//     }
//     // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET EXPRESSION RBRACKET
//     else if(root->id == 554){
//         string t0 = symbol_table_root->getEntry(get_VARIABLE_DECLARATOR_ID_name(root->children[0]))->type;
//         root->datatype = t0;
//         root->sendTypes();

//         string t1 = typeCheck(root->children[2]);

//         if(t1 != "int"){
//             yyerror("Array index must be of type int", root->lineno);
//         }

//         root->children[0]->sendTypes();
//         return t0;
//     }
//     // LOCAL_VARIABLE_DECLARATION: TYPE VARIABLE_DECLARATORS
//     else if(root->id == 253){
//         string t0 = get_TYPE_type(root->children[0]);
//         string t1 = typeCheck(root->children[1]);

//         if (t1 != t0){
//             yyerror("Type mismatch", root->lineno);
//         }
        
//         root->datatype = t0;

//         root->sendTypes();

//         return t0;
//     }
//     // RETURN_STATEMENT: RETURN EXPRESSION SEMICOLON
//     else if(root->id == 362){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[1], 0);

//         int v_cnt_t0 = v_cnt;
//         v_cnt++;

//         threeAC *t2 = new threeAC();
//         t2->res = "%rax";
//         t2->arg1 = t1->res;

//         threeACList.push_back(t2);

//         t0->res = "%rax";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // RETURN_STATEMENT: RETURN SEMICOLON
//     else if(root->id == 365){
//         threeAC *t0 = new threeAC();

//         t0->res = "ret";

//         threeACList.push_back(t0);

//         return t0;
//     }
    // // CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN ARGUMENT_LIST RPAREN
    // else if(root->id == 378){
    //     string t0 = get_CLASS_TYPE_name(root->children[1]);

    //     vector<SymbolTableEntry *> const_list = symbol_table_root->getFunctionParamTable(t0);

    //     checkFunctionParam(root->children[3], const_list);

    //     root->datatype = t0;

    //     return t0;
    // }
    // // CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN RPAREN
    // else if(root->id == 382){
    //     string t0 = get_CLASS_TYPE_name(root->children[1]);

    //     root->datatype = t0;

    //     return t0;
    // }
    // // ARRAY_CREATION_EXPRESSION: NEW PRIMITIVE_TYPE DIM_EXPRS
    // // ARRAY_CREATION_EXPRESSION: NEW CLASS_OR_INTERFACE_TYPE DIM_EXPRS
    // else if(root->id == 389 || root->id == 393){
    //     string t0 = get_PRIMITIVE_TYPE_type(root->children[1]);
    //     string t1 = typeCheck(root->children[2]);

    //     if(t1 != "int"){
    //         yyerror("Array index must be of type int", root->lineno);
    //     }

    //     root->datatype = t0;

    //     return t0;
    // }
//     // DIM_EXPRS: DIM_EXPRS DIM_EXPR
//     else if(root->id == 398){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         threeAC *t2 = create3AC(root->children[1], 0);

//         t0->res = t1->res + t2->res;

//         return t0;
//     }
//     // DIM_EXPR : LBRACKET EXPRESSION RBRACKET
//     else if(root->id == 399){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->res = "[" + t1->res + "]";

//         return t0;
//     }
//     // DIMS: LBRACKET RBRACKET
//     else if(root->id == 402){
//         threeAC *t0 = new threeAC();

//         t0->res = "[]";

//         return t0;
//     }
//     // DIMS: DIMS LBRACKET RBRACKET
//     else if(root->id == 405){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->res = t1->res + "[]";

//         return t0;
//     }
//     // FIELD_ACCESS: PRIMARY DOT IDENTIFIER
//     else if(root->id == 408){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->res = t1->res + "." + root->children[2]->label;

//         return t0;
//     }
//     // METHOD_INVOCATION: NAME LPAREN ARGUMENT_LIST RPAREN
//     else if(root->id == 414){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->res = "goto: ." + t1->res;
//         t0->is_label = true;

//         threeAC *t2 = create3AC(root->children[2], 0);

//         threeACList.push_back(t0);

//         threeAC *t3 = new threeAC();

//         t3->res = "#v_" + to_string(v_cnt);

//         return t3;
//     }
//     // METHOD_INVOCATION: NAME LPAREN RPAREN
//     else if(root->id == 417){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->res = "goto: ." + t1->res;
//         t0->is_label = true;

//         threeACList.push_back(t0);

//         threeAC *t2 = new threeAC();

//         t2->res = "#v_" + to_string(v_cnt);

//         return t2;
//     }
//     // METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN ARGUMENT_LIST RPAREN
//     else if(root->id == 420){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->res = "goto: ." + t1->res + "." + root->children[2]->label;
//         t0->is_label = true;

//         threeACList.push_back(t0);

//         threeAC *t2 = create3AC(root->children[4], 0);

//         threeAC *t3 = new threeAC();

//         t3->res = "#v_" + to_string(v_cnt);

//         return t3;
//     }
//     // METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN RPAREN
//     else if(root->id == 425){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->res = "goto: ." + t1->res + "." + root->children[2]->label;
//         t0->is_label = true;

//         threeACList.push_back(t0);

//         threeAC *t2 = new threeAC();

//         t2->res = "#v_" + to_string(v_cnt);

//         return t2;
//     }
//     // ARRAY_ACCESS: PRIMARY_NO_NEW_ARRAY LBRACKET EXPRESSION RBRACKET
//     // ARRAY_ACCESS: NAME LBRACKET EXPRESSION RBRACKET
//     else if(root->id == 430 || root->id == 433){
//         threeAC* t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);
//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->res = t1->res + "[" + t2->res + "]";

//         return t0;
//     }
//     // POST_INCREMENT_EXPRESSION: POSTFIX_EXPRESSION PLUSPLUS
//     else if(root->id == 440){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[0], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = t1->res;
//         t0->op = "+";
//         t0->arg2 = "$1";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // POST_DECREMENT_EXPRESSION: POSTFIX_EXPRESSION MINUSMINUS
//     else if(root->id == 442){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[0], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = t1->res;
//         t0->op = "-";
//         t0->arg2 = "$1";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // UNARY_EXPRESSION: PLUS UNARY_EXPRESSION
//     else if(root->id == 446){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = t1->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // UNARY_EXPRESSION: MINUS UNARY_EXPRESSION
//     else if(root->id == 448){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = "$0";
//         t0->op = "-";
//         t0->arg2 = t1->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // PRE_INCREMENT_EXPRESSION: PLUSPLUS UNARY_EXPRESSION
//         else if(root->id == 451){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = t1->res;
//         t0->op = "+";
//         t0->arg2 = "$1";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // PRE_DECREMENT_EXPRESSION: MINUSMINUS UNARY_EXPRESSION
//     else if(root->id == 453){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = t1->res;
//         t0->op = "-";
//         t0->arg2 = "$1";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // UNARY_EXPRESSION_NOT_PLUS_MINUS: BANG UNARY_EXPRESSION
//     else if(root->id == 456){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";

//         t0->op = "!";
//         t0->arg2 = t1->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // UNARY_EXPRESSION_NOT_PLUS_MINUS: TILDE UNARY_EXPRESSION
//     else if(root->id == 458){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";

//         t0->op = "~";
//         t0->arg2 = t1->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE DIMS RPAREN UNARY_EXPRESSION
//     else if(root->id == 461){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[1], 0);
//         threeAC *t2 = create3AC(root->children[2], 0);
//         // cout << root->id << "\n";
//         threeAC *t3 = create3AC(root->children[4], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = "cast_to_" + t1->res + t2->res + "(" + t3->res + ")";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // CAST_EXPRESSION: LPAREN NAME DIMS RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS
//     else if(root->id == 464){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[1], 0);
//         threeAC *t2 = create3AC(root->children[2], 0);
//         // cout << root->id << "\n";
//         threeAC *t3 = create3AC(root->children[4], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = "cast_to_" + t1->res + t2->res + "(" + t3->res + ")";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE RPAREN UNARY_EXPRESSION
//     else if(root->id == 467){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";
//         threeAC *t2 = create3AC(root->children[3], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = "cast_to_" + t1->res + "(" + t2->res + ")";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // CAST_EXPRESSION: LPAREN EXPRESSION RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS
//     else if(root->id == 470){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[1], 0);
//         // cout << root->id << "\n";
//         threeAC *t2 = create3AC(root->children[3], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = "cast_to_" + t1->res + "(" + t2->res + ")";

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION MUL UNARY_EXPRESSION
//     else if(root->id == 473){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[0], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = t1->res;
//         t0->op = "*";

//         // cout << root->id << "\n";
//         threeAC *t2 = create3AC(root->children[2], 0);
//         // cout << root->id << "\n";

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION DIV UNARY_EXPRESSION
//     else if(root->id == 475){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "/";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION MOD UNARY_EXPRESSION
//     else if(root->id == 477){
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         // cout << root->id << "\n";
//         threeAC *t1 = create3AC(root->children[0], 0);
//         // cout << root->id << "\n";

//         t0->arg1 = t1->res;
//         t0->op = "%";

//         // cout << root->id << "\n";
//         threeAC *t2 = create3AC(root->children[2], 0);
//         // cout << root->id << "\n";

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // ADDITIVE_EXPRESSION: ADDITIVE_EXPRESSION PLUS MULTIPLICATIVE_EXPRESSION
//     else if(root->id == 480){
//         cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "+";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // ADDITIVE_EXPRESSION: ADDITIVE_EXPRESSION MINUS MULTIPLICATIVE_EXPRESSION
//     else if(root->id == 482){
//         cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "-";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // SHIFT_EXPRESSION: SHIFT_EXPRESSION LEFT_SHIFT ADDITIVE_EXPRESSION
//     else if(root->id == 485){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "<<";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // SHIFT_EXPRESSION: SHIFT_EXPRESSION RIGHT_SHIFT ADDITIVE_EXPRESSION
//     else if(root->id == 487){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = ">>";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // SHIFT_EXPRESSION: UNSIGNED_RIGHT_SHIFT ADDITIVE_EXPRESSION
//     else if(root->id == 490){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = ">>>";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION LESS SHIFT_EXPRESSION
//     else if(root->id == 492){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "<";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION GREATER SHIFT_EXPRESSION
//     else if(root->id == 494){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = ">";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION LESS_EQUAL SHIFT_EXPRESSION
//     else if(root->id == 496){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "<=";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     } 
//     // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION GREATER_EQUAL SHIFT_EXPRESSION
//     else if(root->id == 498){
//         // cout << root->id << "\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = ">=";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // EQUALITY_EXPRESSION: EQUALITY_EXPRESSION EQEQ RELATIONAL_EXPRESSION
//     else if(root->id == 501){
//         // cout << "501\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "==";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // EQUALITY_EXPRESSION: EQUALITY_EXPRESSION NOT_EQUAL RELATIONAL_EXPRESSION
//     else if(root->id == 503){
//         // cout << "503\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "!=";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // AND_EXPRESSION: AND_EXPRESSION AND EQUALITY_EXPRESSION
//     else if(root->id == 506){
//         // cout << "506\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "&";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // EXCLUSIVE_OR_EXPRESSION: EXCLUSIVE_OR_EXPRESSION XOR AND_EXPRESSION
//     else if(root->id == 509){
//         // cout << "509\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "^";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // INCLUSIVE_OR_EXPRESSION: INCLUSIVE_OR_EXPRESSION OR EXCLUSIVE_OR_EXPRESSION
//     else if(root->id == 512){
//         // cout << "512\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "|";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // CONDITIONAL_AND_EXPRESSION: CONDITIONAL_AND_EXPRESSION ANDAND INCLUSIVE_OR_EXPRESSION
//     else if(root->id == 515){
//         // cout << "515\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "&&";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // CONDITIONAL_OR_EXPRESSION: CONDITIONAL_OR_EXPRESSION OROR CONDITIONAL_AND_EXPRESSION
//     else if(root->id == 518){
//         // cout << "518\n";
//         threeAC* t0 = new threeAC();

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;

//         threeAC *t1 = create3AC(root->children[0], 0);

//         t0->arg1 = t1->res;
//         t0->op = "||";

//         threeAC *t2 = create3AC(root->children[2], 0);

//         t0->arg2 = t2->res;

//         threeACList.push_back(t0);

//         return t0;
//     }
//     // CONDITIONAL_EXPRESSION: CONDITIONAL_OR_EXPRESSION QMARK EXPRESSION COLON CONDITIONAL_EXPRESSION
//     else if(root->id == 521){
//         threeAC *t0 = new threeAC();

//         threeAC *t1 = create3AC(root->children[0], 0);

//         threeAC *t2 = create3AC(root->children[2], 0);

//         threeAC *t3 = create3AC(root->children[4], 0);

//         int if_cnt_t0 = if_cnt;
//         if_cnt++;

//         t0->res = "#t_" + to_string(t_cnt);
//         t_cnt++;
//         t0->arg1 = t2->res;

//         threeACList.push_back(t0);

//         threeAC *t4 = new threeAC();
//         t4->res = "if " + t1->res + " goto : .if_" + to_string(if_cnt_t0);

//         threeACList.push_back(t4);

//         threeAC *t5 = new threeAC();

//         t5->res = t0->res;
//         t5->arg1 = t3->res;

//         threeACList.push_back(t5);

//         threeAC *t6 = new threeAC();
        
//         t6->res = ".if_" + to_string(if_cnt_t0) + ":";
//         t6->is_label = true;

//         threeACList.push_back(t6);

//         return t0;
//     }
//     // ASSIGNMENT: LEFT_HAND_SIDE ASSIGNMENT_OPERATOR ASSIGNMENT_EXPRESSION
//     else if(root->id == 527){
//         // cout << "527\n";
//         threeAC *t0 = new threeAC();

//         threeAC *t2 = create3AC(root->children[0], 0);
        
//         t0->res = t2->res;

//         // cout<<t0->res<<"\n";

//         t0->datatype = root->children[0]->datatype;

//         threeAC *t1 = create3AC(root->children[2], 0);

//         // ASSIGNMENT_OPERATOR: ASSIGN
//         if(root->children[1]->id == 531){
//             t0->arg1 = t1->res;
//         }
//         else{
//             t0->arg2 = t1->res;
//         }
//         // ASSIGNMENT_OPERATOR: MUL_ASSIGN
//         if(root->children[1]->id == 533){
//             t0->arg1 = t0->res;
//             t0->op = "*";
//         }
//         // ASSIGNMENT_OPERATOR: DIV_ASSIGN
//         else if(root->children[1]->id == 535){
//             t0->arg1 = t0->res;
//             t0->op = "/";
//         }
//         // ASSIGNMENT_OPERATOR: MOD_ASSIGN
//         else if(root->children[1]->id == 537){
//             t0->arg1 = t0->res;
//             t0->op = "%";
//         }
//         // ASSIGNMENT_OPERATOR: ADD_ASSIGN
//         else if(root->children[1]->id == 539){
//             t0->arg1 = t0->res;
//             t0->op = "+";
//         }
//         // ASSIGNMENT_OPERATOR: SUB_ASSIGN
//         else if(root->children[1]->id == 541){
//             t0->arg1 = t0->res;
//             t0->op = "-";
//         }
//         // ASSIGNMENT_OPERATOR: LEFT_ASSIGN
//         else if(root->children[1]->id == 543){
//             t0->arg1 = t0->res;
//             t0->op = "<<";
//         }
//         // ASSIGNMENT_OPERATOR: RIGHT_ASSIGN
//         else if(root->children[1]->id == 545){
//             t0->arg1 = t0->res;
//             t0->op = ">>";
//         }
//         // ASSIGNMENT_OPERATOR: AND_ASSIGN
//         else if(root->children[1]->id == 547){
//             t0->arg1 = t0->res;
//             t0->op = "&";
//         }
//         // ASSIGNMENT_OPERATOR: XOR_ASSIGN
//         else if(root->children[1]->id == 549){
//             t0->arg1 = t0->res;
//             t0->op = "^";
//         }
//         // ASSIGNMENT_OPERATOR: OR_ASSIGN
//         else if(root->children[1]->id == 551){
//             t0->arg1 = t0->res;
//             t0->op = "|";
//         }

//         threeACList.push_back(t0);

//         return t1;
//     }else{
//         threeAC* t0 = new threeAC();
//         for (auto u : root->children) t0 = create3AC(u, 0);
//         return t0;
//     }
// }