#include "3ac.h"

int t_cnt = 0;
int a_cnt = 0;
int v_cnt = 0;
int if_cnt = 0;
int while_cnt = 0;
int for_cnt = 0;
int var_cnt=1;

vector<threeAC *> threeACList;
map<string, string> var_list;

vector<threeACStack> Stack; 

threeAC::threeAC(){
    this->op = "";
    this->arg1 = "";
    this->arg2 = "";
    this->res = "";
    this->lineno = 0;
    this->datatype = "";
    this->is_label = false;
}

void threeAC::print(){
    if(this->is_label) cout << this->res << "\n";
    else if (arg1=="") cout << "\t" << res << "\n";
    else if(op == "") cout << "\t" << res << " = " << arg1 << "\n";
    else cout << "\t" << res << " = " << arg1 << " " << op << " " << arg2 << "\n";
    return;
}

void threeAC::append(threeAC *tac){
    this->next = tac;
}

void dumpThreeAC(FILE* out){
    for (auto u: threeACList){
        if(u->is_label) fprintf(out, "%s\n", u->res.c_str());
        else if(u->arg1 == "") fprintf(out, "\t%s\n", u->res.c_str());
        else if(u->op == "") fprintf(out, "\t%s = %s\n", u->res.c_str(), u->arg1.c_str());
        else fprintf(out, "\t%s = %s %s %s\n", u->res.c_str(), u->arg1.c_str(), u->op.c_str(), u->arg2.c_str());
    }
    return;
}

threeAC* create3AC(ast *root, int val){
    // LITERAL: INTEGERLITERAL|LONGLITERAL|FLOATLITERAL|DOUBLELITERAL|BOOLEANLITERAL
    if(root->id == 1|| root->id == 3 || root->id == 5 || root->id == 7 || root->id == 9){
        threeAC *t0 = new threeAC();

        t0->res = "$" + root->children[0]->label;

        return t0;
    }
    // PRIMITIVE_TYPE: BOOLEAN
    else if(root->id == 13){
        threeAC *t0 = new threeAC();

        t0->res = root->children[0]->label;

        return t0;
    }
    // NUMERIC_TYPE: INT|FLOAT|LONG|DOUBLE
    else if(root->id == 15 || root->id == 17 || root->id == 19 || root->id == 21){
        threeAC *t0 = new threeAC();

        t0->res = root->children[0]->label;

        return t0;
    }
    // ARRAY_TYPE: PRIMITIVE_TYPE DIMS|NAME DIMS|ARRAY_TYPE DIMS
    else if(root->id == 29 || root->id == 30 || root->id == 31){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        t0->res = t1->res;

        threeAC *t2 = create3AC(root->children[1], 0);
        t0->res += t2->res;

        return t0;
    }
    // SIMPLE_NAME: IDENTIFIER
    else if(root->id == 35){
        threeAC *t0 = new threeAC();

        t0->res = root->children[0]->label;

        return t0;
    }
    // QUALIFIED_NAME: NAME DOT IDENTIFIER
    else if(root->id == 36){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        t0->res = t1->res;

        t0->res += "." + root->children[2]->label;

        return t0;
    }
    // CLASS_DECLARATION: CLASS IDENTIFIER CLASS_BODY
    if(root->id == 79){
        threeAC *t0 = new threeAC();

        t0->res = "class_" + root->children[1]->label + ":";
        t0->is_label = true;

        threeACList.push_back(t0);
        threeAC* t1 = create3AC(root->children[2], 0);

        return t0;
    }
    // CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER CLASS_BODY
    else if(root->id == 82){
        threeAC *t0 = new threeAC();

        t0->res = "class_" + root->children[2]->label + ":";
        t0->is_label = true;

        threeACList.push_back(t0);
        threeAC* t1 = create3AC(root->children[3], 0);

        return t0;
    }
    // FIELD_DECLARATION: MODIFIERS TYPE VARIABLE_DECLARATORS SEMICOLON
    else if(root->id == 105){
        threeAC *t0 = create3AC(root->children[2], 0);

        return t0;
    }
    // FIELD_DECLARATION: TYPE VARIABLE_DECLARATORS SEMICOLON
    else if(root->id == 107){
        threeAC *t0 = create3AC(root->children[1], 0);

        return t0;
    }
    // VARIABLE_DECLARATORS: VARIABLE_DECLARATORS COMMA VARIABLE_DECLARATOR
    else if(root->id == 110){
        threeAC *t0 = create3AC(root->children[0], 0);
        threeAC *t1 = create3AC(root->children[2], 0);

        return t0;
    }
    // VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID
    else if(root->id == 112){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        t0->label = t1->res;

        Stack.push_back({t0->label, true});
        t0->id = Stack.size()-1;

        // t0->datatype = root->datatype;
        t0->res = "%rsp";
        t0->arg1 = "%rsp";
        t0->op = "-";
        t0->arg2 = "$8";

        threeACList.push_back(t0);

        return t0;
    }
    // VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID ASSIGN VARIABLE_INITIALIZER
    else if(root->id == 113){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        t0->label = t1->res;

        Stack.push_back({t0->label, true});
        t0->id = Stack.size()-1;

        // t0->datatype = root->datatype;
        t0->res = "%rsp";
        t0->arg1 = "%rsp";
        t0->op = "-";
        t0->arg2 = "$8";

        threeACList.push_back(t0);

        threeAC *t2 = new threeAC();

        threeAC *t3 = create3AC(root->children[2], 0);

        // t2->datatype = t0->datatype;
        t2->res = "$" + to_string(8*(Stack.size()-t0->id)) + "(%rsp)";
        t2->arg1 = t3->res;
        
        threeACList.push_back(t2);

        return t0;
    }
    // VARIABLE_DECLARATOR_ID: IDENTIFIER
    else if(root->id == 115){
        threeAC *t0 = new threeAC();

        t0->res = root->children[0]->label;

        return t0;
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET RBRACKET
    else if(root->id == 117){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        t0->res = t1->res + "[]";

        return t0;
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET EXPRESSION RBRACKET
    else if(root->id == 554){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        threeAC *t2 = create3AC(root->children[2], 0);
        t0->res = t1->res + "[" + t2->res + "]";

        return t0;
    }
    // METHOD_DECLARATION: METHOD_HEADER METHOD_BODY
    else if (root->id == 122){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = "function_" + t1->res + ":";
        t0->comment = "# FUNCTION LABEL";
        t0->is_label = true;

        threeACList.push_back(t0);

        // CALLEE RULES

        threeAC *t2 = new threeAC();

        t2->res = "push %rbp";

        threeACList.push_back(t2);

        threeAC *t3 = new threeAC();

        t3->res = "mov %rsp, %rbp";

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();

        t4->res = "push %rbx";

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->res = "push %r12";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->res = "push %r13";

        threeACList.push_back(t6);

        threeAC *t7 = new threeAC();

        t7->res = "push %r14";

        threeACList.push_back(t7);

        threeAC *t8 = new threeAC();

        t8->res = "push %r15";

        threeACList.push_back(t8);

        // METHOD BODY

        threeAC* t9 = create3AC(root->children[1], 0);

        // CALLEE RULES

        threeAC *t10 = new threeAC();

        t10->res = "pop %r15";

        threeACList.push_back(t10);

        threeAC *t11 = new threeAC();

        t11->res = "pop %r14";

        threeACList.push_back(t11);

        threeAC *t12 = new threeAC();

        t12->res = "pop %r13";

        threeACList.push_back(t12);

        threeAC *t13 = new threeAC();

        t13->res = "pop %r12";

        threeACList.push_back(t13);

        threeAC *t14 = new threeAC();

        t14->res = "pop %rbx";

        threeACList.push_back(t14);

        threeAC *t15 = new threeAC();

        t15->res = "pop %rbp";

        threeACList.push_back(t15);

        return t0;
    }
    // METHOD_HEADER: MODIFIERS TYPE METHOD_DECLARATOR|MODIFIERS VOID METHOD_DECLARATOR
    else if(root->id == 124 || root->id == 129){
        threeAC *t0 = create3AC(root->children[2], 0);

        return t0;
    }
    // METHOD_HEADER: TYPE METHOD_DECLARATOR|VOID METHOD_DECLARATOR
    else if(root->id == 126 || root->id == 133){
        threeAC *t0 = create3AC(root->children[1], 0);

        return t0;
    }
    // METHOD_DECLARATOR: IDENTIFIER LPAREN FORMAL_PARAMETER_LIST RPAREN
    else if(root->id == 135){
        threeAC *t0 = new threeAC();

        t0->res = root->children[0]->label;
        threeAC *t1 = create3AC(root->children[2], 0);

        return t0;
    }
    // METHOD_DECLARATOR: IDENTIFIER LPAREN RPAREN
    else if(root->id == 139){
        threeAC *t0 = new threeAC();

        t0->res = root->children[0]->label;

        return t0;
    }
    // FORMAL_PARAMETER_LIST: FORMAL_PARAMETER_LIST COMMA FORMAL_PARAMETER
    else if(root->id == 147){
        threeAC *t0 = create3AC(root->children[0], 0);
        threeAC *t1 = create3AC(root->children[2], 0);

        return t0;
    }
    // FORMAL_PARAMETER: TYPE VARIABLE_DECLARATOR_ID
    else if(root->id == 149){
        threeAC *t0 = new threeAC();

        t0->datatype = root->children[0]->datatype;

        threeAC *t1 = create3AC(root->children[1], 0);

        t0->res = "#a_" + to_string(a_cnt);
        a_cnt++;
        t0->arg1 = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // CONSTRUCTOR_DECLARATION: MODIFIERS CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY
    else if(root->id == 161){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1], 0);
        t0->res = ".constructor_" + t1->res + ":";
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC* t2 = create3AC(root->children[2], 0);

        return t0;
    }
    // CONSTRUCTOR_DECLARATION: CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY
    else if(root->id == 163){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        t0->res = ".constructor_" + t1->res + ":";
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC* t2 = create3AC(root->children[1], 0);

        return t0;
    }
    // CONSTRUCTOR_DECLARATOR: SIMPLE_NAME LPAREN FORMAL_PARAMETER_LIST RPAREN
    else if(root->id == 164){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        t0->res = t1->res;

        threeAC *t2 = create3AC(root->children[2], 0);

        return t0;
    }
    // LOCAL_VARIABLE_DECLARATION: TYPE VARIABLE_DECLARATORS
    else if(root->id == 253){
        threeAC *t0 = create3AC(root->children[1], 0);

        return t0;
    }
    // IF_THEN_STATEMENT: IF LPAREN EXPRESSION RPAREN STATEMENT
    else if(root->id == 288){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[2], 0);

        int if_cnt_t0 = if_cnt;
        if_cnt++;

        t0->res = "if not " + t1->res + " goto: .if_" + to_string(if_cnt_t0);
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t2 = create3AC(root->children[4], 0);

        threeAC *t3 = new threeAC();
        t3->res = ".if_" + to_string(if_cnt_t0) + ":";
        t3->is_label = true;

        threeACList.push_back(t3);

        return t0;
    }
    // IF_THEN_ELSE_STATEMENT: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT
    // IF_THEN_ELSE_STATEMENT_NO_SHORT_IF: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT_NO_SHORT_IF
    else if(root->id == 292 || root->id == 297){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[2], 0);

        int if_cnt_t0 = if_cnt;
        if_cnt++;
        int if_cnt_t1 = if_cnt;
        if_cnt++;

        t0->res = "if not " + t1->res + " goto: .if_" + to_string(if_cnt_t0);
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t2 = create3AC(root->children[4], 0);

        threeAC *t3 = new threeAC();
        t3->res = ".if_" + to_string(if_cnt_t0) + ":";
        t3->is_label = true;

        threeAC *t4 = new threeAC();
        t4->res = "goto: .if_" + to_string(if_cnt_t1);
        t4->is_label = true;

        threeACList.push_back(t4);
        threeACList.push_back(t3);

        threeACList.push_back(t4);

        threeAC *t5 = create3AC(root->children[6], 0);

        threeAC *t6 = new threeAC();
        t6->res = ".if_" + to_string(if_cnt_t1) + ":";
        t6->is_label = true;

        threeACList.push_back(t6);

        return t0;
    }
    // WHILE_STATEMENT: WHILE LPAREN EXPRESSION RPAREN STATEMENT
    // WHILE_STATEMENT_NO_SHORT_IF: WHILE LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF
    else if(root->id == 302 || root->id == 306){
        threeAC *t0 = new threeAC();

        int while_cnt_t0 = while_cnt;
        while_cnt++;
        int while_cnt_t1 = while_cnt;
        while_cnt++;

        t0->res = ".while_" + to_string(while_cnt_t0) + ":";
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[2], 0);
        threeAC *t2 = new threeAC();

        t2->res = "if not " + t1->res + " goto: .while_" + to_string(while_cnt_t1);
        t2->is_label = true;

        threeACList.push_back(t2);

        threeAC *t3 = create3AC(root->children[4], 0);

        threeAC *t4 = new threeAC();
        t4->res = "goto: .while_" + to_string(while_cnt_t0);
        t4->is_label = true;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();
        t5->res = ".while_" + to_string(while_cnt_t1) + ":";
        t5->is_label = true;

        threeACList.push_back(t5);

        return t0;
    }
    // DO_STATEMENT: DO STATEMENT WHILE LPAREN EXPRESSION RPAREN SEMICOLON
    else if(root->id == 310){
        threeAC *t0 = new threeAC();

        int while_cnt_t0 = while_cnt;
        while_cnt++;


        t0->res = ".while_" + to_string(while_cnt_t0) + ":";
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[1], 0);

        threeAC *t2 = create3AC(root->children[4], 0);

        threeAC *t3 = new threeAC();
        t3->res = "if " + t2->res + " goto: .while_" + to_string(while_cnt_t0);
        t3->is_label = true;

        threeACList.push_back(t3);

        return t0;
    }
    // FOR_STATEMENT: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT
    // FOR_STATEMENT_NO_SHORT_IF: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT_NO_SHORT_IF
    else if(root->id == 316 || root->id == 328){
        threeAC *t0 = new threeAC();

        int for_cnt_t0 = for_cnt;
        for_cnt++;
        int for_cnt_t1 = for_cnt;
        for_cnt++;

        threeAC *t1 = create3AC(root->children[2], 0);

        t0->res = ".for_" + to_string(for_cnt_t0) + ":";
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t2 = create3AC(root->children[4], 0);
        threeAC *t3 = new threeAC();

        t3->res = "if not " + t2->res + " goto: .for_" + to_string(for_cnt_t1);
        t3->is_label = true;

        threeACList.push_back(t3);

        threeAC *t4 = create3AC(root->children[6], 0);

        threeAC *t5 = create3AC(root->children[8], 0);

        threeAC *t6 = new threeAC();
        t6->res = "goto: .for_" + to_string(for_cnt_t0);
        t6->is_label = true;

        threeACList.push_back(t6);

        threeAC *t7 = new threeAC();
        t7->res = ".for_" + to_string(for_cnt_t1) + ":";
        t7->is_label = true;

        threeACList.push_back(t7);

        return t0;
    }
    // RETURN_STATEMENT: RETURN EXPRESSION SEMICOLON
    else if(root->id == 362){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1], 0);

        int v_cnt_t0 = v_cnt;
        v_cnt++;

        threeAC *t2 = new threeAC();
        t2->res = "%rax";
        t2->arg1 = t1->res;

        threeACList.push_back(t2);

        t0->res = "%rax";

        threeACList.push_back(t0);

        return t0;
    }
    // RETURN_STATEMENT: RETURN SEMICOLON
    else if(root->id == 365){
        threeAC *t0 = new threeAC();

        t0->res = "ret";

        threeACList.push_back(t0);

        return t0;
    }
    // CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN ARGUMENT_LIST RPAREN
    else if(root->id == 378){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1], 0); 

        threeAC *t2 = create3AC(root->children[3], 0);

        t0->datatype = t1->res;
        t0->arg1 = "new_" + t0->datatype + "()";
        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeACList.push_back(t0);

        return t0;
    }
    // CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN RPAREN
    else if(root->id == 382){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1], 0); 

        t0->datatype = t1->res;
        t0->arg1 = "new_" + t0->datatype + "()";
        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeACList.push_back(t0);

        return t0;
    }
    // ARRAY_CREATION_EXPRESSION: NEW PRIMITIVE_TYPE DIM_EXPRS
    // ARRAY_CREATION_EXPRESSION: NEW CLASS_OR_INTERFACE_TYPE DIM_EXPRS
    else if(root->id == 389 || root->id == 393){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[2], 0);

        t0->datatype = t1->res;
        t0->arg1 = "new_" + t0->datatype + "()";

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeACList.push_back(t0);

        return t0;
    }
    // DIM_EXPRS: DIM_EXPRS DIM_EXPR
    else if(root->id == 398){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        threeAC *t2 = create3AC(root->children[1], 0);

        t0->res = t1->res + t2->res;

        return t0;
    }
    // DIM_EXPR : LBRACKET EXPRESSION RBRACKET
    else if(root->id == 399){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = "[" + t1->res + "]";

        return t0;
    }
    // DIMS: LBRACKET RBRACKET
    else if(root->id == 402){
        threeAC *t0 = new threeAC();

        t0->res = "[]";

        return t0;
    }
    // DIMS: DIMS LBRACKET RBRACKET
    else if(root->id == 405){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = t1->res + "[]";

        return t0;
    }
    // FIELD_ACCESS: PRIMARY DOT IDENTIFIER
    else if(root->id == 408){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = t1->res + "." + root->children[2]->label;

        return t0;
    }
    // METHOD_INVOCATION: NAME LPAREN ARGUMENT_LIST RPAREN
    else if(root->id == 414){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = "goto: ." + t1->res;
        t0->is_label = true;

        threeAC *t2 = create3AC(root->children[2], 0);

        threeACList.push_back(t0);

        threeAC *t3 = new threeAC();

        t3->res = "#v_" + to_string(v_cnt);

        return t3;
    }
    // METHOD_INVOCATION: NAME LPAREN RPAREN
    else if(root->id == 417){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = "goto: ." + t1->res;
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t2 = new threeAC();

        t2->res = "#v_" + to_string(v_cnt);

        return t2;
    }
    // METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN ARGUMENT_LIST RPAREN
    else if(root->id == 420){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = "goto: ." + t1->res + "." + root->children[2]->label;
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t2 = create3AC(root->children[4], 0);

        threeAC *t3 = new threeAC();

        t3->res = "#v_" + to_string(v_cnt);

        return t3;
    }
    // METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN RPAREN
    else if(root->id == 425){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->res = "goto: ." + t1->res + "." + root->children[2]->label;
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t2 = new threeAC();

        t2->res = "#v_" + to_string(v_cnt);

        return t2;
    }
    // ARRAY_ACCESS: PRIMARY_NO_NEW_ARRAY LBRACKET EXPRESSION RBRACKET
    // ARRAY_ACCESS: NAME LBRACKET EXPRESSION RBRACKET
    else if(root->id == 430 || root->id == 433){
        threeAC* t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);
        threeAC *t2 = create3AC(root->children[2], 0);

        t0->res = t1->res + "[" + t2->res + "]";

        return t0;
    }
    // POST_INCREMENT_EXPRESSION: POSTFIX_EXPRESSION PLUSPLUS
    else if(root->id == 440){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[0], 0);
        // cout << root->id << "\n";

        t0->arg1 = t1->res;
        t0->op = "+";
        t0->arg2 = "$1";

        threeACList.push_back(t0);

        return t0;
    }
    // POST_DECREMENT_EXPRESSION: POSTFIX_EXPRESSION MINUSMINUS
    else if(root->id == 442){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[0], 0);
        // cout << root->id << "\n";

        t0->arg1 = t1->res;
        t0->op = "-";
        t0->arg2 = "$1";

        threeACList.push_back(t0);

        return t0;
    }
    // UNARY_EXPRESSION: PLUS UNARY_EXPRESSION
    else if(root->id == 446){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";

        t0->arg1 = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // UNARY_EXPRESSION: MINUS UNARY_EXPRESSION
    else if(root->id == 448){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";

        t0->arg1 = "$0";
        t0->op = "-";
        t0->arg2 = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // PRE_INCREMENT_EXPRESSION: PLUSPLUS UNARY_EXPRESSION
        else if(root->id == 451){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";

        t0->arg1 = t1->res;
        t0->op = "+";
        t0->arg2 = "$1";

        threeACList.push_back(t0);

        return t0;
    }
    // PRE_DECREMENT_EXPRESSION: MINUSMINUS UNARY_EXPRESSION
    else if(root->id == 453){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";

        t0->arg1 = t1->res;
        t0->op = "-";
        t0->arg2 = "$1";

        threeACList.push_back(t0);

        return t0;
    }
    // UNARY_EXPRESSION_NOT_PLUS_MINUS: BANG UNARY_EXPRESSION
    else if(root->id == 456){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";

        t0->op = "!";
        t0->arg2 = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // UNARY_EXPRESSION_NOT_PLUS_MINUS: TILDE UNARY_EXPRESSION
    else if(root->id == 458){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";

        t0->op = "~";
        t0->arg2 = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE DIMS RPAREN UNARY_EXPRESSION
    else if(root->id == 461){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1], 0);
        threeAC *t2 = create3AC(root->children[2], 0);
        // cout << root->id << "\n";
        threeAC *t3 = create3AC(root->children[4], 0);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + t2->res + "(" + t3->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN NAME DIMS RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS
    else if(root->id == 464){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1], 0);
        threeAC *t2 = create3AC(root->children[2], 0);
        // cout << root->id << "\n";
        threeAC *t3 = create3AC(root->children[4], 0);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + t2->res + "(" + t3->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE RPAREN UNARY_EXPRESSION
    else if(root->id == 467){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";
        threeAC *t2 = create3AC(root->children[3], 0);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + "(" + t2->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN EXPRESSION RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS
    else if(root->id == 470){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1], 0);
        // cout << root->id << "\n";
        threeAC *t2 = create3AC(root->children[3], 0);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + "(" + t2->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION MUL UNARY_EXPRESSION
    else if(root->id == 473){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[0], 0);
        // cout << root->id << "\n";

        t0->arg1 = t1->res;
        t0->op = "*";

        // cout << root->id << "\n";
        threeAC *t2 = create3AC(root->children[2], 0);
        // cout << root->id << "\n";

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION DIV UNARY_EXPRESSION
    else if(root->id == 475){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "/";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION MOD UNARY_EXPRESSION
    else if(root->id == 477){
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[0], 0);
        // cout << root->id << "\n";

        t0->arg1 = t1->res;
        t0->op = "%";

        // cout << root->id << "\n";
        threeAC *t2 = create3AC(root->children[2], 0);
        // cout << root->id << "\n";

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // ADDITIVE_EXPRESSION: ADDITIVE_EXPRESSION PLUS MULTIPLICATIVE_EXPRESSION
    else if(root->id == 480){
        cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "+";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // ADDITIVE_EXPRESSION: ADDITIVE_EXPRESSION MINUS MULTIPLICATIVE_EXPRESSION
    else if(root->id == 482){
        cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "-";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // SHIFT_EXPRESSION: SHIFT_EXPRESSION LEFT_SHIFT ADDITIVE_EXPRESSION
    else if(root->id == 485){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "<<";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // SHIFT_EXPRESSION: SHIFT_EXPRESSION RIGHT_SHIFT ADDITIVE_EXPRESSION
    else if(root->id == 487){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = ">>";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // SHIFT_EXPRESSION: UNSIGNED_RIGHT_SHIFT ADDITIVE_EXPRESSION
    else if(root->id == 490){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = ">>>";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION LESS SHIFT_EXPRESSION
    else if(root->id == 492){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "<";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION GREATER SHIFT_EXPRESSION
    else if(root->id == 494){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = ">";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION LESS_EQUAL SHIFT_EXPRESSION
    else if(root->id == 496){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "<=";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    } 
    // RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION GREATER_EQUAL SHIFT_EXPRESSION
    else if(root->id == 498){
        // cout << root->id << "\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = ">=";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // EQUALITY_EXPRESSION: EQUALITY_EXPRESSION EQEQ RELATIONAL_EXPRESSION
    else if(root->id == 501){
        // cout << "501\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "==";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // EQUALITY_EXPRESSION: EQUALITY_EXPRESSION NOT_EQUAL RELATIONAL_EXPRESSION
    else if(root->id == 503){
        // cout << "503\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "!=";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // AND_EXPRESSION: AND_EXPRESSION AND EQUALITY_EXPRESSION
    else if(root->id == 506){
        // cout << "506\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "&";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // EXCLUSIVE_OR_EXPRESSION: EXCLUSIVE_OR_EXPRESSION XOR AND_EXPRESSION
    else if(root->id == 509){
        // cout << "509\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "^";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // INCLUSIVE_OR_EXPRESSION: INCLUSIVE_OR_EXPRESSION OR EXCLUSIVE_OR_EXPRESSION
    else if(root->id == 512){
        // cout << "512\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "|";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // CONDITIONAL_AND_EXPRESSION: CONDITIONAL_AND_EXPRESSION ANDAND INCLUSIVE_OR_EXPRESSION
    else if(root->id == 515){
        // cout << "515\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "&&";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // CONDITIONAL_OR_EXPRESSION: CONDITIONAL_OR_EXPRESSION OROR CONDITIONAL_AND_EXPRESSION
    else if(root->id == 518){
        // cout << "518\n";
        threeAC* t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0], 0);

        t0->arg1 = t1->res;
        t0->op = "||";

        threeAC *t2 = create3AC(root->children[2], 0);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // CONDITIONAL_EXPRESSION: CONDITIONAL_OR_EXPRESSION QMARK EXPRESSION COLON CONDITIONAL_EXPRESSION
    else if(root->id == 521){
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0], 0);

        threeAC *t2 = create3AC(root->children[2], 0);

        threeAC *t3 = create3AC(root->children[4], 0);

        int if_cnt_t0 = if_cnt;
        if_cnt++;

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;
        t0->arg1 = t2->res;

        threeACList.push_back(t0);

        threeAC *t4 = new threeAC();
        t4->res = "if " + t1->res + " goto : .if_" + to_string(if_cnt_t0);

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->res = t0->res;
        t5->arg1 = t3->res;

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();
        
        t6->res = ".if_" + to_string(if_cnt_t0) + ":";
        t6->is_label = true;

        threeACList.push_back(t6);

        return t0;
    }
    // ASSIGNMENT: LEFT_HAND_SIDE ASSIGNMENT_OPERATOR ASSIGNMENT_EXPRESSION
    else if(root->id == 527){
        // cout << "527\n";
        threeAC *t0 = new threeAC();

        threeAC *t2 = create3AC(root->children[0], 0);
        
        t0->res = t2->res;

        // cout<<t0->res<<"\n";

        t0->datatype = root->children[0]->datatype;

        threeAC *t1 = create3AC(root->children[2], 0);

        // ASSIGNMENT_OPERATOR: ASSIGN
        if(root->children[1]->id == 531){
            t0->arg1 = t1->res;
        }
        else{
            t0->arg2 = t1->res;
        }
        // ASSIGNMENT_OPERATOR: MUL_ASSIGN
        if(root->children[1]->id == 533){
            t0->arg1 = t0->res;
            t0->op = "*";
        }
        // ASSIGNMENT_OPERATOR: DIV_ASSIGN
        else if(root->children[1]->id == 535){
            t0->arg1 = t0->res;
            t0->op = "/";
        }
        // ASSIGNMENT_OPERATOR: MOD_ASSIGN
        else if(root->children[1]->id == 537){
            t0->arg1 = t0->res;
            t0->op = "%";
        }
        // ASSIGNMENT_OPERATOR: ADD_ASSIGN
        else if(root->children[1]->id == 539){
            t0->arg1 = t0->res;
            t0->op = "+";
        }
        // ASSIGNMENT_OPERATOR: SUB_ASSIGN
        else if(root->children[1]->id == 541){
            t0->arg1 = t0->res;
            t0->op = "-";
        }
        // ASSIGNMENT_OPERATOR: LEFT_ASSIGN
        else if(root->children[1]->id == 543){
            t0->arg1 = t0->res;
            t0->op = "<<";
        }
        // ASSIGNMENT_OPERATOR: RIGHT_ASSIGN
        else if(root->children[1]->id == 545){
            t0->arg1 = t0->res;
            t0->op = ">>";
        }
        // ASSIGNMENT_OPERATOR: AND_ASSIGN
        else if(root->children[1]->id == 547){
            t0->arg1 = t0->res;
            t0->op = "&";
        }
        // ASSIGNMENT_OPERATOR: XOR_ASSIGN
        else if(root->children[1]->id == 549){
            t0->arg1 = t0->res;
            t0->op = "^";
        }
        // ASSIGNMENT_OPERATOR: OR_ASSIGN
        else if(root->children[1]->id == 551){
            t0->arg1 = t0->res;
            t0->op = "|";
        }

        threeACList.push_back(t0);

        return t1;
    }else{
        threeAC* t0 = new threeAC();
        for (auto u : root->children) t0 = create3AC(u, 0);
        return t0;
    }
}