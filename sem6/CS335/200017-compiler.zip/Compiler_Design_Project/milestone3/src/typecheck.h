#ifndef TYPECHECK_H
#define TYPECHECK_H

#include <bits/stdc++.h>
#include "symboltable.h"
#include "3ac.h"

using namespace std;

// bool intCheck(ast *ast_root, SymbolTable *rootTable);
// bool longCheck(ast *ast_root, SymbolTable *rootTable);
// bool floatCheck(ast *ast_root, SymbolTable *rootTable);
// bool doubleCheck(ast *ast_root, SymbolTable *rootTable);
// bool boolCheck(ast *ast_root, SymbolTable *rootTable);
// int countBracketSequence(ast *ast_root, SymbolTable *rootTable);
// bool checkAllTypes(ast *ast_root, SymbolTable *rootTable);

// extern SymbolTable *symbol_table_root;

// TYPE:
int getDimsCount(ast *ast_root);

// DIMS:
int get_DIMS_dims(ast *ast_root);

// METHOD_HEADER:
string get_METHOD_HEADER_name(ast *ast_root);

// METHOD_DECLARATOR:
string get_METHOD_DECLARATOR_name(ast *ast_root);

// TYPE:
string get_TYPE_type(ast *ast_root);

// NAME:
string get_NAME_name(ast *ast_root);

// VARIABLE_DECLARATOR_ID:
string get_VARIABLE_DECLARATOR_ID_name(ast *ast_root);

// LEFT_HAND_SIDE:
string get_LEFT_HAND_SIDE_name(ast *ast_root);

// PRIMARY:
string get_PRIMARY_name(ast *ast_root);

// CLASS_TYPE:
string get_CLASS_TYPE_name(ast *ast_root);

// FIELD_ACCESS:
string get_FIELD_ACCESS_name(ast *ast_root);

// void checkFunctionParam(ast *ast_root, vector<SymbolTableEntry *> param_table);

// string typeCheck(ast *root);

#endif