#ifndef SYMBOLTABLE_H
#define SYMBOLTABLE_H

#include "ast.h"
#include "typecheck.h"

class SymbolTableEntry
{
public:
    string name;
    string type;
    int line_of_dec;
    bool is_variable;
    int dims;

    SymbolTableEntry();

    SymbolTableEntry(string name, string type, int line_of_dec, bool is_variable, int dims);
    void printEntry();
};

class SymbolTable
{
public:
    string name;
    SymbolTable *parent;
    vector<SymbolTable *> children;
    map<string, SymbolTableEntry *> entries;
    vector<SymbolTableEntry *> function_params;
    vector<SymbolTableEntry *> constructor_params;

    bool is_function;
    bool is_constructor;

    SymbolTable(SymbolTable *parent, string name);
    void addChild(SymbolTable *child);
    void addEntry(SymbolTableEntry *entry);
    SymbolTableEntry *getEntry(string name);

    void printTable();
    void printTableTree(int level);
    
    void addParam(SymbolTableEntry *param);

    bool isInt(string name);
    bool isLong(string name);
    bool isFloat(string name);
    bool isDouble(string name);
    bool isBool(string name);

    vector<SymbolTableEntry *> getFunctionParamTable(string name);

    void dumpSymbolTable(string folder_name);

};

void checkEntry(SymbolTable *rootTable, string name);
void createSymbolTable(ast *root, SymbolTable *rootTable);

#endif