public class Main{
    static void main()
	{
		int idx1 = 15;
		int idx2 = 30;
		for (int i=0; i<idx1; i+=1){
			for (int j=0; j<idx2; j+=1){
				printRAX(i);
				printRAX(j);
			}
		}
	}
}
