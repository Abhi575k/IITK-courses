public class BubbleSortExample {
  public static void main() {
    int arr = 10;
    for (int i = 0; i < arr; i+=1) {
      printRAX(i);
    }

    bubbleSort(arr);

    printRAX(arr);
    for (int i0 = 0; i0 < arr; i0+=1) {
      printRAX(i0);
    }
    return;
  }
  static void bubbleSort(int arr1) {
    int n = arr1 - 1;
    int temp = n * arr1;
    printRAX(temp);
  }
}
