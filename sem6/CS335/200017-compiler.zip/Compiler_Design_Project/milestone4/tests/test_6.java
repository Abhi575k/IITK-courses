public class Main {
    public static void main() {
      int num1 = 5;
      int num2 = 14;
      int pi = 3;
      int istrue = 1;
  
     
      int sum = num1 + num2;
      int diff = num2 - num1;
      int product = num1 * num2;
      int quotient =  num2 / num1;
      int remainder = num2 % num1;
      printRAX(sum);
      printRAX(diff);
      printRAX(product);
      printRAX(quotient);
      printRAX(remainder);
      if (istrue) {
        for(int i=0; i<10; i+=1){
          printRAX(i);
        }
      } else {
        printRAX(pi);
      }
      int radius = 2;
      int area = pi * radius*radius;
     printRAX(area);
    }
  }