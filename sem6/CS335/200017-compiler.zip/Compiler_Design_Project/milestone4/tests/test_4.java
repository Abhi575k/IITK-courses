public class Main {
  public static void main(int args) {
    int input = 5;

    printRAX(input);
    int num = input+1;

    int fact = 1;

    if (num < 0) {
      printRAX(num);
      return;
    }

    for (int i = 1; i <= num; i+=1) {
      fact *= i;
    }

    printRAX(fact);
  }
}