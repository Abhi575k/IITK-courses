public class PowerSet {
    public static void main() {
        int input0 = 10;
        int input1 = 3;
        int idx0 = countIdx(input0);
        printRAX(idx0);
        for(int i=0; i<idx0; i+=1){
            printRAX(i);
        }
    }
    public static int countIdx(int n1) {
        int n3 = n1+3;
        printRAX(n3);
        return n3;
    }
}