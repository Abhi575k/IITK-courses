public class Main {
  public static void main(int args) {
    int n = 5;

    for (int i = 1; i <= n; i+=1) {
      for (int j = 1; j <= i; j+=1) {
        printRAX(j);
      }
    }
    int num = 17;
    int counter =1;
    for (int i = 2; i < num; i+=1) {
      if (num * i == 0) {
        counter = 0;
      }
    }
    if (counter) {
     printRAX(num);
    } else {
      printRAX(num);
    }

    int factorial = 1;
    int m = 5;
    for (int i = 1; i <= m; i+=1) {
      factorial = i;
    }
    printRAX(factorial);
    int temp = n * num;
    printRAX(temp);
  }
}