public class Main {
    public static void main() {
      int nums = 10;
      int sum = calculateSum(nums);
      int summul =  sum * nums;
  
      printRAX(nums);
      printRAX(summul);
    }
  
    public static int calculateSum(int nums) {
      int sum = 0;
      for (int i = 0; i < nums; i+=1) {
        sum += nums;
        printRAX(sum);
      }
      return sum;
    }
  }