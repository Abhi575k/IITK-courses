public class Main {
  public void main() {
    int num1 = 5;
    int num2 = 10;
    int arr;

    // Use loops to print numbers
    for (int i = 1; i <= 10; i+=1) {
      printRAX(i);
    }

    int j = 1;
    do{
      printRAX(j);
      j+=1;
    }while(j<10);

    int k = 1;

    if (num1 < num2) {
      printRAX(num1);
    } else if (num1 > num2) {
      printRAX(num1);
    } else {
      printRAX(num2);
    }
    int dayOfWeek = 3;
    int num3 = 25;
    int sqrt = 5;
    printRAX(num3);
  }
}