#ifndef TYPECHECK_H
#define TYPECHECK_H

#include <bits/stdc++.h>

#include "ast.h"
#include "symboltable.h"

using namespace std;

// TYPE:
extern int getDimsCount(ast *ast_root);

// DIMS:
extern int get_DIMS_dims(ast *ast_root);

// METHOD_HEADER:
extern string get_METHOD_HEADER_name(ast *ast_root);

// METHOD_DECLARATOR:
extern string get_METHOD_DECLARATOR_name(ast *ast_root);

// TYPE:
extern string get_TYPE_type(ast *ast_root);

// NAME:
extern string get_NAME_name(ast *ast_root);

// VARIABLE_DECLARATOR_ID:
extern string get_VARIABLE_DECLARATOR_ID_name(ast *ast_root);

// LEFT_HAND_SIDE:
extern string get_LEFT_HAND_SIDE_name(ast *ast_root);

// PRIMARY:
extern string get_PRIMARY_name(ast *ast_root);

// CLASS_TYPE:
extern string get_CLASS_TYPE_name(ast *ast_root);

// FIELD_ACCESS:
extern string get_FIELD_ACCESS_name(ast *ast_root);

string goto_IDENTIFIER(ast* root);

string goto_LITERAL(ast* root);
string goto_TYPE(ast* root);
string goto_PRIMITIVE_TYPE(ast* root);
string goto_NUMERIC_TYPE(ast* root);
string goto_REFERENCE_TYPE(ast* root);
string goto_CLASS_OR_INTERFACE_TYPE(ast* root);
string goto_CLASS_TYPE(ast* root);
string goto_ARRAY_TYPE(ast* root);
string goto_NAME(ast* root);
string goto_SIMPLE_NAME(ast* root);
string goto_QUALIFIED_NAME(ast* root);
string goto_CLASS_DECLARATION(ast* root);
string goto_FIELD_DECLARATION(ast* root);
string goto_VARIABLE_DECLARATOR(ast* root);
string goto_VARIABLE_DECLARATOR_ID(ast* root);
string goto_METHOD_DECLARATION(ast* root);
string goto_METHOD_HEADER(ast* root);
string goto_METHOD_DECLARATOR(ast* root);
string goto_CONSTRUCTOR_DECLARATION(ast* root);
string goto_CONSTRUCTOR_DECLARATOR(ast* root);
string goto_PRIMARY(ast* root);
string goto_PRIMARY_NO_NEW_ARRAY(ast* root);
string goto_DIMS(ast* root);
string goto_LEFT_HAND_SIDE(ast* root);

#endif