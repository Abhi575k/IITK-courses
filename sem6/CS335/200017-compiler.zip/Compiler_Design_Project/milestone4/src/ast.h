#ifndef AST_H
#define AST_H

#include <bits/stdc++.h>

using namespace std;

class SymbolTable;

class ast{
public:
    int num;
    string label;
    int lineno;
    int id;
    string datatype;
    vector<ast *> children;

    SymbolTable *st;

    int dims;
    bool is_variable;
    bool is_function_param;
    bool is_array;

    string st_name;

    void init_ast();

    ast(char *label, int lineno, int id);
    ast(char *label, vector<ast *> children, int id);

    ast(char *label, vector<ast *> children, int id, char* datatype);
    ast(char *label, vector<ast *> children, int id, string datatype);

    void printtree(FILE *outfile);

    void sendTypes();
};

// global variables
extern int yylineno;
extern FILE *yyin;
extern FILE *yyout;

extern int yylex();
extern int yyparse();

extern void yyerror(char *s);
extern void yyerror(char *s, int lineno);

extern int cnt;
extern int key_count, sep_count, opt_count, id_count, lit_count;
extern ast *parse_tree_root;

extern void printAstVerbose();

#endif