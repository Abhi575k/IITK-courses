#ifndef STACK_H
#define STACK_H

#include <bits/stdc++.h>

#include "ast.h"
#include "3ac.h"

using namespace std;

// maps temporary variables to memory
class threeACStackElem{
public:
    string name;
    int offset;

    bool is_useful;

    threeACStackElem(string name, int offset);
};

class threeACStack{
public:
    int size;
    int offset;

    int rbp_offset;

    vector<threeACStackElem*> elements;
    vector<pair<string, int>> r_reg;

    threeACStack();

    void newVar(string name, int size);

    string getVarName(string name);

    void removeVar(string name);

    string newReg();
    void freeReg(string reg);

    void print();

    void cleanStack();
};

extern threeACStack Stack;
extern vector<threeACStack> StackList;

void pushLocalVariables(SymbolTable* rootTable);
void popLocalVariables(SymbolTable* rootTable);

void pushArgumentsList(vector<SymbolTableEntry*> params, ast* root, int idx);
void popArgumentsList(vector<SymbolTableEntry*> params);

void functionCaleeRules1(int flag);
void functionCaleeRules2(int flag);

void functionCallerRules(int flag);

#endif