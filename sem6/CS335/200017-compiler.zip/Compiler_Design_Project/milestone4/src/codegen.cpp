#include "codegen.h"

void x86_codegen(FILE *out){

    printFileHeader(out);
    
    for (auto u: threeACList){
        if(u->is_label){
            fprintf(out, "%s:\n", u->label.c_str());
        }else{
            if(u->op == "mov")
                fprintf(out, "\tmov %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "push")
                fprintf(out, "\tpush %s\n", u->arg1.c_str());
            else if(u->op == "pop")
                fprintf(out, "\tpop %s\n", u->arg1.c_str());
            else if(u->op == "lea")
                fprintf(out, "\tlea %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "add")
                fprintf(out, "\tadd %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "sub")
                fprintf(out, "\tsub %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "inc")
                fprintf(out, "\tinc %s\n", u->arg1.c_str());
            else if(u->op == "dec")
                fprintf(out, "\tdec %s\n", u->arg1.c_str());
            else if(u->op == "mul")
                fprintf(out, "\tmul %s\n", u->arg1.c_str());
            else if(u->op == "div")
                fprintf(out, "\tdiv %s\n", u->arg1.c_str());
            else if(u->op == "mod")
                fprintf(out, "\tmod %s\n", u->arg1.c_str());
            else if(u->op == "and")
                fprintf(out, "\tand %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "or")
                fprintf(out, "\tor %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "xor")
                fprintf(out, "\txor %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "not")
                fprintf(out, "\tnot %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "cmp")
                fprintf(out, "\tcmp %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "shl")
                fprintf(out, "\tshl %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "shr")
                fprintf(out, "\tshr %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "jmp")
                fprintf(out, "\tjmp %s\n", u->arg1.c_str());
            else if(u->op == "je")
                fprintf(out, "\tje %s\n", u->arg1.c_str());
            else if(u->op == "jne")
                fprintf(out, "\tjne %s\n", u->arg1.c_str());
            else if(u->op == "jg")
                fprintf(out, "\tjg %s\n", u->arg1.c_str());
            else if(u->op == "jge")
                fprintf(out, "\tjge %s\n", u->arg1.c_str());
            else if(u->op == "jl")
                fprintf(out, "\tjl %s\n", u->arg1.c_str());
            else if(u->op == "jle")
                fprintf(out, "\tjle %s\n", u->arg1.c_str());
            else if(u->op == "cmp")
                fprintf(out, "\tcmp %s, %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "call")
                fprintf(out, "\tcall %s\n", u->arg1.c_str());
            else if(u->op == "ret")
                fprintf(out, "\tret\n");
        }
    }

    function_printRAX(out);

    function_printRAXLoop(out);

    function_printRAXLoop2(out);

    return;
}

void printFileHeader(FILE *out){
    fprintf(out, "section .bss\n");
    fprintf(out, "\tdigitSpace resb 100\n");
    fprintf(out, "\tdigitSpacePos resb 8\n");
    fprintf(out, "\n");

    fprintf(out, "section .data\n");
    //
    fprintf(out, "\n");
    ///
    fprintf(out, "\n");

    fprintf(out, "section .text\n");
    fprintf(out, "\tglobal _start\n");
    fprintf(out, "\n");

    fprintf(out, "_start:\n");
    fprintf(out, "\tpush rax\n");
    fprintf(out, "\tpush rcx\n");
    fprintf(out, "\tpush rdx\n");
    fprintf(out, "\tmov r8, rbp\n");
    fprintf(out, "\tcall function_main\n");
    fprintf(out, "\tpop rdx\n");
    fprintf(out, "\tpop rcx\n");
    fprintf(out, "\tpop rax\n");
    fprintf(out, "\tmov rax, 60\n");
    fprintf(out, "\tmov rdi, 0\n");
    fprintf(out, "\tsyscall\n");
    return;
}

void function_printRAX(FILE *out){
    fprintf(out, "function_printRAX:\n");
    fprintf(out, "\tmov rcx, digitSpace\n");
    fprintf(out, "\tmov rbx, 10\n");
    fprintf(out, "\tmov [rcx], rbx\n");
    fprintf(out, "\tinc rcx\n");
    fprintf(out, "\tmov [digitSpacePos], rcx\n");
    return;
}

void function_printRAXLoop(FILE *out){
    fprintf(out, "function_printRAXLoop:\n");
    fprintf(out, "\tmov rdx, 0\n");
    fprintf(out, "\tmov rbx, 10\n");
    fprintf(out, "\tdiv rbx\n");
    fprintf(out, "\tpush rax\n");
    fprintf(out, "\tadd rdx, 48\n");

    fprintf(out, "\tmov rcx, [digitSpacePos]\n");
    fprintf(out, "\tmov [rcx], dl\n");
    fprintf(out, "\tinc rcx\n");
    fprintf(out, "\tmov [digitSpacePos], rcx\n");
    
    fprintf(out, "\tpop rax\n");
    fprintf(out, "\tcmp rax, 0\n");
    fprintf(out, "\tjne function_printRAXLoop\n");
    return;
}

void function_printRAXLoop2(FILE *out){
    fprintf(out, "function_printRAXLoop2:\n");
    fprintf(out, "\tmov rcx, [digitSpacePos]\n");

    fprintf(out, "\tmov rax, 1\n");
    fprintf(out, "\tmov rdi, 1\n");
    fprintf(out, "\tmov rsi, rcx\n");
    fprintf(out, "\tmov rdx, 1\n");
    fprintf(out, "\tsyscall\n");

    fprintf(out, "\tmov rcx, [digitSpacePos]\n");
    fprintf(out, "\tdec rcx\n");
    fprintf(out, "\tmov [digitSpacePos], rcx\n");

    fprintf(out, "\tcmp rcx, digitSpace\n");
    fprintf(out, "\tjge function_printRAXLoop2\n");

    fprintf(out, "\tret\n");
    return;
}
