#include "3ac.h"

// variables only required in this file
int t_cnt = 0;
int v_cnt = 0;
int if_cnt = 0;
int while_cnt = 0;
int for_cnt = 0;
int var_cnt = 1;
int l_cnt = 0;

threeAC::threeAC()
{
    this->op = "";
    this->arg1 = "";
    this->arg2 = "";
    this->res = "";
    this->is_label = false;
    this->label = "";
}

void threeAC::print()
{
    if (this->is_label)
        cout << this->label << ":\n";
    else{
        if(this->op == "mov")
            cout << "mov " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "push")
            cout << "push " << this->arg1 << "\n";
        else if(this->op == "pop")
            cout << "pop " << this->arg1 << "\n";
        else if(this->op == "lea")
            cout << "lea " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "add")
            cout << "add " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "sub")
            cout << "sub " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "inc")
            cout << "inc " << this->arg1 << "\n";
        else if(this->op == "dec")
            cout << "dec " << this->arg1 << "\n";
        else if(this->op == "mul")
            cout << "mul " << this->arg1 << "\n";
        else if(this->op == "div")
            cout << "div " << this->arg1 << "\n";
        else if(this->op == "mod")
            cout << "mod " << this->arg1 << "\n";
        else if(this->op == "and")
            cout << "and " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "or")
            cout << "or " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "xor")
            cout << "xor " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "not")
            cout << "not " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "cmp")
            cout << "cmp " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "shl")
            cout << "shl " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "shr")
            cout << "shr " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "jmp")
            cout << "jmp " << this->arg1 << "\n";
        else if(this->op == "je")
            cout << "je " << this->arg1 << "\n";
        else if(this->op == "jne")
            cout << "jne " << this->arg1 << "\n";
        else if(this->op == "jg")
            cout << "jg " << this->arg1 << "\n";
        else if(this->op == "jge")
            cout << "jge " << this->arg1 << "\n";
        else if(this->op == "jl")
            cout << "jl " << this->arg1 << "\n";
        else if(this->op == "jle")
            cout << "jle " << this->arg1 << "\n";
        else if(this->op == "cmp")
            cout << "cmp " << this->arg1 << " " << this->arg2 << "\n";
        else if(this->op == "call")
            cout << "call " << this->arg1 << "\n";
        else if(this->op == "ret")
            cout << "ret\n";
    }
    return;
}

threeAC *create3AC(ast *root)
{
    // CLASS_DECLARATION: CLASS IDENTIFIER CLASS_BODY
    if (root->id == 79)
    {
        threeAC *t0 = new threeAC();

        t0->label = "class_" + goto_CLASS_DECLARATION(root);
        t0->is_label = true;

        threeACList.push_back(t0);

        create3AC(root->children[2]);

        return t0;
    }
    // CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER CLASS_BODY
    else if (root->id == 82)
    {
        threeAC *t0 = new threeAC();

        t0->label = "class_" + goto_CLASS_DECLARATION(root);
        t0->is_label = true;

        threeACList.push_back(t0);

        create3AC(root->children[3]);

        return t0;
    }
    // VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID ASSIGN VARIABLE_INITIALIZER
    else if (root->id == 113)
    {
        threeAC *t0 = create3AC(root->children[2]);

        threeAC *t1 = new threeAC();

        t1->res = goto_VARIABLE_DECLARATOR_ID(root->children[0]);

        t1->arg1 = Stack.getVarName(t1->res);
        t1->arg2 = t0->res;
        t1->op = "mov";

        threeACList.push_back(t1);

        Stack.freeReg(t0->res);

        return t1;
    }
    // METHOD_DECLARATION: METHOD_HEADER METHOD_BODY
    else if (root->id == 122)
    {
        threeAC *t0 = new threeAC();

        t0->label = "function_" + goto_METHOD_HEADER(root->children[0]);
        t0->is_label = true;

        threeACList.push_back(t0);

        functionCaleeRules1(0);
        pushLocalVariables(root->st);
        functionCaleeRules2(0);

        // METHOD BODY

        create3AC(root->children[1]);

        // CALLEE RULES

        functionCaleeRules2(1);
        popLocalVariables(root->st);
        functionCaleeRules1(1);

        // RETURN

        threeAC *t3 = new threeAC();

        t3->op = "ret";

        threeACList.push_back(t3);

        return t0;
    }
    // CONSTRUCTOR_DECLARATION: MODIFIERS CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY
    else if (root->id == 161)
    {
        threeAC *t0 = new threeAC();

        t0->label = "constructor_" + goto_CONSTRUCTOR_DECLARATOR(root->children[1]);
        t0->is_label = true;

        threeACList.push_back(t0);

        functionCaleeRules1(0);

        pushLocalVariables(root->st);
        functionCaleeRules2(0);

        create3AC(root->children[2]);

        functionCaleeRules2(1);
        popLocalVariables(root->st);
        functionCaleeRules1(1);

        threeAC *t3 = new threeAC();

        t3->op = "ret";

        threeACList.push_back(t3);

        return t0;
    }
    // CONSTRUCTOR_DECLARATION: CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY
    else if (root->id == 163)
    {
        threeAC *t0 = new threeAC();

        t0->label = "constructor_" + goto_CONSTRUCTOR_DECLARATOR(root->children[0]);
        t0->is_label = true;

        threeACList.push_back(t0);

        functionCaleeRules1(0);
        pushLocalVariables(root->st);
        functionCaleeRules2(0);

        create3AC(root->children[1]);

        functionCaleeRules2(1);
        popLocalVariables(root->st);
        functionCaleeRules1(1);

        threeAC *t3 = new threeAC();

        t3->op = "ret";

        threeACList.push_back(t3);

        return t0;
    }
    // IF_THEN_STATEMENT: IF LPAREN EXPRESSION RPAREN STATEMENT
    else if (root->id == 288)
    {
        threeAC *t0 = create3AC(root->children[2]);

        int if_cnt_t0 = if_cnt;
        if_cnt++;

        threeAC *t1 = new threeAC();

        t1->arg1 = t0->res;
        t1->arg2 = "0";
        t1->op = "cmp";

        threeACList.push_back(t1);

        Stack.freeReg(t0->res);

        threeAC *t2 = new threeAC();

        t2->arg1 = "if_" + to_string(if_cnt_t0);
        t2->op = "je";

        threeACList.push_back(t2);

        pushLocalVariables(root->children[4]->st);

        create3AC(root->children[4]);

        popLocalVariables(root->children[4]->st);

        threeAC *t3 = new threeAC();
        t3->label = "if_" + to_string(if_cnt_t0);
        t3->is_label = true;

        threeACList.push_back(t3);

        return t0;
    }
    // IF_THEN_ELSE_STATEMENT: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT
    // IF_THEN_ELSE_STATEMENT_NO_SHORT_IF: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT_NO_SHORT_IF
    else if (root->id == 292 || root->id == 297)
    {
        threeAC *t0 = create3AC(root->children[2]);

        int if_cnt_t0 = if_cnt;
        if_cnt++;
        int if_cnt_t1 = if_cnt;
        if_cnt++;

        threeAC *t1 = new threeAC();

        t1->arg1 = t0->res;
        t1->arg2 = "0";
        t1->op = "cmp";

        threeACList.push_back(t1);

        Stack.freeReg(t0->res);

        threeAC *t2 = new threeAC();

        t2->arg1 = "if_" + to_string(if_cnt_t0);
        t2->op = "je";

        threeACList.push_back(t2);

        pushLocalVariables(root->children[4]->st);

        create3AC(root->children[4]);

        popLocalVariables(root->children[4]->st);

        threeAC *t3 = new threeAC();
        t3->arg1 = "if_" + to_string(if_cnt_t1);
        t3->op = "jmp";

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();
        t4->label = "if_" + to_string(if_cnt_t0);
        t4->is_label = true;

        threeACList.push_back(t4);

        pushLocalVariables(root->children[6]->st);

        create3AC(root->children[6]);

        popLocalVariables(root->children[6]->st);

        threeAC *t5 = new threeAC();
        t5->label = "if_" + to_string(if_cnt_t1);
        t5->is_label = true;

        threeACList.push_back(t5);

        return t0;
    }
    // WHILE_STATEMENT: WHILE LPAREN EXPRESSION RPAREN STATEMENT
    // WHILE_STATEMENT_NO_SHORT_IF: WHILE LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF
    else if (root->id == 302 || root->id == 306)
    {
        threeAC *t0 = create3AC(root->children[2]);

        int while_cnt_t0 = while_cnt;
        while_cnt++;
        int while_cnt_t1 = while_cnt;
        while_cnt++;

        threeAC *t1 = new threeAC();
        t1->label = "while_" + to_string(while_cnt_t0);
        t1->is_label = true;
        threeACList.push_back(t1);

        threeAC *t2 = new threeAC();
        t2->arg1 = t0->res;
        t2->arg2 = "0";
        t2->op = "cmp";

        threeACList.push_back(t2);

        Stack.freeReg(t0->res);

        threeAC *t3 = new threeAC();
        t3->arg1 = "while_" + to_string(while_cnt_t1);
        t3->op = "je";

        threeACList.push_back(t3);

        pushLocalVariables(root->children[4]->st);

        create3AC(root->children[4]);

        popLocalVariables(root->children[4]->st);

        threeAC *t4 = new threeAC();
        t4->arg1 = "while_" + to_string(while_cnt_t0);
        t4->op = "jmp";

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();
        t5->label = "while_" + to_string(while_cnt_t1);
        t5->is_label = true;

        threeACList.push_back(t5);

        return t0;
    }
    // DO_STATEMENT: DO STATEMENT WHILE LPAREN EXPRESSION RPAREN SEMICOLON
    else if (root->id == 310)
    {
        threeAC *t0 = new threeAC();

        int while_cnt_t0 = while_cnt;
        while_cnt++;

        t0->label = "while_" + to_string(while_cnt_t0);
        t0->is_label = true;

        threeACList.push_back(t0);

        pushLocalVariables(root->children[1]->st);

        create3AC(root->children[1]);

        popLocalVariables(root->children[1]->st);

        threeAC *t1 = create3AC(root->children[4]);

        threeAC *t2 = new threeAC();

        t2->arg1 = t1->res;
        t2->arg2 = "0";
        t2->op = "cmp";

        threeACList.push_back(t2);

        Stack.freeReg(t1->res);

        threeAC *t3 = new threeAC();

        t3->arg1 = "while_" + to_string(while_cnt_t0);
        t3->op = "jne";

        threeACList.push_back(t3);

        return t0;
    }
    // FOR_STATEMENT: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT
    // FOR_STATEMENT_NO_SHORT_IF: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT_NO_SHORT_IF
    else if (root->id == 316 || root->id == 328)
    {
        int for_cnt_t0 = for_cnt;
        for_cnt++;
        int for_cnt_t1 = for_cnt;
        for_cnt++;

        pushLocalVariables(root->children[8]->st);

        threeAC *t1 = create3AC(root->children[2]);

        threeAC *t0 = new threeAC();

        t0->label = "for_" + to_string(for_cnt_t0);
        t0->is_label = true;

        threeACList.push_back(t0);

        threeAC *t6 = create3AC(root->children[4]);

        threeAC *t2 = new threeAC();

        t2->arg1 = t6->res;
        t2->arg2 = "0";
        t2->op = "cmp";

        threeACList.push_back(t2);

        Stack.freeReg(t6->res);

        threeAC *t3 = new threeAC();

        t3->arg1 = "for_" + to_string(for_cnt_t1);
        t3->op = "je";

        threeACList.push_back(t3);

        create3AC(root->children[8]);

        create3AC(root->children[6]);

        threeAC *t4 = new threeAC();

        t4->arg1 = "for_" + to_string(for_cnt_t0);
        t4->op = "jmp";

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->label = "for_" + to_string(for_cnt_t1);
        t5->is_label = true;

        threeACList.push_back(t5);

        popLocalVariables(root->children[8]->st);

        return t0;
    }
    // RETURN_STATEMENT: RETURN EXPRESSION SEMICOLON
    else if (root->id == 362)
    {
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1]);

        t0->arg1 = "rax";
        t0->arg2 = t1->res;
        t0->op = "mov";

        threeACList.push_back(t0);

        Stack.freeReg(t1->res);

        return t0;
    }
    // PRIMARY: PRIMARY_NO_NEW_ARRAY | ARRAY_CREATION_EXPRESSION
    else if(root->id == 368 || root->id == 369)
    {
        return create3AC(root->children[0]);
    }

// PRIMARY_NO_NEW_ARRAY: LITERAL| LPAREN EXPRESSION RPAREN| CLASS_INSTANCE_CREATION_EXPRESSION| FIELD_ACCESS| ARRAY_ACCESS| METHOD_INVOCATION

    else if (root->id == 370){
        threeAC *t0 = new threeAC();
        t0->res = goto_LITERAL(root->children[0]);

        threeAC *t1 = new threeAC();
        t1->res = Stack.newReg();
        t1->arg1 = t1->res;
        t1->op = "mov";
        t1->arg2 = t0->res;

        threeACList.push_back(t1);

        return t1;
    }
    else if (root->id == 371){
        return create3AC(root->children[1]);
    }
    else if (root->id == 374){
        return create3AC(root->children[0]);
    }
    else if (root->id == 375){
        return create3AC(root->children[0]);
    }
    else if (root->id == 376){
        return create3AC(root->children[0]);
    }
    else if (root->id == 377){
        return create3AC(root->children[0]);
    }
    // CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN ARGUMENT_LIST RPAREN
    else if (root->id == 378)
    {

        // functionCallerRules(0);

        // vector<SymbolTableEntry *> 

        // pushArgumentsList(goto_CLASS_TYPE(root->children[1]), root->children[3], a);

        threeAC *t0 = new threeAC();

        t0->arg1 = "class_" + goto_CLASS_TYPE(root->children[1]);
        t0->op = "call";

        threeACList.push_back(t0);

        // popArgumentsList(a);

        // functionCallerRules(1);

        return t0;
    }
    // CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN RPAREN
    else if (root->id == 382)
    {

        // functionCallerRules(0);

        threeAC *t0 = new threeAC();

        t0->arg1 = "class_" + goto_CLASS_TYPE(root->children[1]);
        t0->op = "call";

        threeACList.push_back(t0);

        // functionCallerRules(1);

        return t0;
    }
    // // ARRAY_CREATION_EXPRESSION: NEW PRIMITIVE_TYPE DIM_EXPRS
    // // ARRAY_CREATION_EXPRESSION: NEW CLASS_OR_INTERFACE_TYPE DIM_EXPRS
    // else if (root->id == 389 || root->id == 393)
    // {
    //     Stack.newArray(root);

    //     return NULL;
    // }
    // METHOD_INVOCATION: NAME LPAREN ARGUMENT_LIST RPAREN
    else if (root->id == 414)
    {

        // functionCallerRules(0);

        vector<SymbolTableEntry*> temp;

        if(goto_NAME(root->children[0]) != "printRAX"){
            temp = symbol_table_root->findTable(goto_NAME(root->children[0]))->function_params;

            pushArgumentsList(temp, root->children[2], 0);
        }else{
            ast* temp = root->children[2];
            while(temp->children.size()!=0) temp = temp->children[0];

            threeAC *t0 = new threeAC();

            t0->op = "mov";
            t0->arg1 = "rax";
            t0->arg2 = Stack.getVarName(temp->label);

            threeACList.push_back(t0);

        }

        threeAC *t0 = new threeAC();

        t0->arg1 = "function_" + goto_NAME(root->children[0]);
        t0->op = "call";

        threeACList.push_back(t0);

        
        if(goto_NAME(root->children[0]) != "printRAX"){
            popArgumentsList(temp);
        }
        threeAC *t1 = new threeAC();

        t1->op = "mov";
        t1->arg1 = Stack.newReg();
        t1->arg2 = "rax";
        t1->res = t1->arg1;

        threeACList.push_back(t1);
        

        // functionCallerRules(1);

        return t1;
    }
    // METHOD_INVOCATION: NAME LPAREN RPAREN
    else if (root->id == 417)
    {

        // functionCallerRules(0);

        threeAC *t0 = new threeAC();

        t0->arg1 = goto_NAME(root->children[0]);
        t0->op = "call";

        threeACList.push_back(t0);

        threeAC *t1 = new threeAC();

        t1->op = "mov";
        t1->arg1 = Stack.newReg();
        t1->arg2 = "rax";
        t1->res = t1->arg1;

        threeACList.push_back(t1);

        Stack.freeReg(t1->arg1);

        // functionCallerRules(1);

        return t1;
    }
    // METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN ARGUMENT_LIST RPAREN
    else if (root->id == 420)
    {

        // functionCallerRules(0);

        vector<SymbolTableEntry*> temp = symbol_table_root->findTable(goto_IDENTIFIER(root->children[2]))->function_params;

        vector<int> a;

        pushArgumentsList(temp, root->children[4], 0);

        threeAC *t0 = new threeAC();

        t0->arg1 = goto_PRIMARY(root->children[0]) + "." + goto_IDENTIFIER(root->children[2]);
        t0->op = "call";

        threeACList.push_back(t0);

        popArgumentsList(temp);

        threeAC *t1 = new threeAC();

        t1->op = "mov";
        t1->arg1 = "rax";
        t1->arg2 = Stack.newReg();
        t1->res = t1->arg2;

        // functionCallerRules(1);

        return t1;
    }
    // METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN RPAREN
    else if (root->id == 425)
    {
            
            // functionCallerRules(0);
    
            threeAC *t0 = new threeAC();
    
            t0->arg1 = goto_PRIMARY(root->children[0]) + "." + goto_IDENTIFIER(root->children[2]);
            t0->op = "call";
    
            threeACList.push_back(t0);
    
            // functionCallerRules(1);
    
            return t0;
    }
    // ARRAY_ACCESS: PRIMARY_NO_NEW_ARRAY LBRACKET EXPRESSION RBRACKET
    // ARRAY_ACCESS: NAME LBRACKET EXPRESSION RBRACKET
    else if (root->id == 430 || root->id == 433)
    {
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);
        threeAC *t2 = create3AC(root->children[2]);

        t0->res = t1->res + "[" + t2->res + "]";

        return t0;
    }
    // POSTFIX_EXPRESSION:
    // PRIMARY
    // { $$ = new ast("Postfix_Expression", 
    //     vector<class ast*>({$1}),
    //     436, $1->datatype);
    // }
    // | POST_INCREMENT_EXPRESSION
    // { $$ = new ast("Postfix_Expression", 
    //     vector<class ast*>({$1}),
    //     437, $1->datatype);
    // }
    // | POST_DECREMENT_EXPRESSION
    // { $$ = new ast("Postfix_Expression", 
    //     vector<class ast*>({$1}),
    //     438, $1->datatype);
    // }
    // | NAME
    // {   $$ = new ast("Postfix_Expression", 
    //     vector<class ast*>({$1}),
    //     439, $1->datatype);
    // }
    // ;
    else if(root->id == 436 || root->id == 439)
    {
        threeAC *t0 = new threeAC();
        if (root->id == 436)
        {
            t0 = create3AC(root->children[0]);
        }
        else if (root->id == 439)
        {
            t0->res = Stack.newReg();

            t0->arg1 = t0->res;
            t0->op = "mov";
            t0->arg2 = Stack.getVarName(goto_NAME(root->children[0]));

            threeACList.push_back(t0);

        }
        return t0;
    }
    else if(root->id == 437 || root->id == 438)
    {
        return create3AC(root->children[0]);
    }
    // POST_INCREMENT_EXPRESSION:
    // POSTFIX_EXPRESSION PLUSPLUS
    // { $$ = new ast("Post_Increment_Expression", 
    //     vector<class ast*>({$1, new ast("++",yylineno,441)}),
    //     440, $1->datatype);
    //     opt_count++;
    // }
    // ;
    else if (root->id == 440)
    {
        threeAC *t0 = create3AC(root->children[0]);

        threeAC *t1 = new threeAC();

        t1->arg1 = t0->res;
        t1->op = "inc";
        t1->res = t0->res;

        threeACList.push_back(t1);

        return t0;
    }
    // POST_DECREMENT_EXPRESSION:
    // POSTFIX_EXPRESSION MINUSMINUS
    // { $$ = new ast("Post_Decrement_Expression", 
    //     vector<class ast*>({$1 , new ast("--",yylineno,443)}),
    //     442, $1->datatype);
    //     opt_count++;
    // }
    // ;
    else if (root->id == 442)
    {
        threeAC *t0 = create3AC(root->children[0]);

        threeAC *t1 = new threeAC();

        t1->arg1 = t0->res;
        t1->op = "dec";
        t1->res = t0->res;

        threeACList.push_back(t1);

        return t0;
    }
    // UNARY_EXPRESSION:
    // PRE_INCREMENT_EXPRESSION
    // { $$ = new ast("Unary_Expression", 
    //     vector<class ast*>({$1}),
    //     444, $1->datatype);
    // }
    // | PRE_DECREMENT_EXPRESSION
    // { $$ = new ast("Unary_Expression", 
    //     vector<class ast*>({$1}),
    //     445, $1->datatype);
    // }
    // | PLUS UNARY_EXPRESSION
    // { $$ = new ast("Unary_Expression", 
    //     vector<class ast*>({new ast("+",yylineno,447),$2}),
    //     446, $2->datatype);
    //     opt_count++;
    // }
    // | MINUS UNARY_EXPRESSION
    // { $$ = new ast("Unary_Expression", 
    //     vector<class ast*>({new ast("-",yylineno,449),$2}),
    //     448, $2->datatype);
    //     opt_count++;
    // }
    // | UNARY_EXPRESSION_NOT_PLUS_MINUS
    // { $$ = new ast("Unary_Expression", 
    //     vector<class ast*>({$1}),
    //     450, $1->datatype);
    // }
    // ;
    else if (root->id == 444 || root->id == 445 || root->id == 446 || root->id == 450)
    {
        return create3AC(root->children[0]);
    }
    else if (root->id == 448)
    {
        threeAC *t0 = create3AC(root->children[1]);
        
        threeAC *t1 = new threeAC();

        t1->arg1 = t0->res;
        t1->op = "neg";
        t1->res = t0->res;

        threeACList.push_back(t1);

        return t0;
    }
    // PRE_INCREMENT_EXPRESSION:
    // PLUSPLUS UNARY_EXPRESSION
    // { $$ = new ast("Pre_Increment_Expression", 
    //     vector<class ast*>({new ast("++",yylineno,452), $2}),
    //     451, $2->datatype);
    // }
    // ;
    else if (root->id == 451)
    {
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1]);

        t0->arg1 = t1->res;
        t0->op = "inc";
        t0->res = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // PRE_DECREMENT_EXPRESSION:
    // MINUSMINUS UNARY_EXPRESSION
    // { $$ = new ast("Pre_Decrement_Expression", 
    //     vector<class ast*>({new ast("--",yylineno,454), $2}),
    //     453, $2->datatype);
    //     opt_count++;
    // }
    // ;
    else if (root->id == 453)
    {
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1]);

        t0->arg1 = t1->res;
        t0->op = "dec";
        t0->res = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // UNARY_EXPRESSION_NOT_PLUS_MINUS:
    // POSTFIX_EXPRESSION
    // { $$ = new ast("Unary_Expression_Not_Plus_Minus", 
    //     vector<class ast*>({$1}),
    //     455, $1->datatype);
    // }
    // | BANG UNARY_EXPRESSION
    // { $$ = new ast("Unary_Expression_Not_Plus_Minus", 
    //     vector<class ast*>({ new ast("!",yylineno,457), $2}),
    //     456, $2->datatype);
    //     opt_count++;
    // }
    // | TILDE UNARY_EXPRESSION
    // { $$ = new ast("Unary_Expression_Not_Plus_Minus", 
    //     vector<class ast*>({ new ast("~",yylineno,459), $2}),
    //     458, $2->datatype);
    //     opt_count++;
    // }
    // | CAST_EXPRESSION
    // { $$ = new ast("Unary_Expression_Not_Plus_Minus", 
    //     vector<class ast*>({$1}),
    //     460, $1->datatype);
    // }
    // ;
    else if (root->id == 455 || root->id == 460)
    {
        return create3AC(root->children[0]);
    }
    else if (root->id == 456)
    {
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[1]);

        t0->arg1 = t1->res;
        t0->op = "not";
        t0->res = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // UNARY_EXPRESSION_NOT_PLUS_MINUS: TILDE UNARY_EXPRESSION
    else if (root->id == 458)
    {
        threeAC *t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        // cout << root->id << "\n";
        threeAC *t1 = create3AC(root->children[1]);
        // cout << root->id << "\n";

        t0->op = "~";
        t0->arg2 = t1->res;

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE DIMS RPAREN UNARY_EXPRESSION
    else if (root->id == 461)
    {
        threeAC *t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1]);
        threeAC *t2 = create3AC(root->children[2]);
        // cout << root->id << "\n";
        threeAC *t3 = create3AC(root->children[4]);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + t2->res + "(" + t3->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN NAME DIMS RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS
    else if (root->id == 464)
    {
        threeAC *t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1]);
        threeAC *t2 = create3AC(root->children[2]);
        // cout << root->id << "\n";
        threeAC *t3 = create3AC(root->children[4]);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + t2->res + "(" + t3->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE RPAREN UNARY_EXPRESSION
    else if (root->id == 467)
    {
        threeAC *t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1]);
        // cout << root->id << "\n";
        threeAC *t2 = create3AC(root->children[3]);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + "(" + t2->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // CAST_EXPRESSION: LPAREN EXPRESSION RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS
    else if (root->id == 470)
    {
        threeAC *t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[1]);
        // cout << root->id << "\n";
        threeAC *t2 = create3AC(root->children[3]);
        // cout << root->id << "\n";

        t0->arg1 = "cast_to_" + t1->res + "(" + t2->res + ")";

        threeACList.push_back(t0);

        return t0;
    }
    // MULTIPLICATIVE_EXPRESSION:
    // MULTIPLICATIVE_EXPRESSION MUL UNARY_EXPRESSION
    // { $$ = new ast("Multiplicative_Expression", 
    //     vector<class ast*>({$1, new ast("*",yylineno,474), $3}),
    //     473, $1->datatype);
    //     opt_count++;
    // }
    // | MULTIPLICATIVE_EXPRESSION DIV UNARY_EXPRESSION
    // { $$ = new ast("Multiplicative_Expression", 
    //     vector<class ast*>({$1, new ast("/",yylineno,476), $3}),
    //     475, $1->datatype);
    //     opt_count++;
    // }
    // | MULTIPLICATIVE_EXPRESSION MOD UNARY_EXPRESSION
    // { $$ = new ast("Multiplicative_Expression", 
    //     vector<class ast*>({$1, new ast("%",yylineno,478), $3}),
    //     477, $1->datatype);
    //     opt_count++;
    // }
    // | UNARY_EXPRESSION
    // { $$ = new ast("Multiplicative_Expression", 
    //     vector<class ast*>({$1}),
    //     479, $1->datatype);
    // }
    // ;
    else if (root->id == 473)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = "rax";
        t3->op = "push";

        Stack.newVar("#t", 8);

        threeACList.push_back(t3);

        threeAC* t4 = new threeAC();

        t4->arg1 = "rax";
        t4->arg2 = t1->res;
        t4->op = "mov";

        threeACList.push_back(t4);

        t0->arg1 = t2->res;
        t0->op = "mul";

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        threeAC* t5 = new threeAC();

        t5->arg1 = t1->res;
        t5->arg2 = "rax";
        t5->op = "mov";

        threeACList.push_back(t5);

        threeAC* t6 = new threeAC();

        t6->arg1 = "rax";
        t6->op = "pop";

        threeACList.push_back(t6);

        Stack.removeVar("#t");

        return t1;
    }
    else if (root->id == 475)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = "rax";
        t3->op = "push";

        threeACList.push_back(t3);

        Stack.newVar("#t", 8);

        threeAC* t4 = new threeAC();

        t4->arg1 = "rax";
        t4->arg2 = t1->res;
        t4->op = "mov";

        threeACList.push_back(t4);

        t0->arg1 = t2->res;
        t0->op = "div";

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        threeAC* t5 = new threeAC();

        t5->arg1 = t1->res;
        t5->arg2 = "rax";
        t5->op = "mov";

        threeACList.push_back(t5);

        threeAC* t6 = new threeAC();

        t6->arg1 = "rax";
        t6->op = "pop";

        threeACList.push_back(t6);

        Stack.removeVar("#t");

        return t1;
    }
    else if (root->id == 477)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = "rax";
        t3->op = "push";

        threeACList.push_back(t3);

        Stack.newVar("#t", 8);

        threeAC* t4 = new threeAC();

        t4->arg1 = "rax";
        t4->arg2 = t1->res;
        t4->op = "mov";

        threeACList.push_back(t4);

        t0->arg1 = t2->res;
        t0->op = "div";

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        threeAC* t5 = new threeAC();

        t5->arg1 = t1->res;
        t5->arg2 = "rdx";
        t5->op = "mov";

        threeACList.push_back(t5);

        threeAC* t6 = new threeAC();

        t6->arg1 = "rax";
        t6->op = "pop";

        threeACList.push_back(t6);

        Stack.removeVar("#t");

        return t1;
    }
    else if (root->id == 479)
    {
        return create3AC(root->children[0]);
    }
    // ADDITIVE_EXPRESSION:
    // ADDITIVE_EXPRESSION PLUS MULTIPLICATIVE_EXPRESSION
    // { $$ = new ast("Additive_Expression", 
    //     vector<class ast*>({$1, new ast("+",yylineno,481),$3}),
    //     480, $1->datatype);
    //     opt_count++;
    // }
    // | ADDITIVE_EXPRESSION MINUS MULTIPLICATIVE_EXPRESSION
    // { $$ = new ast("Additive_Expression", 
    //     vector<class ast*>({$1, new ast("-",yylineno,483),$3}),
    //     482, $1->datatype);
    //     opt_count++;
    // }
    // | MULTIPLICATIVE_EXPRESSION
    // { $$ = new ast("Additive_Expression", 
    //     vector<class ast*>({$1}),
    //     484, $1->datatype);
    // }
    // ;
    else if (root->id == 480)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        t0->res = t1->res;
        t0->arg1 = t1->res;
        t0->op = "add";
        t0->arg2 = t2->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        return t0;
    }
    else if (root->id == 482)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        t0->res = t1->res;
        t0->arg1 = t1->res;
        t0->op = "sub";
        t0->arg2 = t2->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        return t0;
    }
    else if (root->id == 484)
    {
        return create3AC(root->children[0]);
    }
    // SHIFT_EXPRESSION:
    // SHIFT_EXPRESSION LEFT_SHIFT ADDITIVE_EXPRESSION
    // { $$ = new ast("Shift_Expression", 
    //     vector<class ast*>({$1, new ast("<<",yylineno,486),$3}),
    //     485, $1->datatype);
    //     opt_count++;
    // }
    // | SHIFT_EXPRESSION RIGHT_SHIFT ADDITIVE_EXPRESSION
    // { $$ = new ast("Shift_Expression", 
    //     vector<class ast*>({$1, new ast(">>",yylineno,488),$3}),
    //     487, $1->datatype);
    //     opt_count++;
    // }
    // | ADDITIVE_EXPRESSION
    // { $$ = new ast("Shift_Expression", 
    //     vector<class ast*>({$1}),
    //     489, $1->datatype);
    // }
    // | SHIFT_EXPRESSION UNSIGNED_RIGHT_SHIFT ADDITIVE_EXPRESSION
    // { $$ = new ast("Shift_Expression", 
    //     vector<class ast*>({$1, new ast(">>>",yylineno,491),$3}),
    //     490, $1->datatype);
    //     opt_count++;
    // }
    // ;
    else if (root->id == 485)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        t0->res = t1->res;
        t0->arg1 = t1->res;
        t0->op = "shl";
        t0->arg2 = t2->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        return t0;
    }
    else if (root->id == 487)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        t0->res = t1->res;
        t0->arg1 = t1->res;
        t0->op = "shr";
        t0->arg2 = t2->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        return t0;
    }
    else if (root->id == 489)
    {
        return create3AC(root->children[0]);
    }
    else if (root->id == 490)
    {
        // cout << root->id << "\n";
        threeAC *t0 = new threeAC();

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;

        threeAC *t1 = create3AC(root->children[0]);

        t0->arg1 = t1->res;
        t0->op = ">>>";

        threeAC *t2 = create3AC(root->children[2]);

        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        return t0;
    }
    // RELATIONAL_EXPRESSION:
    // RELATIONAL_EXPRESSION LESS SHIFT_EXPRESSION
    // { $$ = new ast("Relational_Expression", 
    //     vector<class ast*>({$1, new ast("<",yylineno,493),$3}),
    //     492, $1->datatype);
    //     opt_count++;
    // }
    // | RELATIONAL_EXPRESSION GREATER SHIFT_EXPRESSION
    // { $$ = new ast("Relational_Expression", 
    //     vector<class ast*>({$1, new ast(">",yylineno,495),$3}),
    //     494, $1->datatype);
    //     opt_count++;
    // }
    // | RELATIONAL_EXPRESSION LESS_EQUAL SHIFT_EXPRESSION
    // { $$ = new ast("Relational_Expression", 
    //     vector<class ast*>({$1, new ast("<=",yylineno,497),$3}),
    //     496, $1->datatype);
    //     opt_count++;
    // }
    // | RELATIONAL_EXPRESSION GREATER_EQUAL SHIFT_EXPRESSION
    // { $$ = new ast("Relational_Expression", 
    //     vector<class ast*>({$1, new ast(">=",yylineno,499),$3}),
    //     498, $1->datatype);
    //     opt_count++;
    // }
    // | SHIFT_EXPRESSION
    // { $$ = new ast("Relational_Expression", 
    //     vector<class ast*>({$1}),
    //     500, $1->datatype);
    // }
    // ;
    else if (root->id == 492)
    {
        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();
        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";
        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "cmp";
        t3->arg2 = t2->res;

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();

        t4->op = "jl";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        Stack.freeReg(t1->res);
        Stack.freeReg(t2->res);

        return t0;
    }
    else if (root->id == 494)
    {
        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();
        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";
        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "cmp";
        t3->arg2 = t2->res;

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();

        t4->op = "jg";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        Stack.freeReg(t1->res);
        Stack.freeReg(t2->res);

        return t0;
    }
    else if (root->id == 496)
    {
        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();
        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";
        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "cmp";
        t3->arg2 = t2->res;

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();

        t4->op = "jle";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        Stack.freeReg(t1->res);
        Stack.freeReg(t2->res);    

        return t0;
    }
    else if (root->id == 498)
    {
        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();
        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";
        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "cmp";
        t3->arg2 = t2->res;

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();

        t4->op = "jge";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        Stack.freeReg(t1->res);
        Stack.freeReg(t2->res);

        return t0;
    }
    else if(root->id == 500)
    {
        return create3AC(root->children[0]);
    }
    // EQUALITY_EXPRESSION:
    // EQUALITY_EXPRESSION EQEQ RELATIONAL_EXPRESSION
    // { $$ = new ast("Equality_Expression", 
    //     vector<class ast*>({$1, new ast("==",yylineno,502),$3}),
    //     501, $1->datatype);
    //     opt_count++;
    // }
    // | EQUALITY_EXPRESSION NOT_EQUAL RELATIONAL_EXPRESSION
    // { $$ = new ast("Equality_Expression", 
    //     vector<class ast*>({$1, new ast("!=",yylineno,504),$3}),
    //     503, $1->datatype);
    //     opt_count++;
    // }
    // | RELATIONAL_EXPRESSION
    // { $$ = new ast("Equality_Expression", 
    //     vector<class ast*>({$1}),
    //     505, $1->datatype);
    // }
    // ;
    else if (root->id == 501)
    {
        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();
        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";
        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "cmp";
        t3->arg2 = t2->res;

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();

        t4->op = "je";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        Stack.freeReg(t1->res);
        Stack.freeReg(t2->res);

        return t0;
    }
    else if (root->id == 503)
    {
        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();
        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";

        threeACList.push_back(t0);

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "cmp";
        t3->arg2 = t2->res;

        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();

        t4->op = "jne";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        Stack.freeReg(t1->res);
        Stack.freeReg(t2->res);

        return t0;
    }
    else if(root->id == 505)
    {
        return create3AC(root->children[0]);
    }
    // AND_EXPRESSION:
    // AND_EXPRESSION AND EQUALITY_EXPRESSION
    // { $$ = new ast("And_Expression", 
    //     vector<class ast*>({$1, new ast("&",yylineno,507),$3}),
    //     506, $1->datatype);
    //     opt_count++;
    // }
    // | EQUALITY_EXPRESSION
    // { $$ = new ast("And_Expression", 
    //     vector<class ast*>({$1}),
    //     508, $1->datatype);
    // }
    // ;
    else if (root->id == 506)
    {
        // cout << "512\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        t0->arg1 = t1->res;
        t0->op = "and";
        t0->arg2 = t2->res;
        t0->res = t1->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        return t0;
    }
    else if(root->id == 508)
    {
        return create3AC(root->children[0]);
    }
    // EXCLUSIVE_OR_EXPRESSION: 
    // EXCLUSIVE_OR_EXPRESSION XOR AND_EXPRESSION
    // { $$ = new ast("Exclusive_Or_Expression", 
    //     vector<class ast*>({$1, new ast("^",yylineno,510),$3}),
    //     509, $1->datatype);
    //     opt_count++;
    // }
    // | AND_EXPRESSION
    // { $$ = new ast("Exclusive_Or_Expression", 
    //     vector<class ast*>({$1}),
    //     511, $1->datatype);
    // }
    // ;
    else if (root->id == 509)
    {
        // cout << "512\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        t0->arg1 = t1->res;
        t0->op = "xor";
        t0->arg2 = t2->res;
        t0->res = t1->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        return t0;
    }
    else if (root->id == 511)
    {
        return create3AC(root->children[0]);
    }
    // INCLUSIVE_OR_EXPRESSION:
    // INCLUSIVE_OR_EXPRESSION OR EXCLUSIVE_OR_EXPRESSION
    // { $$ = new ast("Inclusive_Or_Expression", 
    //     vector<class ast*>({$1, new ast("|",yylineno,513),$3}),
    //     512, $1->datatype);
    //     opt_count++;
    // }
    // | EXCLUSIVE_OR_EXPRESSION
    // { $$ = new ast("Inclusive_Or_Expression", 
    //     vector<class ast*>({$1}),
    //     514, $1->datatype);
    // }
    // ;
    else if (root->id == 512)
    {
        // cout << "512\n";
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        t0->arg1 = t1->res;
        t0->op = "or";
        t0->arg2 = t2->res;
        t0->res = t1->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t0);

        return t0;
    }
    else if (root->id == 514)
    {
        return create3AC(root->children[0]);
    }
    // CONDITIONAL_AND_EXPRESSION:
    // CONDITIONAL_AND_EXPRESSION ANDAND INCLUSIVE_OR_EXPRESSION
    // { $$ = new ast("Conditional_And_Expression", 
    //     vector<class ast*>({$1, new ast("&&",yylineno,516),$3}),
    //     515, $1->datatype);
    //     opt_count++;
    // }
    // | INCLUSIVE_OR_EXPRESSION
    // { $$ = new ast("Conditional_And_Expression", 
    //     vector<class ast*>({$1}),
    //     517, $1->datatype);
    // }
    // ;
    else if (root->id == 515)
    {
        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "and";
        t3->arg2 = t2->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t3);

        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();

        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";

        threeACList.push_back(t0);

        threeAC *t7 = new threeAC();

        t7->arg1 = t1->res;
        t7->op = "cmp";
        t7->arg2 = "0";

        Stack.freeReg(t1->res);

        threeACList.push_back(t7);

        threeAC *t4 = new threeAC();

        t4->op = "jne";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        return t0;
    }
    else if (root->id == 517)
    {
        return create3AC(root->children[0]);
    }
    // CONDITIONAL_OR_EXPRESSION:
    // CONDITIONAL_OR_EXPRESSION OROR CONDITIONAL_AND_EXPRESSION
    // { $$ = new ast("Conditional_Or_Expression", 
    //     vector<class ast*>({$1,new ast("||",yylineno,519), $3}),
    //     518, $1->datatype);
    //     opt_count++;
    // }
    // | CONDITIONAL_AND_EXPRESSION
    // { $$ = new ast("Conditional_Or_Expression", 
    //     vector<class ast*>({$1}),
    //     520, $1->datatype);
    // }
    // ;
    else if (root->id == 518)
    {
        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = new threeAC();

        t3->arg1 = t1->res;
        t3->op = "or";
        t3->arg2 = t2->res;

        Stack.freeReg(t2->res);

        threeACList.push_back(t3);

        threeAC *t0 = new threeAC();

        t0->res = Stack.newReg();

        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = "1";

        threeACList.push_back(t0);

        threeAC *t7 = new threeAC();

        t7->arg1 = t1->res;
        t7->op = "cmp";
        t7->arg2 = "0";

        Stack.freeReg(t1->res);

        threeACList.push_back(t7);

        threeAC *t4 = new threeAC();

        t4->op = "jne";
        t4->arg1 = "L_" + to_string(l_cnt);
        l_cnt++;

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->arg1 = t0->res;
        t5->op = "mov";
        t5->arg2 = "0";

        threeACList.push_back(t5);

        threeAC *t6 = new threeAC();

        t6->label = t4->arg1;
        t6->is_label = true;

        threeACList.push_back(t6);

        return t0;
    }
    else if (root->id == 520)
    {
        return create3AC(root->children[0]);
    }
    // CONDITIONAL_EXPRESSION:
    // CONDITIONAL_OR_EXPRESSION QMARK EXPRESSION COLON CONDITIONAL_EXPRESSION
    // { $$ = new ast("Conditional_Expression", 
    //     vector<class ast*>({$1, new ast("?",yylineno,522),$3, new ast(":",yylineno,523),$5}),
    //     521, $1->datatype);
    //     opt_count++;
    //     sep_count++;
    // }
    // | CONDITIONAL_OR_EXPRESSION
    // { $$ = new ast("Conditional_Expression", 
    //     vector<class ast*>({$1}),
    //     524, $1->datatype);
    // }
    // ;
    else if (root->id == 521)
    {
        threeAC *t0 = new threeAC();

        threeAC *t1 = create3AC(root->children[0]);

        threeAC *t2 = create3AC(root->children[2]);

        threeAC *t3 = create3AC(root->children[4]);

        int if_cnt_t0 = if_cnt;
        if_cnt++;

        t0->res = "#t_" + to_string(t_cnt);
        t_cnt++;
        t0->arg1 = t0->res;
        t0->op = "mov";
        t0->arg2 = t2->res;

        threeACList.push_back(t0);

        threeAC *t4 = new threeAC();
        
        t4->op = "cmp";
        t4->arg1 = t1->res;
        t4->arg2 = "1";

        threeACList.push_back(t4);

        threeAC *t5 = new threeAC();

        t5->op = "je";
        t5->arg1 = "if_" + to_string(if_cnt_t0);

        threeACList.push_back(t5);

        threeAC *t7 = new threeAC();

        t7->arg1 = t0->res;
        t7->op = "mov";
        t7->arg2 = t3->res;

        threeACList.push_back(t7);

        threeAC *t6 = new threeAC();

        t6->label = "if_" + to_string(if_cnt_t0);
        t6->is_label = true;

        threeACList.push_back(t6);

        return t0;
    }
    else if (root->id == 524)
    {
        return create3AC(root->children[0]);
    }
    // ASSIGNMENT_EXPRESSION:
    //  ASSIGNMENT
    //  {
    //     $$ = new ast("Assignment_Expression", 
    //     vector<class ast*>({$1}),
    //     525, $1->datatype);
    //  }
    // | CONDITIONAL_EXPRESSION
    // { $$ = new ast("Assignment_Expression", 
    //     vector<class ast*>({$1}),
    //     526, $1->datatype);
    // }
    // ;
    else if (root->id == 525 || root->id == 526)
    {
        return create3AC(root->children[0]);
    }
    // ASSIGNMENT:
    // LEFT_HAND_SIDE ASSIGNMENT_OPERATOR ASSIGNMENT_EXPRESSION
    // { $$ = new ast("Assignment", 
    //     vector<class ast*>({$1, $2, $3}),
    //     527, $1->datatype);
    // }
    // ;
    else if (root->id == 527)
    {
        threeAC *t0 = create3AC(root->children[2]);

        threeAC *t1 = new threeAC();

        t1->res = goto_LEFT_HAND_SIDE(root->children[0]);
        t1->arg1 = Stack.getVarName(t1->res);
        t1->op = "mov";
        t1->arg2 = t0->res;
        // ASSIGNMENT_OPERATOR: MUL_ASSIGN
        if (root->children[1]->id == 533)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t2->op = "mul";
            t2->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: DIV_ASSIGN
        else if (root->children[1]->id == 535)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t2->op = "div";
            t2->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: MOD_ASSIGN
        else if (root->children[1]->id == 537)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t2->op = "mod";
            t2->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: ADD_ASSIGN
        else if (root->children[1]->id == 539)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t2->op = "add";
            t2->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: SUB_ASSIGN
        else if (root->children[1]->id == 541)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t2->op = "sub";
            t2->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: LEFT_ASSIGN
        else if (root->children[1]->id == 543)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t2->op = "shl";
            t2->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: RIGHT_ASSIGN
        else if (root->children[1]->id == 545)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t2->op = "shr";
            t2->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: AND_ASSIGN
        else if (root->children[1]->id == 547)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t0->op = "and";
            t0->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: XOR_ASSIGN
        else if (root->children[1]->id == 549)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t0->op = "xor";
            t0->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }
        // ASSIGNMENT_OPERATOR: OR_ASSIGN
        else if (root->children[1]->id == 551)
        {
            threeAC *t2 = new threeAC();

            t2->res = t0->res;
            t2->arg1 = t0->res;
            t0->op = "or";
            t0->arg2 = t1->arg1;

            threeACList.push_back(t2);
        }

        threeACList.push_back(t1);

        Stack.freeReg(t0->res);

        return t1;
    }
    // LEFT_HAND_SIDE:
    // NAME
    // { $$ = new ast("Left_Hand_Side", 
    //     vector<class ast*>({$1}),
    //     528, $1->datatype);
    // }
    // | FIELD_ACCESS
    // { $$ = new ast("Left_Hand_Side", 
    //     vector<class ast*>({$1}),
    //     529, $1->datatype);
    // }
    // | ARRAY_ACCESS
    // { $$ = new ast("Left_Hand_Side", 
    //     vector<class ast*>({$1}),
    //     530, $1->datatype);
    // }
    // ;
    else if (root->id == 528 || root->id == 529 || root->id == 530)
    {
        return create3AC(root->children[0]);
    }
    // EXPRESSION:
    // ASSIGNMENT_EXPRESSION
    // { $$ = new ast("Expression", 
    //     vector<class ast*>({$1}),
    //     553, $1->datatype);
    // }
    // ;
    else if(root->id == 553){
        return create3AC(root->children[0]);
    }
    else
    {
        threeAC *t0 = new threeAC();
        for (auto u : root->children)
            t0 = create3AC(u);
        return t0;
    }
}

void dumpThreeAC(FILE *out)
{
    for (auto u : threeACList)
    {
        if (u->is_label)
            fprintf(out, "%s:\n", u->label.c_str());
        else{
            if(u->op == "mov")
                fprintf(out, "\tmov %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "push")
                fprintf(out, "\tpush %s\n", u->arg1.c_str());
            else if(u->op == "pop")
                fprintf(out, "\tpop %s\n", u->arg1.c_str());
            else if(u->op == "lea")
                fprintf(out, "\tlea %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "add")
                fprintf(out, "\tadd %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "sub")
                fprintf(out, "\tsub %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "inc")
                fprintf(out, "\tinc %s\n", u->arg1.c_str());
            else if(u->op == "dec")
                fprintf(out, "\tdec %s\n", u->arg1.c_str());
            else if(u->op == "mul")
                fprintf(out, "\tmul %s\n", u->arg1.c_str());
            else if(u->op == "div")
                fprintf(out, "\tdiv %s\n", u->arg1.c_str());
            else if(u->op == "mod")
                fprintf(out, "\tmod %s\n", u->arg1.c_str());
            else if(u->op == "and")
                fprintf(out, "\tand %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "or")
                fprintf(out, "\tor %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "xor")
                fprintf(out, "\txor %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "not")
                fprintf(out, "\tnot %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "cmp")
                fprintf(out, "\tcmp %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "shl")
                fprintf(out, "\tshl %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "shr")
                fprintf(out, "\tshr %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "jmp")
                fprintf(out, "\tjmp %s\n", u->arg1.c_str());
            else if(u->op == "je")
                fprintf(out, "\tje %s\n", u->arg1.c_str());
            else if(u->op == "jne")
                fprintf(out, "\tjne %s\n", u->arg1.c_str());
            else if(u->op == "jg")
                fprintf(out, "\tjg %s\n", u->arg1.c_str());
            else if(u->op == "jge")
                fprintf(out, "\tjge %s\n", u->arg1.c_str());
            else if(u->op == "jl")
                fprintf(out, "\tjl %s\n", u->arg1.c_str());
            else if(u->op == "jle")
                fprintf(out, "\tjle %s\n", u->arg1.c_str());
            else if(u->op == "cmp")
                fprintf(out, "\tcmp %s %s\n", u->arg1.c_str(), u->arg2.c_str());
            else if(u->op == "call")
                fprintf(out, "\tcall %s\n", u->arg1.c_str());
            else if(u->op == "ret")
                fprintf(out, "\tret\n");
        }
    }
    return;
}