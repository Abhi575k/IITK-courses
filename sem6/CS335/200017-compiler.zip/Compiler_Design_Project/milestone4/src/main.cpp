#include "commandline.h"
#include "codegen.h"

// 3ac.h
threeAC *tac;
vector<threeAC *> threeACList;

// 3acstack.h
threeACStack Stack;

// ast.h
void yyerror(char *s){
    printf("Error at line %d: %s\n", yylineno, s);
}
void yyerror(char *s, int lineno){
    printf("Error at line %d: %s\n", lineno, s);
}

int cnt;
int key_count, sep_count, opt_count, id_count, lit_count;
ast *parse_tree_root;

// symboltable.h
SymbolTable *symbol_table_root;

// 3ac and assembly code output file
FILE *out;



int main(int argc, char **argv){
    cnt = 0;
    key_count = 0, opt_count = 0, id_count = 0, sep_count = 0, lit_count = 0;

    bool print_ast = false;
    bool verbose = false;
    bool output_symbol_table = false;
    string ast_output_file = "";
    string input_file = "";
    string symbol_table_output_folder = "";
    string tac_output_file = "";

    if(!checkArguements(argc, argv)){
        printError();
        printUsage();
        return 0;
    }

    if(checkHelp(argc, argv)){
        printUsage();
        return 0;
    }

    if(printAst(argc, argv, ast_output_file)){
        print_ast = true;
        yyout = fopen(ast_output_file.c_str(), "w");
        if(yyout == NULL){
            printError();
            printUsage();
            return 0;
        }
    }

    if(checkInput(argc, argv, input_file)){
        yyin = fopen(input_file.c_str(), "r");
        if(yyin == NULL){
            printError();
            printUsage();
            return 0;
        }
    }else{
        printError();
        printUsage();
        return 0;
    }

    if(checkOutput(argc, argv, tac_output_file)){
        out = fopen(tac_output_file.c_str(), "w");
        if(out == NULL){
            printError();
            printUsage();
            return 0;
        }
    }else{
        printError();
        printUsage();
        return 0;
    }

    if(checkVerbose(argc, argv)){
        verbose = true;
    }

    if(checkSymbolTable(argc, argv, symbol_table_output_folder)){
        output_symbol_table = true;
    }
    
    if(print_ast) fprintf(yyout, "digraph G{\n");
    yyparse();
    if(parse_tree_root==NULL) printf("Empty Program\n");
    else{
        parse_tree_root->sendTypes();
        if(print_ast) parse_tree_root->printtree(yyout);
        symbol_table_root = new SymbolTable(NULL,"Global Table");
        parse_tree_root->st = symbol_table_root;
        createSymbolTable(parse_tree_root, symbol_table_root);
        if(output_symbol_table) symbol_table_root->dumpSymbolTable(symbol_table_output_folder);
        if(verbose) symbol_table_root->printTableTree(0);
        if(verbose) symbol_table_root->printTable();
    }
    if(print_ast) fprintf(yyout, "}");
    fclose(yyin);
    if(print_ast) fclose(yyout);
    
    if(verbose) printAstVerbose();

    tac = create3AC(parse_tree_root);

    // for (auto u: threeACList){
    //     u->print();
    // }

    // dumpThreeAC(out);
    x86_codegen(out);

    Stack.print();

    return 0;
}