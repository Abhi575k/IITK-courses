#include "typecheck.h"

int getDimsCount(ast *ast_root){
    // TYPE: REFERENCE_TYPE
    if(ast_root->id == 11){
        return getDimsCount(ast_root->children[0]);
    }
    // REFERENCE_TYPE: ARRAY_TYPE
    else if(ast_root->id == 25){
        return getDimsCount(ast_root->children[0]);
    }
    // ARRAY_TYPE: PRIMITIVE_TYPE DIMS
    else if(ast_root->id == 29){
        return get_DIMS_dims(ast_root->children[1]);
    }
    // ARRAY_TYPE: NAME DIMS
    else if(ast_root->id == 30){
        return get_DIMS_dims(ast_root->children[1]);
    }
    // ARRAY_TYPE: ARRAY_TYPE DIMS
    else if(ast_root->id == 31){
        return get_DIMS_dims(ast_root->children[1]);
    }
    return 0;
}

int get_DIMS_dims(ast *ast_root){
    // DIMS: LBRACKET RBRACKET
    if(ast_root->id == 402){
        return 1;
    }
    // DIMS: DIMS LBRACKET RBRACKET
    else if(ast_root->id == 405){
        return 1 + getDimsCount(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_DIMS_dims() called with wrong ast_root->id\n";
        return 0;
    }
}

string get_METHOD_HEADER_name(ast *ast_root){
    // MODIFIERS TYPE METHOD_DECLARATOR
    if (ast_root->id == 124){
        return get_METHOD_DECLARATOR_name(ast_root->children[2]);
    }
    // TYPE METHOD_DECLARATOR
    else if (ast_root->id == 126){
        return get_METHOD_DECLARATOR_name(ast_root->children[1]);
    }
    // MODIFIERS VOID METHOD_DECLARATOR
    else if (ast_root->id == 129){
        return get_METHOD_DECLARATOR_name(ast_root->children[2]);
    }
    // VOID METHOD_DECLARATOR
    else if (ast_root->id == 133){
        return get_METHOD_DECLARATOR_name(ast_root->children[1]);
    }
    else{
        cout << "[!!] Implementation error, get_METHOD_HEADER_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_METHOD_DECLARATOR_name(ast *ast_root){
    // IDENTIFIER LPAREN FORMAL_PARAMETER_LIST RPAREN
    if (ast_root->id == 135){
        return ast_root->children[0]->label;
    }
    // IDENTIFIER LPAREN RPAREN
    else if (ast_root->id == 139){
        return ast_root->children[0]->label;
    }
    // IDENTIFIER LBRACKET RBRACKET LPAREN FORMAL_PARAMETER_LIST RPAREN
    else if (ast_root->id == 557){
        return ast_root->children[0]->label;
    }
    // IDENTIFIER LBRACKET RBRACKET LPAREN RPAREN
    else if (ast_root->id == 563){
        return ast_root->children[0]->label;
    }
    else{
        cout << "[!!] Implementation error, get_METHOD_DECLARATOR_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_TYPE_type(ast *ast_root){
    // TYPE: PRIMITIVE_TYPE
    if(ast_root->id == 10){
        return get_TYPE_type(ast_root->children[0]);
    }
    // TYPE: REFERENCE_TYPE
    else if(ast_root->id == 11){
        return get_TYPE_type(ast_root->children[0]);
    }
    // PRIMITIVE_TYPE: NUMERIC_TYPE
    else if(ast_root->id == 12){
        return get_TYPE_type(ast_root->children[0]);
    }
    // PRIMITIVE_TYPE: BOOLEAN
    else if(ast_root->id == 13){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: INT
    else if(ast_root->id == 15){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: FLOAT
    else if(ast_root->id == 17){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: LONG
    else if(ast_root->id == 19){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: DOUBLE
    else if(ast_root->id == 21){
        return ast_root->children[0]->label;
    }
    // REFERENCE_TYPE: CLASS_OR_INTERFACE_TYPE
    else if(ast_root->id == 24){
        return get_TYPE_type(ast_root->children[0]);
    }
    // REFERENCE_TYPE: ARRAY_TYPE
    else if(ast_root->id == 25){
        return get_TYPE_type(ast_root->children[0]);
    }
    // CLASS_OR_INTERFACE_TYPE: NAME
    else if(ast_root->id == 26){
        return get_NAME_name(ast_root->children[0]);
    }
    // ARRAY_TYPE: PRIMITIVE_TYPE DIMS
    else if(ast_root->id == 29){
        return get_TYPE_type(ast_root->children[0]);
    }
    // ARRAY_TYPE: NAME DIMS
    else if(ast_root->id == 30){
        return get_NAME_name(ast_root->children[0]);
    }
    // ARRAY_TYPE: ARRAY_TYPE DIMS
    else if(ast_root->id == 31){
        return get_TYPE_type(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_TYPE_type() called with wrong ast_root->id\n";
        return "";
    }
}

string get_NAME_name(ast *ast_root){
    // SIMPLE_NAME
    if(ast_root->id == 32){
        return get_NAME_name(ast_root->children[0]);
    }
    // QUALIFIED NAME
    else if(ast_root->id == 33){
        return get_NAME_name(ast_root->children[0]) + "." + get_NAME_name(ast_root->children[2]);
    }
    // SIMPLE_NAME: IDENTIFIER
    else if(ast_root->id == 35){
        return ast_root->children[0]->label;
    }
    else{
        cout << "[!!] Implementation error, get_NAME_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_VARIABLE_DECLARATOR_ID_name(ast *ast_root){
    // VARIABLE_DECLARATOR_ID: IDENTIFIER
    if(ast_root->id == 115){
        return ast_root->children[0]->label;
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET RBRACKET
    else if(ast_root->id == 117){
        return get_VARIABLE_DECLARATOR_ID_name(ast_root->children[0]);
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET EXPRESSION RBRACKET
    else if(ast_root->id == 554){
        return get_VARIABLE_DECLARATOR_ID_name(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_VARIABLE_DECLARATOR_ID_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_LEFT_HAND_SIDE_name(ast *ast_root){
    // NAME
    if(ast_root->id == 528){
        return get_NAME_name(ast_root->children[0]);
    }
    // FIELD_ACCESS
    else if(ast_root->id == 529){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    // ARRAY_ACCESS
    else if(ast_root->id == 530){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    // FIELD_ACCESS: PRIMARY DOT IDENTIFIER
    else if(ast_root->id == 408){
        return get_PRIMARY_name(ast_root->children[0]) + "." + ast_root->children[2]->label;
    }
    // ARRAY_ACCESS: PRIMARY LBRACKET EXPRESSION RBRACKET
    else if(ast_root->id == 430){
        return get_PRIMARY_name(ast_root->children[0]);
    }
    // ARRAY_ACCESS: NAME LBRACKET EXPRESSION RBRACKET
    else if(ast_root->id == 433){
        return get_NAME_name(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_LEFT_HAND_SIDE_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_PRIMARY_name(ast *ast_root){
    // PRIMARY_NO_NEW_ARRAY
    if(ast_root->id == 368){
        return get_PRIMARY_name(ast_root->children[0]);
    }
    // PRIMARY_NO_NEW_ARRAY: FIELD_ACCESS
    else if(ast_root->id == 375){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    // PRIMARY_NO_NEW_ARRAY: ARRAY_ACCESS
    else if(ast_root->id == 376){
        return get_LEFT_HAND_SIDE_name(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_PRIMARY_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_CLASS_TYPE_name(ast *ast_root){
    // CLASS_TYPE: CLASS_OR_INTERFACE_TYPE
    if(ast_root->id == 27){
        return get_CLASS_TYPE_name(ast_root->children[0]);
    }
    // CLASS_OR_INTERFACE_TYPE: NAME 
    else if(ast_root->id == 26){
        return get_NAME_name(ast_root->children[0]);
    }
    else{
        cout << "[!!] Implementation error, get_CLASS_TYPE_name() called with wrong ast_root->id\n";
        return "";
    }
}

string get_FIELD_ACCESS_name(ast *ast_root){
    // FIELD_ACCESS: PRIMARY DOT IDENTIFIER
    if(ast_root->id == 408){
        return get_PRIMARY_name(ast_root->children[0]) + "." + ast_root->children[2]->label;
    }
    else{
        cout << "[!!] Implementation error, get_FIELD_ACCESS_name() called with wrong ast_root->id\n";
    }
}

string goto_IDENTIFIER(ast* root){
    return root->label;
}

// LITERAL: INTEGERLITERAL|LONGLITERAL|FLOATLITERAL|DOUBLELITERAL|BOOLEANLITERAL
string goto_LITERAL(ast* root){
    return root->children[0]->label;
}

// TYPE: PRIMITIVE_TYPE|REFERENCE_TYPE
string goto_TYPE(ast* root){
    switch(root->id){
        case 10:
            return goto_PRIMITIVE_TYPE(root->children[0]);
        case 11:
            return goto_REFERENCE_TYPE(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_TYPE() called with wrong root->id\n";
            return "";
    }
}

// PRIMITIVE_TYPE:NUMERIC_TYPE| BOOLEAN
string goto_PRIMITIVE_TYPE(ast* root){
    switch(root->id){
        case 12:
            return goto_NUMERIC_TYPE(root->children[0]);
        case 13:
            return "bool";
        default:
            cout << "[!!] Implementation error, goto_PRIMITIVE_TYPE() called with wrong root->id\n";
            return "";
    }
}

// NUMERIC_TYPE:INT| FLOAT| LONG| DOUBLE
string goto_NUMERIC_TYPE(ast* root){
    switch(root->id){
        case 15:
            return "int";
        case 17:
            return "float";
        case 19:
            return "long";
        case 21:
            return "double";
        default:
            cout << "[!!] Implementation error, goto_NUMERIC_TYPE() called with wrong root->id\n";
            return "";
    }
}

// REFERENCE_TYPE: CLASS_OR_INTERFACE_TYPE| ARRAY_TYPE
string goto_REFERENCE_TYPE(ast* root){
    switch(root->id){
        case 24:
            return goto_CLASS_OR_INTERFACE_TYPE(root->children[0]);
        case 25:
            return goto_ARRAY_TYPE(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_REFERENCE_TYPE() called with wrong root->id\n";
            return "";
    }
}

// CLASS_OR_INTERFACE_TYPE: NAME
string goto_CLASS_OR_INTERFACE_TYPE(ast* root){
    switch(root->id){
        case 26:
            return goto_NAME(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_CLASS_OR_INTERFACE_TYPE() called with wrong root->id\n";
            return "";
    }
}

// CLASS_TYPE:CLASS_OR_INTERFACE_TYPE
string goto_CLASS_TYPE(ast* root){
    switch(root->id){
        case 27:
            return goto_CLASS_OR_INTERFACE_TYPE(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_CLASS_TYPE() called with wrong root->id\n";
            return "";
    }
}

// ARRAY_TYPE: PRIMITIVE_TYPE DIMS| NAME DIMS| ARRAY_TYPE DIMS
string goto_ARRAY_TYPE(ast* root){
    switch(root->id){
        case 29:
            return goto_PRIMITIVE_TYPE(root->children[0]) + goto_DIMS(root->children[1]);
        case 30:
            return goto_NAME(root->children[0]) + goto_DIMS(root->children[1]);
        case 31:
            return goto_ARRAY_TYPE(root->children[0]) + goto_DIMS(root->children[1]);
        default:
            cout << "[!!] Implementation error, goto_ARRAY_TYPE() called with wrong root->id\n";
            return "";
    }
}

// NAME: SIMPLE_NAME| QUALIFIED_NAME
string goto_NAME(ast* root){
    switch(root->id){
        case 32:
            return goto_SIMPLE_NAME(root->children[0]);
        case 33:
            return goto_QUALIFIED_NAME(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_NAME() called with wrong root->id\n";
            return "";
    }
}

// SIMPLE_NAME: IDENTIFIER
string goto_SIMPLE_NAME(ast* root){
    switch(root->id){
        case 35:
            return goto_IDENTIFIER(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_SIMPLE_NAME() called with wrong root->id\n";
            return "";
    }
}

// QUALIFIED_NAME: NAME DOT IDENTIFIER
string goto_QUALIFIED_NAME(ast* root){
    switch(root->id){
        case 36:
            return goto_NAME(root->children[0]) + "." + goto_IDENTIFIER(root->children[2]);
        default:
            cout << "[!!] Implementation error, goto_QUALIFIED_NAME() called with wrong root->id\n";
            return "";
    }
}

// CLASS_DECLARATION: CLASS IDENTIFIER CLASS_BODY| MODIFIERS CLASS IDENTIFIER CLASS_BODY
string goto_CLASS_DECLARATION(ast* root){
    switch(root->id){
        case 79:
            return root->children[1]->label;
        case 82:
            return root->children[2]->label;
        default:
            cout << "[!!] Implementation error, goto_CLASS_DECLARATION() called with wrong root->id\n";
            return "";
    }
}

// FIELD_DECLARATION: MODIFIERS TYPE VARIABLE_DECLARATORS SEMICOLON | TYPE VARIABLE_DECLARATORS SEMICOLON
string goto_FIELD_DECLARATION(ast* root){
    switch(root->id){
        case 105:
            return goto_TYPE(root->children[1]);
        case 107:
            return goto_TYPE(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_FIELD_DECLARATION() called with wrong root->id\n";
            return "";
    }
}

// VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID| VARIABLE_DECLARATOR_ID ASSIGN VARIABLE_INITIALIZER
string goto_VARIABLE_DECLARATOR(ast* root){
    switch(root->id){
        case 112:
            return goto_VARIABLE_DECLARATOR_ID(root->children[0]);
        case 113:
            return goto_VARIABLE_DECLARATOR_ID(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_VARIABLE_DECLARATOR() called with wrong root->id\n";
            return "";
    }
}

// VARIABLE_DECLARATOR_ID: IDENTIFIER| VARIABLE_DECLARATOR_ID LBRACKET RBRACKET| VARIABLE_DECLARATOR_ID LBRACKET EXPRESSION RBRACKET
string goto_VARIABLE_DECLARATOR_ID(ast* root){
    switch(root->id){
        case 115:
            return goto_IDENTIFIER(root->children[0]);
        case 117:
            return goto_VARIABLE_DECLARATOR_ID(root->children[0]) + "[]";
        case 554:
            return goto_VARIABLE_DECLARATOR_ID(root->children[0]) + "[]";
        default:
            cout << "[!!] Implementation error, goto_VARIABLE_DECLARATOR_ID() called with wrong root->id\n";
            return "";
    }
}

// METHOD_DECLARATION: METHOD_HEADER METHOD_BODY
string goto_METHOD_DECLARATION(ast* root){
    switch(root->id){
        case 122:
            return goto_METHOD_HEADER(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_METHOD_DECLARATION() called with wrong root->id\n";
            return "";
    }
}

// METHOD_HEADER: MODIFIERS TYPE METHOD_DECLARATOR| TYPE METHOD_DECLARATOR| MODIFIERS VOID METHOD_DECLARATOR| VOID METHOD_DECLARATOR

string goto_METHOD_HEADER(ast* root){
    switch(root->id){
        case 124:
            return goto_METHOD_DECLARATOR(root->children[2]);
        case 126:
            return goto_METHOD_DECLARATOR(root->children[1]);
        case 129:
            return goto_METHOD_DECLARATOR(root->children[2]);
        case 133:
            return goto_METHOD_DECLARATOR(root->children[1]);
        default:
            cout << "[!!] Implementation error, goto_METHOD_HEADER() called with wrong root->id\n";
            return "";
    }
}

// METHOD_DECLARATOR:IDENTIFIER LPAREN FORMAL_PARAMETER_LIST RPAREN| IDENTIFIER LPAREN RPAREN

string goto_METHOD_DECLARATOR(ast* root){
    switch(root->id){
        case 135:
            return goto_IDENTIFIER(root->children[0]);
        case 139:
            return goto_IDENTIFIER(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_METHOD_DECLARATOR() called with wrong root->id\n";
            return "";
    }
}

// CONSTRUCTOR_DECLARATION: MODIFIERS CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY | CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY
string goto_CONSTRUCTOR_DECLARATION(ast* root){
    switch(root->id){
        case 161:
            return goto_CONSTRUCTOR_DECLARATOR(root->children[1]);
        case 163:
            return goto_CONSTRUCTOR_DECLARATOR(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_CONSTRUCTOR_DECLARATION() called with wrong root->id\n";
            return "";
    }
}

// CONSTRUCTOR_DECLARATOR: SIMPLE_NAME LPAREN FORMAL_PARAMETER_LIST RPAREN
string goto_CONSTRUCTOR_DECLARATOR(ast* root){
    switch(root->id){
        case 164:
            return goto_SIMPLE_NAME(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_CONSTRUCTOR_DECLARATOR() called with wrong root->id\n";
            return "";
    }
}

// PRIMARY:
//     PRIMARY_NO_NEW_ARRAY
//     { $$ = new ast("Primary", 
//         vector<class ast*>({$1}),
//         368, $1->datatype);
//     }
//     | ARRAY_CREATION_EXPRESSION
//     { $$ = new ast("Primary", 
//         vector<class ast*>({$1}),
//         369, $1->datatype);
//     }
//     ;

string goto_PRIMARY(ast* root){
    switch(root->id){
        case 368:
            return goto_PRIMARY_NO_NEW_ARRAY(root->children[0]);
        // case 369:
        //     return goto_ARRAY_CREATION_EXPRESSION(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_PRIMARY() called with wrong root->id\n";
            return "";
    }
}

// PRIMARY_NO_NEW_ARRAY:
//     LITERAL
//     { $$ = new ast("Primary_No_New_Array", 
//         vector<class ast*>({$1}),
//         370, $1->datatype);
//     }
//     | LPAREN EXPRESSION RPAREN
//     { $$ = new ast("Primary_No_New_Array", 
//         vector<class ast*>({new ast("(",yylineno,372), $2, new ast(")",yylineno,373)}),
//         371, $2->datatype);
//         sep_count++;
//         sep_count++;
//     }
//     | CLASS_INSTANCE_CREATION_EXPRESSION
//     { $$ = new ast("Primary_No_New_Array", 
//         vector<class ast*>({$1}),
//         374);
//     }
//     | FIELD_ACCESS
//     { $$ = new ast("Primary_No_New_Array", 
//         vector<class ast*>({$1}),
//         375, $1->datatype);
//     }
//     | ARRAY_ACCESS
//     { $$ = new ast("Primary_No_New_Array", 
//         vector<class ast*>({$1}),
//         376, $1->datatype);
//     }
//     | METHOD_INVOCATION
//     { $$ = new ast("Primary_No_New_Array", 
//         vector<class ast*>({$1}),
//         377, $1->datatype);
//     }
//     ;

string goto_PRIMARY_NO_NEW_ARRAY(ast* root){
    switch(root->id){
        case 370:
            return goto_LITERAL(root->children[0]);
        // case 371:
        //     return goto_EXPRESSION(root->children[1]);
        // case 374:
        //     return goto_CLASS_INSTANCE_CREATION_EXPRESSION(root->children[0]);
        // case 375:
        //     return goto_FIELD_ACCESS(root->children[0]);
        // case 376:
        //     return goto_ARRAY_ACCESS(root->children[0]);
        // case 377:
        //     return goto_METHOD_INVOCATION(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_PRIMARY_NO_NEW_ARRAY() called with wrong root->id\n";
            return "";
    }
}

// DIMS:
//     LBRACKET RBRACKET
//     { $$ = new ast("Dims", 
//         vector<class ast*>({new ast("[",yylineno,403), new ast("]",yylineno,404)}),
//         402);
//         sep_count++;
//         sep_count++;
//     }
//     | DIMS LBRACKET RBRACKET
//     { $$ = new ast("Dims", 
//         vector<class ast*>({$1, new ast("[",yylineno,406), new ast("]",yylineno,407)}),
//         405);
//         sep_count++;
//         sep_count++;
//     }
//     ;

string goto_DIMS(ast* root){
    switch(root->id){
        case 402:
            return "[]";
        case 405:
            return "[]" + goto_DIMS(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_DIMS() called with wrong root->id\n";
            return "";
    }
}

// LEFT_HAND_SIDE:
//     NAME
//     { $$ = new ast("Left_Hand_Side", 
//         vector<class ast*>({$1}),
//         528, $1->datatype);
//     }
//     | FIELD_ACCESS
//     { $$ = new ast("Left_Hand_Side", 
//         vector<class ast*>({$1}),
//         529, $1->datatype);
//     }
//     | ARRAY_ACCESS
//     { $$ = new ast("Left_Hand_Side", 
//         vector<class ast*>({$1}),
//         530, $1->datatype);
//     }

string goto_LEFT_HAND_SIDE(ast* root){
    switch(root->id){
        case 528:
            return goto_NAME(root->children[0]);
        // case 529:
        //     return goto_FIELD_ACCESS(root->children[0]);
        // case 530:
        //     return goto_ARRAY_ACCESS(root->children[0]);
        default:
            cout << "[!!] Implementation error, goto_LEFT_HAND_SIDE() called with wrong root->id\n";
            return "";
    }
}

// ARGUMENT_LIST:
//     EXPRESSION
//     { $$ = new ast("Argument_List", 
//         vector<class ast*>({$1}),
//         386, $1->datatype);
//     }
//     | ARGUMENT_LIST COMMA EXPRESSION
//     { $$ = new ast("Argument_List", 
//         vector<class ast*>({$1, new ast(",",yylineno,388), $3}),
//         387, $1->datatype);
//         sep_count++;
//     }
//     ;
