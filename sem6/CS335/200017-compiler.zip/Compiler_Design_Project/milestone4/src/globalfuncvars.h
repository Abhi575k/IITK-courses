#ifndef GLOBALVARIABLES_H
#define GLOBALVARIABLES_H

#include <bits/stdc++.h>

using namespace std;

// forward declaration of classes
class threeAC;
class ast;
class x86Code;
class threeACStack;
class SymbolTableEntry;
class SymbolTable;

// 3ac


// ast
extern int cnt;
extern int key_count, sep_count, opt_count, id_count, lit_count;
extern ast *parse_tree_root;

// codegen

// commandline

// stack

// symboltable

// typecheck


// lexer global variables
extern int yylineno;
extern FILE *yyin;
extern FILE *yyout;

// 3ac and assembly code output file
extern FILE *out;





// extern threeAC *tac;







// extern map<string, string> var_list;

// 

// extern vector<threeACStack> Stack; 

extern int yylex();
extern int yyparse();

extern void yyerror(char *s);
extern void yyerror(char *s, int lineno);

void printAstVerbose();

void checkEntry(SymbolTable *rootTable, string name);
void createSymbolTable(ast *root, SymbolTable *rootTable);

// bool intCheck(ast *ast_root, SymbolTable *rootTable);
// bool longCheck(ast *ast_root, SymbolTable *rootTable);
// bool floatCheck(ast *ast_root, SymbolTable *rootTable);
// bool doubleCheck(ast *ast_root, SymbolTable *rootTable);
// bool boolCheck(ast *ast_root, SymbolTable *rootTable);
// int countBracketSequence(ast *ast_root, SymbolTable *rootTable);
// bool checkAllTypes(ast *ast_root, SymbolTable *rootTable);

// extern SymbolTable *symbol_table_root;

// TYPE:
int getDimsCount(ast *ast_root);

// DIMS:
int get_DIMS_dims(ast *ast_root);

// METHOD_HEADER:
string get_METHOD_HEADER_name(ast *ast_root);

// METHOD_DECLARATOR:
string get_METHOD_DECLARATOR_name(ast *ast_root);

// TYPE:
string get_TYPE_type(ast *ast_root);

// NAME:
string get_NAME_name(ast *ast_root);

// VARIABLE_DECLARATOR_ID:
string get_VARIABLE_DECLARATOR_ID_name(ast *ast_root);

// LEFT_HAND_SIDE:
string get_LEFT_HAND_SIDE_name(ast *ast_root);

// PRIMARY:
string get_PRIMARY_name(ast *ast_root);

// CLASS_TYPE:
string get_CLASS_TYPE_name(ast *ast_root);

// FIELD_ACCESS:
string get_FIELD_ACCESS_name(ast *ast_root);

// void checkFunctionParam(ast *ast_root, vector<SymbolTableEntry *> param_table);

// string typeCheck(ast *root);

threeAC* create3AC(ast *root, int val);

void dumpThreeAC(FILE *out);


#endif