#include "3acstack.h"

int a_cnt = 0;

threeACStackElem::threeACStackElem(string name, int offset)
{
    this->name = name;
    this->offset = offset;
    this->is_useful = true;
}

threeACStack::threeACStack()
{
    this->size = 0;
    this->offset = 0;
    // this->r_reg.push_back({"rax", 0});
    // this->r_reg.push_back({"rcx", 0});
    // this->r_reg.push_back({"rdx", 0});
    // this->r_reg.push_back({"rbx", 0});
    // this->r_reg.push_back({"rsp", 0});
    // this->r_reg.push_back({"rbp", 0});
    // this->r_reg.push_back({"rsi", 0});
    // this->r_reg.push_back({"rdi", 0});

    this->r_reg.push_back({"r8", 0});
    this->r_reg.push_back({"r9", 0});
    this->r_reg.push_back({"r10", 0});
    this->r_reg.push_back({"r11", 0});
    this->r_reg.push_back({"r12", 0});
    this->r_reg.push_back({"r13", 0});
    this->r_reg.push_back({"r14", 0});
    this->r_reg.push_back({"r15", 0});
}

void threeACStack::newVar(string name, int size)
{
    size = 8;
    elements.push_back(new threeACStackElem(name, this->offset));
    this->offset += size;

    return;
}

string threeACStack::getVarName(string name)
{
    for (int i = elements.size() - 1; i >= 0; i--)
    {
        if (elements[i]->name == name)
        {
            if (elements[i]->offset == 0)
                return "[rbp]";
            else
                return "[rbp - " + to_string(elements[i]->offset) + "]";
        }
    }
    return "";
}

void threeACStack::removeVar(string name)
{
    // for (int i=elements.size()-1; i >= 0; i--)
    // {
    //     if (elements[i]->name == name)
    //     {
    //         elements[i]->is_useful = false;
    //         cleanStack();
    //         return;
    //     }
    // }
    return;
}

void threeACStack::cleanStack()
{
    for (int i=elements.size()-1; i >= 0; i--)
    {
        if (elements[i]->is_useful == false)
        {
            this->offset -= 8;
            elements.pop_back();
        }
        else
            break;
    }
}

string threeACStack::newReg()
{
    for(int i=0;i<r_reg.size();i++){
        if(r_reg[i].second == 0){
            r_reg[i].second = 1;
            return r_reg[i].first;
        }
    }
}

void threeACStack::freeReg(string reg)
{
    for(int i=0;i<r_reg.size();i++){
        if(r_reg[i].first == reg){
            r_reg[i].second = 0;
            return;
        }
    }
}

void threeACStack::print()
{
    cout << "Stack: " << endl;
    for (auto u : elements)
    {
        cout << u->name << " " << u->offset << endl;
    }
    cout << endl;
}

void pushLocalVariables(SymbolTable *rootTable)
{
    for (auto u : rootTable->entries)
    {
        if (u.second->is_variable)
        {
            Stack.newVar(u.second->name, u.second->size);

            threeAC *t0 = new threeAC();

            t0->op = "mov";
            t0->arg1 = Stack.newReg();
            t0->arg2 = "0";

            threeACList.push_back(t0);

            threeAC *t1 = new threeAC();
            t1->op = "push";
            t1->arg1 = t0->arg1;
            threeACList.push_back(t1);

            Stack.freeReg(t0->arg1);
        }
    }
    return;
}

void popLocalVariables(SymbolTable *rootTable)
{
    for (auto u = rootTable->entries.rbegin(); u != rootTable->entries.rend(); u++)
    {
        if (u->second->is_variable)
        {
            threeAC *t0 = new threeAC();
            t0->op = "pop";
            t0->arg1 = Stack.newReg();
            threeACList.push_back(t0);

            Stack.freeReg(t0->arg1);

            Stack.removeVar(u->second->name);
        }
    }
    return;
}

void pushArgumentsList(vector<SymbolTableEntry *> params, ast *root, int idx)
{
    threeAC *t0 = create3AC(root->children[0]);

    threeAC *t1 = new threeAC();

    t1->res = params[idx]->name;

    Stack.newVar(t1->res, params[idx]->size);
    t1->op = "mov";
    t1->arg1 = Stack.getVarName(t1->res);
    t1->arg2 = t0->res;

    threeACList.push_back(t1);

    threeAC *t2 = new threeAC();

    t2->op = "mov";
    t2->arg1 = Stack.newReg();
    t2->arg2 = t1->arg1;

    threeACList.push_back(t2);

    threeAC *t3 = new threeAC();

    t3->op = "push";
    t3->arg1 = t2->arg1;

    Stack.freeReg(t2->arg1);

    threeACList.push_back(t3);
    if (root->id != 386)
    {
        pushArgumentsList(params, root->children[0], idx + 1);
    }
    return;
}

void popArgumentsList(vector<SymbolTableEntry *> params)
{
    for (int i = params.size() - 1; i >= 0; i--)
    {
        threeAC *t0 = new threeAC();
        t0->op = "pop";
        t0->arg1 = Stack.newReg();
        threeACList.push_back(t0);

        Stack.freeReg(t0->arg1);

        Stack.removeVar(params[i]->name);
    }
    return;
}

void functionCaleeRules1(int flag)
{
    if (flag == 0)
    {
        threeAC *t0 = new threeAC();
        t0->op = "push";
        t0->arg1 = "rbp";
        threeACList.push_back(t0);

        Stack.newVar("#t", 8);

        threeAC *t1 = new threeAC();
        t1->op = "mov";
        t1->arg1 = "rbp";
        t1->arg2 = "rsp";
        threeACList.push_back(t1);
    }
    else
    {
        threeAC *t0 = new threeAC();
        t0->op = "mov";
        t0->arg1 = "rsp";
        t0->arg2 = "rbp";
        threeACList.push_back(t0);

        threeAC *t1 = new threeAC();
        t1->op = "pop";
        t1->arg1 = "rbp";
        threeACList.push_back(t1);

        Stack.removeVar("#t");
    }
    return;
}

void functionCaleeRules2(int flag)
{
    // if (flag == 0)
    // {
    //     threeAC *t0 = new threeAC();
    //     t0->op = "push";
    //     t0->arg1 = "rbx";
    //     threeACList.push_back(t0);

    //     threeAC *t1 = new threeAC();
    //     t1->op = "push";
    //     t1->arg1 = "rdi";
    //     threeACList.push_back(t1);

    //     threeAC *t2 = new threeAC();
    //     t2->op = "push";
    //     t2->arg1 = "rsi";
    //     threeACList.push_back(t2);
    // }
    // else
    // {
    //     threeAC *t0 = new threeAC();
    //     t0->op = "pop";
    //     t0->arg1 = "rsi";
    //     threeACList.push_back(t0);

    //     threeAC *t1 = new threeAC();
    //     t1->op = "pop";
    //     t1->arg1 = "rdi";
    //     threeACList.push_back(t1);

    //     threeAC *t2 = new threeAC();
    //     t2->op = "pop";
    //     t2->arg1 = "rbx";
    //     threeACList.push_back(t2);
    // }
    return;
}

void functionCallerRules(int flag)
{
    if (flag == 0)
    {
        threeAC *t0 = new threeAC();
        t0->op = "push";
        t0->arg1 = "rax";
        threeACList.push_back(t0);

        // threeAC *t1 = new threeAC();
        // t1->op = "push";
        // t1->arg1 = "rcx";
        // threeACList.push_back(t1);

        threeAC *t2 = new threeAC();
        t2->op = "push";
        t2->arg1 = "rdx";
        threeACList.push_back(t2);

        threeAC *t3 = new threeAC();
        t3->op = "push";
        t3->arg1 = "rbp";
        threeACList.push_back(t3);

        threeAC *t4 = new threeAC();
        t4->op = "mov";
        t4->arg1 = "rbp";
        t4->arg2 = "rsp";
        threeACList.push_back(t4);
    }
    else
    {
        threeAC *t0 = new threeAC();
        t0->op = "mov";
        t0->arg1 = "rsp";
        t0->arg2 = "rbp";
        threeACList.push_back(t0);

        threeAC *t1 = new threeAC();
        t1->op = "pop";
        t1->arg1 = "rbp";
        threeACList.push_back(t1);

        threeAC *t2 = new threeAC();
        t2->op = "pop";
        t2->arg1 = "rdx";
        threeACList.push_back(t2);

        // threeAC *t3 = new threeAC();
        // t3->op = "pop";
        // t3->arg1 = "rcx";
        // threeACList.push_back(t3);

        threeAC *t4 = new threeAC();
        t4->op = "pop";
        t4->arg1 = "rax";
        threeACList.push_back(t4);
    }
    return;
}
