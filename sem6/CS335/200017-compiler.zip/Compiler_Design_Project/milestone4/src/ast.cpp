#include "ast.h"

void ast::init_ast(){
    this->label = "";
    this->num = cnt;
    cnt++;
    this->lineno = 0;
    this->id = 0;
    this->datatype = "void";
    this->dims = 0;
    this->is_variable = true;
    this->is_function_param = false;
    return;
}

ast::ast(char* label, int lineno, int id){
    init_ast();
    this->label = string(label);
    this->lineno = lineno;
    this->id = id;
}

ast::ast(char* label, vector<ast*> children, int id){
    init_ast();
    this->label = string(label);
    for(int i=0;i<children.size();i++){
        if(children[i]->label!="NULL") this->children.push_back(children[i]);
    }
    this->id = id;
}

ast::ast(char* label, vector<ast*> children, int id, char* datatype){
    init_ast();
    this->label = string(label);
    for(int i=0;i<children.size();i++){
        if(children[i]->label!="NULL") this->children.push_back(children[i]);
    }
    this->id = id;
    this->datatype = string(datatype);
}

ast::ast(char* label, vector<ast*> children, int id, string datatype){
    init_ast();
    this->label = string(label);
    for(int i=0;i<children.size();i++){
        if(children[i]->label!="NULL") this->children.push_back(children[i]);
    }
    this->id = id;
    this->datatype = datatype;
}

void ast::printtree(FILE *outfile){
    if(label=="NULL") return;
    fprintf(outfile, "\tn%d [label=\"%s, %d\n%s\"]\n", num, label.c_str(), id, datatype.c_str());
    for(int i=0;i<children.size();i++){
        fprintf(outfile, "\tn%d -> n%d;\n", num, children[i]->num);
        children[i]->printtree(outfile);
    }
    return;
}

void ast::sendTypes(){
    if(children.size()!=0){
        if(datatype!="void"){
            for(int i=0;i<children.size();i++){
                if(children[i]->datatype=="void"){
                    children[i]->datatype = datatype;
                }
            }
        }
    }
    for(auto u: children){
        u->sendTypes();
    }
}

void printAstVerbose(){
    printf("\n[VERBOSE]Parse Tree Info:\n\n");
    printf("Total number of nodes: %d\n", cnt);
    printf("Keywords: %d\n", key_count);
    printf("Operators: %d\n", opt_count);
    printf("Identifiers: %d\n", id_count);
    printf("Separators: %d\n", sep_count);
    printf("Literal: %d\n", lit_count);
    return;
}
