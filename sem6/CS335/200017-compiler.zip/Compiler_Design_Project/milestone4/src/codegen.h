#ifndef CODEGEN_H
#define CODEGEN_H

#include <bits//stdc++.h>

#include "3ac.h"
#include "3acstack.h"

using namespace std;


class x86Code{
public:
    string op;
    string arg1;
    string arg2;
    string res;

    bool is_label;

    string label;

    x86Code();
    void print();
};

void x86_push(string reg);
void x86_pop(string reg);
void x86_mov(string reg, string val);

void x86_codegen(FILE *out);
void printFileHeader(FILE *out);
void function_printRAX(FILE *out);
void function_printRAXLoop(FILE *out);
void function_printRAXLoop2(FILE *out);

#endif