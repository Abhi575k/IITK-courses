#ifndef TAC_H
#define TAC_H

#include "ast.h"
#include "symboltable.h"
#include "3acstack.h"

class threeAC{
public:
    // op arg1 arg2 res
    string op;
    string arg1;
    string arg2;
    string res;

    bool is_label;
    string label;

    threeAC();
    void print();
};

extern threeAC *tac;

extern vector<threeAC *> threeACList;

threeAC* create3AC(ast *root);

void dumpThreeAC(FILE *out);

#endif