/* A Bison parser, made by GNU Bison 3.8.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30800

/* Bison version string.  */
#define YYBISON_VERSION "3.8"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "./src/parser.ypp"

// Header files
#include "./src/codegen.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wwrite-strings"

void yyerror(char*);


#line 82 "parser.tab.cpp"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.hpp"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_CLASS = 3,                      /* CLASS  */
  YYSYMBOL_IDENTIFIER = 4,                 /* IDENTIFIER  */
  YYSYMBOL_CLASSMODIFIER = 5,              /* CLASSMODIFIER  */
  YYSYMBOL_INTEGERLITERAL = 6,             /* INTEGERLITERAL  */
  YYSYMBOL_LONGLITERAL = 7,                /* LONGLITERAL  */
  YYSYMBOL_FLOATLITERAL = 8,               /* FLOATLITERAL  */
  YYSYMBOL_DOUBLELITERAL = 9,              /* DOUBLELITERAL  */
  YYSYMBOL_BOOLEANLITERAL = 10,            /* BOOLEANLITERAL  */
  YYSYMBOL_INT = 11,                       /* INT  */
  YYSYMBOL_FLOAT = 12,                     /* FLOAT  */
  YYSYMBOL_DOUBLE = 13,                    /* DOUBLE  */
  YYSYMBOL_BOOLEAN = 14,                   /* BOOLEAN  */
  YYSYMBOL_LONG = 15,                      /* LONG  */
  YYSYMBOL_THIS = 16,                      /* THIS  */
  YYSYMBOL_EQEQ = 17,                      /* EQEQ  */
  YYSYMBOL_NOT_EQUAL = 18,                 /* NOT_EQUAL  */
  YYSYMBOL_AND_ASSIGN = 19,                /* AND_ASSIGN  */
  YYSYMBOL_XOR_ASSIGN = 20,                /* XOR_ASSIGN  */
  YYSYMBOL_OR_ASSIGN = 21,                 /* OR_ASSIGN  */
  YYSYMBOL_MOD_ASSIGN = 22,                /* MOD_ASSIGN  */
  YYSYMBOL_MUL_ASSIGN = 23,                /* MUL_ASSIGN  */
  YYSYMBOL_DIV_ASSIGN = 24,                /* DIV_ASSIGN  */
  YYSYMBOL_ADD_ASSIGN = 25,                /* ADD_ASSIGN  */
  YYSYMBOL_SUB_ASSIGN = 26,                /* SUB_ASSIGN  */
  YYSYMBOL_LEFT_ASSIGN = 27,               /* LEFT_ASSIGN  */
  YYSYMBOL_RIGHT_ASSIGN = 28,              /* RIGHT_ASSIGN  */
  YYSYMBOL_LPAREN = 29,                    /* LPAREN  */
  YYSYMBOL_RPAREN = 30,                    /* RPAREN  */
  YYSYMBOL_DOT = 31,                       /* DOT  */
  YYSYMBOL_VOID = 32,                      /* VOID  */
  YYSYMBOL_IF = 33,                        /* IF  */
  YYSYMBOL_ELSE = 34,                      /* ELSE  */
  YYSYMBOL_WHILE = 35,                     /* WHILE  */
  YYSYMBOL_FOR = 36,                       /* FOR  */
  YYSYMBOL_STATIC = 37,                    /* STATIC  */
  YYSYMBOL_NEW = 38,                       /* NEW  */
  YYSYMBOL_PLUS = 39,                      /* PLUS  */
  YYSYMBOL_MINUS = 40,                     /* MINUS  */
  YYSYMBOL_THROW = 41,                     /* THROW  */
  YYSYMBOL_LBRACE = 42,                    /* LBRACE  */
  YYSYMBOL_RBRACE = 43,                    /* RBRACE  */
  YYSYMBOL_LBRACKET = 44,                  /* LBRACKET  */
  YYSYMBOL_RBRACKET = 45,                  /* RBRACKET  */
  YYSYMBOL_SEMICOLON = 46,                 /* SEMICOLON  */
  YYSYMBOL_COMMA = 47,                     /* COMMA  */
  YYSYMBOL_QMARK = 48,                     /* QMARK  */
  YYSYMBOL_COLON = 49,                     /* COLON  */
  YYSYMBOL_ASSIGN = 50,                    /* ASSIGN  */
  YYSYMBOL_DO = 51,                        /* DO  */
  YYSYMBOL_LESS = 52,                      /* LESS  */
  YYSYMBOL_GREATER = 53,                   /* GREATER  */
  YYSYMBOL_LESS_EQUAL = 54,                /* LESS_EQUAL  */
  YYSYMBOL_GREATER_EQUAL = 55,             /* GREATER_EQUAL  */
  YYSYMBOL_OROR = 56,                      /* OROR  */
  YYSYMBOL_ANDAND = 57,                    /* ANDAND  */
  YYSYMBOL_OR = 58,                        /* OR  */
  YYSYMBOL_XOR = 59,                       /* XOR  */
  YYSYMBOL_AND = 60,                       /* AND  */
  YYSYMBOL_PLUSPLUS = 61,                  /* PLUSPLUS  */
  YYSYMBOL_MINUSMINUS = 62,                /* MINUSMINUS  */
  YYSYMBOL_MUL = 63,                       /* MUL  */
  YYSYMBOL_DIV = 64,                       /* DIV  */
  YYSYMBOL_MOD = 65,                       /* MOD  */
  YYSYMBOL_IMPORT = 66,                    /* IMPORT  */
  YYSYMBOL_RETURN = 67,                    /* RETURN  */
  YYSYMBOL_BREAK = 68,                     /* BREAK  */
  YYSYMBOL_CONTINUE = 69,                  /* CONTINUE  */
  YYSYMBOL_EXTENDS = 70,                   /* EXTENDS  */
  YYSYMBOL_IMPLEMENTS = 71,                /* IMPLEMENTS  */
  YYSYMBOL_INTERFACE = 72,                 /* INTERFACE  */
  YYSYMBOL_BANG = 73,                      /* BANG  */
  YYSYMBOL_TILDE = 74,                     /* TILDE  */
  YYSYMBOL_LEFT_SHIFT = 75,                /* LEFT_SHIFT  */
  YYSYMBOL_RIGHT_SHIFT = 76,               /* RIGHT_SHIFT  */
  YYSYMBOL_UNSIGNED_RIGHT_SHIFT = 77,      /* UNSIGNED_RIGHT_SHIFT  */
  YYSYMBOL_DOTMUL = 78,                    /* DOTMUL  */
  YYSYMBOL_YYACCEPT = 79,                  /* $accept  */
  YYSYMBOL_GOAL = 80,                      /* GOAL  */
  YYSYMBOL_LITERAL = 81,                   /* LITERAL  */
  YYSYMBOL_TYPE = 82,                      /* TYPE  */
  YYSYMBOL_PRIMITIVE_TYPE = 83,            /* PRIMITIVE_TYPE  */
  YYSYMBOL_NUMERIC_TYPE = 84,              /* NUMERIC_TYPE  */
  YYSYMBOL_REFERENCE_TYPE = 85,            /* REFERENCE_TYPE  */
  YYSYMBOL_CLASS_OR_INTERFACE_TYPE = 86,   /* CLASS_OR_INTERFACE_TYPE  */
  YYSYMBOL_CLASS_TYPE = 87,                /* CLASS_TYPE  */
  YYSYMBOL_INTERFACE_TYPE = 88,            /* INTERFACE_TYPE  */
  YYSYMBOL_ARRAY_TYPE = 89,                /* ARRAY_TYPE  */
  YYSYMBOL_NAME = 90,                      /* NAME  */
  YYSYMBOL_SIMPLE_NAME = 91,               /* SIMPLE_NAME  */
  YYSYMBOL_QUALIFIED_NAME = 92,            /* QUALIFIED_NAME  */
  YYSYMBOL_COMPILATION_UNIT = 93,          /* COMPILATION_UNIT  */
  YYSYMBOL_IMPORT_DECLARATIONS = 94,       /* IMPORT_DECLARATIONS  */
  YYSYMBOL_IMPORT_DECLARATION = 95,        /* IMPORT_DECLARATION  */
  YYSYMBOL_SINGLE_TYPE_IMPORT_DECLARATION = 96, /* SINGLE_TYPE_IMPORT_DECLARATION  */
  YYSYMBOL_TYPE_IMPORT_ON_DEMAND_DECLARATION = 97, /* TYPE_IMPORT_ON_DEMAND_DECLARATION  */
  YYSYMBOL_TYPE_DECLARATIONS = 98,         /* TYPE_DECLARATIONS  */
  YYSYMBOL_MODIFIERS = 99,                 /* MODIFIERS  */
  YYSYMBOL_CLASS_DECLARATION = 100,        /* CLASS_DECLARATION  */
  YYSYMBOL_SUPER = 101,                    /* SUPER  */
  YYSYMBOL_INTERFACES = 102,               /* INTERFACES  */
  YYSYMBOL_INTERFACE_TYPE_LIST = 103,      /* INTERFACE_TYPE_LIST  */
  YYSYMBOL_CLASS_BODY = 104,               /* CLASS_BODY  */
  YYSYMBOL_CLASS_BODY_DECLARATIONS = 105,  /* CLASS_BODY_DECLARATIONS  */
  YYSYMBOL_CLASS_BODY_DECLARATION = 106,   /* CLASS_BODY_DECLARATION  */
  YYSYMBOL_CLASS_MEMBER_DECLARATION = 107, /* CLASS_MEMBER_DECLARATION  */
  YYSYMBOL_FIELD_DECLARATION = 108,        /* FIELD_DECLARATION  */
  YYSYMBOL_VARIABLE_DECLARATORS = 109,     /* VARIABLE_DECLARATORS  */
  YYSYMBOL_VARIABLE_DECLARATOR = 110,      /* VARIABLE_DECLARATOR  */
  YYSYMBOL_VARIABLE_DECLARATOR_ID = 111,   /* VARIABLE_DECLARATOR_ID  */
  YYSYMBOL_VARIABLE_INITIALIZER = 112,     /* VARIABLE_INITIALIZER  */
  YYSYMBOL_METHOD_DECLARATION = 113,       /* METHOD_DECLARATION  */
  YYSYMBOL_METHOD_HEADER = 114,            /* METHOD_HEADER  */
  YYSYMBOL_METHOD_DECLARATOR = 115,        /* METHOD_DECLARATOR  */
  YYSYMBOL_FORMAL_PARAMETER_LIST = 116,    /* FORMAL_PARAMETER_LIST  */
  YYSYMBOL_FORMAL_PARAMETER = 117,         /* FORMAL_PARAMETER  */
  YYSYMBOL_THROWS = 118,                   /* THROWS  */
  YYSYMBOL_CLASS_TYPE_LIST = 119,          /* CLASS_TYPE_LIST  */
  YYSYMBOL_METHOD_BODY = 120,              /* METHOD_BODY  */
  YYSYMBOL_STATIC_INITIALIZER = 121,       /* STATIC_INITIALIZER  */
  YYSYMBOL_CONSTRUCTOR_DECLARATION = 122,  /* CONSTRUCTOR_DECLARATION  */
  YYSYMBOL_CONSTRUCTOR_DECLARATOR = 123,   /* CONSTRUCTOR_DECLARATOR  */
  YYSYMBOL_CONSTRUCTOR_BODY = 124,         /* CONSTRUCTOR_BODY  */
  YYSYMBOL_EXPLICIT_CONSTRUCTOR_INVOCATION = 125, /* EXPLICIT_CONSTRUCTOR_INVOCATION  */
  YYSYMBOL_INTERFACE_DECLARATION = 126,    /* INTERFACE_DECLARATION  */
  YYSYMBOL_EXTENDS_INTERFACES = 127,       /* EXTENDS_INTERFACES  */
  YYSYMBOL_INTERFACE_BODY = 128,           /* INTERFACE_BODY  */
  YYSYMBOL_INTERFACE_MEMBER_DECLARATIONS = 129, /* INTERFACE_MEMBER_DECLARATIONS  */
  YYSYMBOL_INTERFACE_MEMBER_DECLARATION = 130, /* INTERFACE_MEMBER_DECLARATION  */
  YYSYMBOL_CONSTANT_DECLARATION = 131,     /* CONSTANT_DECLARATION  */
  YYSYMBOL_ABSTRACT_METHOD_DECLARATION = 132, /* ABSTRACT_METHOD_DECLARATION  */
  YYSYMBOL_ARRAY_INITIALIZER = 133,        /* ARRAY_INITIALIZER  */
  YYSYMBOL_VARIABLE_INITIALIZERS = 134,    /* VARIABLE_INITIALIZERS  */
  YYSYMBOL_BLOCK = 135,                    /* BLOCK  */
  YYSYMBOL_BLOCK_STATEMENTS = 136,         /* BLOCK_STATEMENTS  */
  YYSYMBOL_BLOCK_STATEMENT = 137,          /* BLOCK_STATEMENT  */
  YYSYMBOL_LOCAL_VARIABLE_DECLARATION_STATEMENT = 138, /* LOCAL_VARIABLE_DECLARATION_STATEMENT  */
  YYSYMBOL_LOCAL_VARIABLE_DECLARATION = 139, /* LOCAL_VARIABLE_DECLARATION  */
  YYSYMBOL_STATEMENT = 140,                /* STATEMENT  */
  YYSYMBOL_STATEMENT_NO_SHORT_IF = 141,    /* STATEMENT_NO_SHORT_IF  */
  YYSYMBOL_STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT = 142, /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT  */
  YYSYMBOL_EMPTY_STATEMENT = 143,          /* EMPTY_STATEMENT  */
  YYSYMBOL_LABELED_STATEMENT = 144,        /* LABELED_STATEMENT  */
  YYSYMBOL_LABELED_STATEMENT_NO_SHORT_IF = 145, /* LABELED_STATEMENT_NO_SHORT_IF  */
  YYSYMBOL_EXPRESSION_STATEMENT = 146,     /* EXPRESSION_STATEMENT  */
  YYSYMBOL_STATEMENT_EXPRESSION = 147,     /* STATEMENT_EXPRESSION  */
  YYSYMBOL_IF_THEN_STATEMENT = 148,        /* IF_THEN_STATEMENT  */
  YYSYMBOL_IF_THEN_ELSE_STATEMENT = 149,   /* IF_THEN_ELSE_STATEMENT  */
  YYSYMBOL_IF_THEN_ELSE_STATEMENT_NO_SHORT_IF = 150, /* IF_THEN_ELSE_STATEMENT_NO_SHORT_IF  */
  YYSYMBOL_WHILE_STATEMENT = 151,          /* WHILE_STATEMENT  */
  YYSYMBOL_WHILE_STATEMENT_NO_SHORT_IF = 152, /* WHILE_STATEMENT_NO_SHORT_IF  */
  YYSYMBOL_DO_STATEMENT = 153,             /* DO_STATEMENT  */
  YYSYMBOL_FOR_STATEMENT = 154,            /* FOR_STATEMENT  */
  YYSYMBOL_FOR_STATEMENT_NO_SHORT_IF = 155, /* FOR_STATEMENT_NO_SHORT_IF  */
  YYSYMBOL_FOR_INIT_OPT = 156,             /* FOR_INIT_OPT  */
  YYSYMBOL_FOR_INIT = 157,                 /* FOR_INIT  */
  YYSYMBOL_FOR_UPDATE_OPT = 158,           /* FOR_UPDATE_OPT  */
  YYSYMBOL_FOR_UPDATE = 159,               /* FOR_UPDATE  */
  YYSYMBOL_STATEMENT_EXPRESSION_LIST = 160, /* STATEMENT_EXPRESSION_LIST  */
  YYSYMBOL_BREAK_STATEMENT = 161,          /* BREAK_STATEMENT  */
  YYSYMBOL_CONTINUE_STATEMENT = 162,       /* CONTINUE_STATEMENT  */
  YYSYMBOL_RETURN_STATEMENT = 163,         /* RETURN_STATEMENT  */
  YYSYMBOL_PRIMARY = 164,                  /* PRIMARY  */
  YYSYMBOL_PRIMARY_NO_NEW_ARRAY = 165,     /* PRIMARY_NO_NEW_ARRAY  */
  YYSYMBOL_CLASS_INSTANCE_CREATION_EXPRESSION = 166, /* CLASS_INSTANCE_CREATION_EXPRESSION  */
  YYSYMBOL_ARGUMENT_LIST = 167,            /* ARGUMENT_LIST  */
  YYSYMBOL_ARRAY_CREATION_EXPRESSION = 168, /* ARRAY_CREATION_EXPRESSION  */
  YYSYMBOL_DIM_EXPRS = 169,                /* DIM_EXPRS  */
  YYSYMBOL_DIM_EXPR = 170,                 /* DIM_EXPR  */
  YYSYMBOL_DIMS = 171,                     /* DIMS  */
  YYSYMBOL_FIELD_ACCESS = 172,             /* FIELD_ACCESS  */
  YYSYMBOL_METHOD_INVOCATION = 173,        /* METHOD_INVOCATION  */
  YYSYMBOL_ARRAY_ACCESS = 174,             /* ARRAY_ACCESS  */
  YYSYMBOL_POSTFIX_EXPRESSION = 175,       /* POSTFIX_EXPRESSION  */
  YYSYMBOL_POST_INCREMENT_EXPRESSION = 176, /* POST_INCREMENT_EXPRESSION  */
  YYSYMBOL_POST_DECREMENT_EXPRESSION = 177, /* POST_DECREMENT_EXPRESSION  */
  YYSYMBOL_UNARY_EXPRESSION = 178,         /* UNARY_EXPRESSION  */
  YYSYMBOL_PRE_INCREMENT_EXPRESSION = 179, /* PRE_INCREMENT_EXPRESSION  */
  YYSYMBOL_PRE_DECREMENT_EXPRESSION = 180, /* PRE_DECREMENT_EXPRESSION  */
  YYSYMBOL_UNARY_EXPRESSION_NOT_PLUS_MINUS = 181, /* UNARY_EXPRESSION_NOT_PLUS_MINUS  */
  YYSYMBOL_CAST_EXPRESSION = 182,          /* CAST_EXPRESSION  */
  YYSYMBOL_MULTIPLICATIVE_EXPRESSION = 183, /* MULTIPLICATIVE_EXPRESSION  */
  YYSYMBOL_ADDITIVE_EXPRESSION = 184,      /* ADDITIVE_EXPRESSION  */
  YYSYMBOL_SHIFT_EXPRESSION = 185,         /* SHIFT_EXPRESSION  */
  YYSYMBOL_RELATIONAL_EXPRESSION = 186,    /* RELATIONAL_EXPRESSION  */
  YYSYMBOL_EQUALITY_EXPRESSION = 187,      /* EQUALITY_EXPRESSION  */
  YYSYMBOL_AND_EXPRESSION = 188,           /* AND_EXPRESSION  */
  YYSYMBOL_EXCLUSIVE_OR_EXPRESSION = 189,  /* EXCLUSIVE_OR_EXPRESSION  */
  YYSYMBOL_INCLUSIVE_OR_EXPRESSION = 190,  /* INCLUSIVE_OR_EXPRESSION  */
  YYSYMBOL_CONDITIONAL_AND_EXPRESSION = 191, /* CONDITIONAL_AND_EXPRESSION  */
  YYSYMBOL_CONDITIONAL_OR_EXPRESSION = 192, /* CONDITIONAL_OR_EXPRESSION  */
  YYSYMBOL_CONDITIONAL_EXPRESSION = 193,   /* CONDITIONAL_EXPRESSION  */
  YYSYMBOL_ASSIGNMENT_EXPRESSION = 194,    /* ASSIGNMENT_EXPRESSION  */
  YYSYMBOL_ASSIGNMENT = 195,               /* ASSIGNMENT  */
  YYSYMBOL_LEFT_HAND_SIDE = 196,           /* LEFT_HAND_SIDE  */
  YYSYMBOL_ASSIGNMENT_OPERATOR = 197,      /* ASSIGNMENT_OPERATOR  */
  YYSYMBOL_EXPRESSION = 198                /* EXPRESSION  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  22
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1850

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  79
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  120
/* YYNRULES -- Number of rules.  */
#define YYNRULES  288
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  501

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   333


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    49,    49,    53,    59,    65,    71,    77,    86,    91,
      99,   104,   113,   119,   125,   132,   142,   147,   155,   163,
     171,   179,   184,   189,   197,   202,   210,   219,   229,   234,
     239,   245,   250,   255,   263,   268,   276,   286,   298,   303,
     311,   317,   323,   329,   338,   345,   352,   359,   366,   373,
     380,   387,   397,   406,   415,   420,   429,   439,   444,   452,
     457,   462,   470,   475,   483,   489,   498,   503,   512,   517,
     526,   532,   539,   549,   554,   562,   570,   575,   580,   585,
     590,   596,   602,   608,   619,   627,   635,   645,   658,   663,
     672,   680,   689,   694,   703,   708,   717,   726,   731,   736,
     741,   749,   759,   766,   773,   780,   790,   798,   807,   815,
     828,   835,   842,   849,   859,   865,   874,   881,   891,   896,
     904,   909,   917,   926,   936,   943,   951,   961,   966,   975,
     982,   992,   997,  1005,  1010,  1018,  1027,  1035,  1040,  1045,
    1050,  1055,  1060,  1068,  1073,  1078,  1083,  1088,  1096,  1101,
    1106,  1111,  1116,  1121,  1126,  1134,  1143,  1153,  1163,  1172,
    1177,  1182,  1187,  1192,  1197,  1205,  1216,  1228,  1240,  1251,
    1262,  1275,  1285,  1298,  1308,  1323,  1329,  1334,  1339,  1347,
    1353,  1358,  1366,  1371,  1380,  1389,  1399,  1408,  1418,  1425,
    1436,  1441,  1449,  1454,  1461,  1466,  1471,  1476,  1484,  1492,
    1503,  1508,  1517,  1523,  1529,  1535,  1544,  1549,  1557,  1567,
    1574,  1584,  1591,  1601,  1608,  1615,  1624,  1636,  1643,  1653,
    1658,  1663,  1668,  1676,  1685,  1694,  1699,  1704,  1710,  1716,
    1725,  1733,  1742,  1747,  1753,  1759,  1767,  1774,  1781,  1788,
    1798,  1804,  1810,  1816,  1824,  1830,  1836,  1844,  1850,  1856,
    1861,  1870,  1876,  1882,  1888,  1894,  1902,  1908,  1914,  1922,
    1928,  1936,  1942,  1950,  1956,  1964,  1970,  1978,  1984,  1992,
    1999,  2007,  2013,  2021,  2029,  2034,  2039,  2047,  2053,  2060,
    2067,  2074,  2081,  2088,  2096,  2103,  2110,  2117,  2127
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "CLASS", "IDENTIFIER",
  "CLASSMODIFIER", "INTEGERLITERAL", "LONGLITERAL", "FLOATLITERAL",
  "DOUBLELITERAL", "BOOLEANLITERAL", "INT", "FLOAT", "DOUBLE", "BOOLEAN",
  "LONG", "THIS", "EQEQ", "NOT_EQUAL", "AND_ASSIGN", "XOR_ASSIGN",
  "OR_ASSIGN", "MOD_ASSIGN", "MUL_ASSIGN", "DIV_ASSIGN", "ADD_ASSIGN",
  "SUB_ASSIGN", "LEFT_ASSIGN", "RIGHT_ASSIGN", "LPAREN", "RPAREN", "DOT",
  "VOID", "IF", "ELSE", "WHILE", "FOR", "STATIC", "NEW", "PLUS", "MINUS",
  "THROW", "LBRACE", "RBRACE", "LBRACKET", "RBRACKET", "SEMICOLON",
  "COMMA", "QMARK", "COLON", "ASSIGN", "DO", "LESS", "GREATER",
  "LESS_EQUAL", "GREATER_EQUAL", "OROR", "ANDAND", "OR", "XOR", "AND",
  "PLUSPLUS", "MINUSMINUS", "MUL", "DIV", "MOD", "IMPORT", "RETURN",
  "BREAK", "CONTINUE", "EXTENDS", "IMPLEMENTS", "INTERFACE", "BANG",
  "TILDE", "LEFT_SHIFT", "RIGHT_SHIFT", "UNSIGNED_RIGHT_SHIFT", "DOTMUL",
  "$accept", "GOAL", "LITERAL", "TYPE", "PRIMITIVE_TYPE", "NUMERIC_TYPE",
  "REFERENCE_TYPE", "CLASS_OR_INTERFACE_TYPE", "CLASS_TYPE",
  "INTERFACE_TYPE", "ARRAY_TYPE", "NAME", "SIMPLE_NAME", "QUALIFIED_NAME",
  "COMPILATION_UNIT", "IMPORT_DECLARATIONS", "IMPORT_DECLARATION",
  "SINGLE_TYPE_IMPORT_DECLARATION", "TYPE_IMPORT_ON_DEMAND_DECLARATION",
  "TYPE_DECLARATIONS", "MODIFIERS", "CLASS_DECLARATION", "SUPER",
  "INTERFACES", "INTERFACE_TYPE_LIST", "CLASS_BODY",
  "CLASS_BODY_DECLARATIONS", "CLASS_BODY_DECLARATION",
  "CLASS_MEMBER_DECLARATION", "FIELD_DECLARATION", "VARIABLE_DECLARATORS",
  "VARIABLE_DECLARATOR", "VARIABLE_DECLARATOR_ID", "VARIABLE_INITIALIZER",
  "METHOD_DECLARATION", "METHOD_HEADER", "METHOD_DECLARATOR",
  "FORMAL_PARAMETER_LIST", "FORMAL_PARAMETER", "THROWS", "CLASS_TYPE_LIST",
  "METHOD_BODY", "STATIC_INITIALIZER", "CONSTRUCTOR_DECLARATION",
  "CONSTRUCTOR_DECLARATOR", "CONSTRUCTOR_BODY",
  "EXPLICIT_CONSTRUCTOR_INVOCATION", "INTERFACE_DECLARATION",
  "EXTENDS_INTERFACES", "INTERFACE_BODY", "INTERFACE_MEMBER_DECLARATIONS",
  "INTERFACE_MEMBER_DECLARATION", "CONSTANT_DECLARATION",
  "ABSTRACT_METHOD_DECLARATION", "ARRAY_INITIALIZER",
  "VARIABLE_INITIALIZERS", "BLOCK", "BLOCK_STATEMENTS", "BLOCK_STATEMENT",
  "LOCAL_VARIABLE_DECLARATION_STATEMENT", "LOCAL_VARIABLE_DECLARATION",
  "STATEMENT", "STATEMENT_NO_SHORT_IF",
  "STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT", "EMPTY_STATEMENT",
  "LABELED_STATEMENT", "LABELED_STATEMENT_NO_SHORT_IF",
  "EXPRESSION_STATEMENT", "STATEMENT_EXPRESSION", "IF_THEN_STATEMENT",
  "IF_THEN_ELSE_STATEMENT", "IF_THEN_ELSE_STATEMENT_NO_SHORT_IF",
  "WHILE_STATEMENT", "WHILE_STATEMENT_NO_SHORT_IF", "DO_STATEMENT",
  "FOR_STATEMENT", "FOR_STATEMENT_NO_SHORT_IF", "FOR_INIT_OPT", "FOR_INIT",
  "FOR_UPDATE_OPT", "FOR_UPDATE", "STATEMENT_EXPRESSION_LIST",
  "BREAK_STATEMENT", "CONTINUE_STATEMENT", "RETURN_STATEMENT", "PRIMARY",
  "PRIMARY_NO_NEW_ARRAY", "CLASS_INSTANCE_CREATION_EXPRESSION",
  "ARGUMENT_LIST", "ARRAY_CREATION_EXPRESSION", "DIM_EXPRS", "DIM_EXPR",
  "DIMS", "FIELD_ACCESS", "METHOD_INVOCATION", "ARRAY_ACCESS",
  "POSTFIX_EXPRESSION", "POST_INCREMENT_EXPRESSION",
  "POST_DECREMENT_EXPRESSION", "UNARY_EXPRESSION",
  "PRE_INCREMENT_EXPRESSION", "PRE_DECREMENT_EXPRESSION",
  "UNARY_EXPRESSION_NOT_PLUS_MINUS", "CAST_EXPRESSION",
  "MULTIPLICATIVE_EXPRESSION", "ADDITIVE_EXPRESSION", "SHIFT_EXPRESSION",
  "RELATIONAL_EXPRESSION", "EQUALITY_EXPRESSION", "AND_EXPRESSION",
  "EXCLUSIVE_OR_EXPRESSION", "INCLUSIVE_OR_EXPRESSION",
  "CONDITIONAL_AND_EXPRESSION", "CONDITIONAL_OR_EXPRESSION",
  "CONDITIONAL_EXPRESSION", "ASSIGNMENT_EXPRESSION", "ASSIGNMENT",
  "LEFT_HAND_SIDE", "ASSIGNMENT_OPERATOR", "EXPRESSION", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-373)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-277)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      71,    86,  -373,  -373,   171,   228,   109,  -373,    71,  -373,
    -373,  -373,  -373,   128,  -373,  -373,    98,  -373,     5,  -373,
    -373,    23,  -373,  -373,  -373,   257,  -373,  -373,   276,  1311,
     171,   171,     8,   182,  -373,   283,  -373,   245,   358,   171,
       6,  -373,    98,    23,  -373,  -373,  -373,  -373,  -373,   295,
     251,   305,   296,  -373,  -373,  -373,   296,   248,   314,  1380,
     578,  -373,  -373,  -373,  -373,   108,  -373,  -373,   106,  -373,
    -373,   317,  -373,  -373,   298,   182,  -373,  -373,  -373,  -373,
    -373,  1380,  -373,   308,   968,  -373,  -373,  -373,  -373,   171,
    -373,     8,   182,  -373,     6,  -373,   165,   320,  1479,  -373,
     165,   151,  -373,    47,   320,   319,   333,   333,   333,   304,
     295,   305,   106,  -373,  -373,  -373,  -373,  -373,   171,  1412,
     338,  -373,   171,  -373,  -373,  -373,  -373,  -373,   182,  -373,
    -373,  -373,   466,   337,  -373,   336,  -373,  -373,  -373,  -373,
    -373,  1370,   360,   362,   364,   304,  -373,  -373,  1649,  1370,
    1370,   985,    64,    78,  -373,   396,   209,   371,  -373,  1491,
    -373,  -373,   372,  -373,  -373,  -373,  -373,  -373,   379,  -373,
    -373,  -373,  -373,  -373,  -373,  -373,  -373,   373,   366,   211,
    -373,  1236,   222,  1781,   174,   289,  -373,  -373,  -373,  -373,
    1800,  -373,   396,  1034,  1060,  -373,  -373,   386,   396,    22,
    -373,   320,   350,   320,   338,  -373,  -373,   388,   404,  -373,
     196,  1558,  1570,  -373,  -373,  -373,  -373,   130,   408,  1649,
     888,  1370,  1370,  1370,  1370,  1709,  -373,  -373,   174,  -373,
    -373,  -373,  -373,  -373,  -373,   249,   374,   291,   231,   399,
     385,   395,   389,   398,    -2,  -373,  -373,  -373,   416,  1370,
    1370,   653,   417,   417,   435,   432,    91,  -373,  -373,  -373,
    -373,  -373,   422,   426,  -373,   428,  -373,  -373,   436,  1076,
    1119,   471,  -373,  -373,  -373,  -373,   478,  1370,  -373,  -373,
    -373,  -373,  -373,  -373,  -373,  -373,  -373,  -373,  -373,  -373,
    -373,  1370,  -373,  -373,   439,   172,  -373,  -373,  -373,  -373,
     442,  -373,   304,  -373,  -373,  -373,  -373,   171,  1161,  1168,
    -373,  1637,  -373,  -373,   540,  -373,    40,  1768,   457,  -373,
    -373,  -373,  -373,  1370,  1370,  1370,  1370,  1370,  1370,  1370,
    1370,  1370,  1370,  1370,  1370,  1370,  1370,  1370,  1370,  1370,
    1370,  1370,  1370,  1370,  -373,   460,   462,  -373,  -373,   447,
    -373,   448,  1370,   450,  -373,   450,  1207,   469,  -373,  -373,
    -373,  -373,   136,  -373,   454,  -373,   474,   455,  -373,  -373,
    -373,  -373,   152,  -373,  -373,   458,   143,   459,   201,  -373,
    -373,   207,  1370,   199,   229,   268,  -373,  -373,  -373,   249,
     249,   374,   374,   374,   291,   291,   291,   291,   231,   231,
     399,   385,   395,   389,   463,   398,  1716,  1649,  1244,   947,
     468,  1119,  -373,   333,   333,  -373,   220,  1370,  -373,  1370,
    -373,  1290,  -373,  -373,   959,  -373,   470,  -373,   472,  -373,
    -373,  1370,   268,  -373,  1370,   465,   479,   488,   490,  -373,
     486,   487,  -373,  -373,  -373,  -373,  -373,   947,   476,  -373,
    -373,  -373,   494,  -373,  -373,   234,  -373,  -373,  -373,  -373,
    -373,  -373,  -373,  1716,  1370,  1370,   653,  1649,   495,  -373,
     448,   947,   483,  -373,  -373,   498,   501,   491,  -373,  1649,
     502,  -373,  1716,  1716,  1327,  -373,  1649,   500,  -373,   947,
     493,  -373,  1716,   512,   947,  -373,  1716,   526,  -373,  1716,
    -373
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
      31,     0,    40,    41,     0,     0,     0,     2,    29,    33,
      34,    35,    30,     0,    38,    39,     0,    26,     0,    24,
      25,     0,     1,    32,    28,     0,    42,    43,     0,     0,
       0,     0,     0,     0,    49,     0,    36,     0,     0,     0,
       0,   113,     0,     0,    12,    13,    15,    11,    14,     0,
      41,     0,     8,    10,     9,    16,    17,    18,    24,     0,
       0,    57,    59,    62,    63,     0,    60,    61,     0,    19,
      52,    18,    20,    54,    53,     0,    47,    51,    27,    37,
     117,     0,   122,     0,     0,   118,   120,   121,   114,     0,
     112,     0,     0,    50,     0,   111,     0,    83,     0,    96,
      70,     0,    66,    68,    79,     0,    21,    23,    22,     0,
       0,     0,     0,    56,    58,    95,    75,    94,     0,     0,
       0,   100,     0,    45,   123,   116,   119,   115,     0,    46,
      48,   110,     0,     0,    82,    26,     3,     4,     5,     6,
       7,     0,     0,     0,     0,     0,   130,   155,     0,     0,
       0,     0,     0,     0,   192,     0,   274,     0,   148,     0,
     131,   133,     0,   134,   137,   149,   138,   150,     0,   139,
     140,   141,   153,   142,   151,   152,   154,   219,   190,   194,
     191,   195,   197,   196,     0,   162,   221,   160,   161,   159,
       0,    65,     0,     0,     0,    78,   209,     0,     0,     0,
      88,    81,     0,    77,     0,    98,    92,    91,     0,   105,
       0,     0,     0,    99,    55,    44,    85,     0,     0,     0,
       0,     0,     0,     0,     0,   222,   194,   197,   232,   220,
     243,   225,   226,   229,   235,   246,   249,   255,   258,   260,
     262,   264,   266,   268,   270,   272,   288,   271,     0,     0,
       0,   176,     0,    19,     0,     0,   222,   195,   196,   230,
     231,   189,     0,     0,   185,     0,   187,    70,   136,     0,
       0,     0,   129,   132,   135,   158,     0,     0,   223,   224,
     285,   286,   287,   280,   278,   279,   281,   282,   283,   284,
     277,     0,    67,    71,     0,     0,    69,    74,    73,   210,
      90,   101,     0,    80,    64,    76,    97,     0,     0,     0,
     103,     0,   104,    84,     0,   156,     0,   222,     0,   227,
     228,   233,   234,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   193,     0,     0,   178,   182,     0,
     175,   177,     0,   202,   206,   204,     0,     0,   188,   184,
     186,   214,     0,   200,     0,   212,   211,     0,   273,    72,
     126,   127,     0,    89,    93,     0,     0,     0,     0,   102,
      87,     0,     0,     0,     0,   193,   240,   241,   242,   244,
     245,   247,   248,   250,   251,   252,   253,   254,   256,   257,
     259,   261,   263,   265,     0,   267,     0,     0,     0,     0,
       0,     0,   207,   203,   205,   199,     0,     0,   213,     0,
     218,     0,   217,   124,     0,   107,     0,   109,     0,    86,
     238,     0,     0,   239,     0,    26,     0,     0,     0,   165,
       0,   137,   144,   145,   146,   147,   168,   180,     0,   183,
     208,   198,     0,   201,   216,     0,   125,   128,   106,   108,
     236,   237,   269,     0,     0,     0,   176,     0,     0,   179,
     181,   180,     0,   215,   157,     0,     0,     0,   166,     0,
       0,   170,     0,     0,     0,   172,     0,     0,   169,   180,
       0,   171,     0,     0,   180,   167,     0,     0,   174,     0,
     173
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -373,  -373,  -373,   -20,  -134,  -373,  -373,   -11,  -114,   -16,
    -373,    -4,   127,  -373,  -373,  -373,   550,  -373,  -373,   551,
     101,  -373,     0,     1,  -373,    25,  -373,   503,  -373,     3,
     -89,   368,   369,  -292,  -373,    11,   -39,  -130,   260,   -80,
    -373,  -373,  -373,  -373,   510,   -75,  -373,  -373,   528,     4,
    -373,   489,  -373,  -373,  -373,  -373,   240,   -98,  -149,  -373,
    -244,    82,   -84,  -325,  -373,  -373,  -373,  -373,  -245,  -373,
    -373,  -373,  -373,  -373,  -373,  -373,  -373,   111,  -373,  -345,
    -373,  -243,  -373,  -373,  -373,  -373,  -373,   -60,  -294,  -373,
     322,  -183,   -51,   482,   -23,   605,    44,   141,  -373,  -120,
     246,   290,  -372,  -373,    93,    45,    24,   105,   241,   233,
     244,   239,   242,  -373,   153,   303,   387,  -373,  -373,   425
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     6,   154,   155,    52,    53,    54,    55,    70,    73,
      56,   225,    19,    20,     7,     8,     9,    10,    11,    12,
      13,    14,   157,    33,    74,    34,    60,    61,    62,    63,
     101,   102,   103,   296,    64,    65,    97,   199,   200,   120,
     207,   116,    66,    67,    68,   121,   211,    15,    40,    41,
      84,    85,    86,    87,   297,   372,   158,   159,   160,   161,
     162,   163,   440,   164,   165,   166,   442,   167,   168,   169,
     170,   443,   171,   444,   172,   173,   445,   349,   350,   468,
     469,   470,   174,   175,   176,   177,   178,   226,   362,   180,
     353,   354,   108,   181,   227,   183,   228,   229,   186,   230,
     231,   232,   233,   234,   235,   236,   237,   238,   239,   240,
     241,   242,   243,   244,   245,   246,   247,   190,   291,   363
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      18,   106,   217,   371,   206,   107,   348,   347,   351,    51,
     273,   252,   104,   433,   376,   378,    32,   134,    51,    69,
      72,   212,   202,    88,   195,    57,    71,    71,    72,   259,
     260,   254,   204,    75,    57,    71,    35,   205,   179,   111,
      51,    82,    91,    92,    90,   213,   342,    95,    38,    83,
      29,    36,   301,    89,   343,    57,    57,    76,    77,   179,
     461,   111,   416,   273,    51,    38,   268,    93,   263,   302,
     382,   201,   203,   127,     1,   182,     2,    57,    72,    31,
      57,   441,   265,    37,   105,    71,   316,    82,   179,   198,
      16,   193,   128,    39,   156,    83,   182,   194,   131,   179,
     123,   319,   320,   321,   322,    57,   214,    69,     3,    22,
     264,    72,   198,   311,    71,   156,   129,   130,    71,   210,
     269,   303,    35,   305,   266,   182,   480,   455,    57,   306,
      59,    25,   457,    26,   253,   323,   182,     4,   441,    81,
      29,    71,   184,     5,   493,   256,   256,   118,   119,   497,
      98,   179,   179,   215,   115,   156,    58,   441,   441,   179,
     313,    59,   273,   184,   449,    27,   418,   441,    30,    31,
     412,   441,   412,   426,   441,    17,    17,   302,   136,   137,
     138,   139,   140,   419,   381,    81,    58,    58,   182,   182,
     419,   179,   184,   374,   132,   423,   182,   191,   192,   424,
      28,   220,   348,   184,   386,   387,   388,   156,   156,   133,
     145,   221,   222,   -18,   295,   370,   317,   256,   256,   256,
     256,   348,   347,   351,    29,   309,   348,   271,   182,   431,
     255,   428,    21,   149,   150,   278,   279,   429,   269,   185,
      35,  -164,    30,   197,   348,   223,   224,   156,   419,   348,
     451,   179,  -163,   270,   302,   184,   184,  -164,  -164,   432,
     185,    42,   430,   184,   473,   383,   384,   419,  -163,  -163,
    -222,  -222,    17,   197,   136,   137,   138,   139,   140,    35,
      43,   419,   198,   332,   333,   334,   335,    78,   182,   185,
      99,    79,   105,    98,   198,   184,    69,   220,    57,    96,
     185,   315,   413,    71,   414,   117,   145,   156,    17,   100,
      57,   460,   324,   325,   326,    44,    45,    46,    47,    48,
     256,   256,   256,   256,   256,   256,   256,   256,   256,   256,
     256,   256,   256,   256,   256,   256,   256,   256,    30,   256,
     105,   223,   224,   109,   187,   122,   179,   179,    35,   179,
    -220,  -220,   185,   185,   124,   184,   394,   395,   396,   397,
     185,   118,    17,     2,   196,   187,   329,   330,   331,    44,
      45,    46,    47,    48,   391,   392,   393,   197,   256,   474,
     119,   256,   218,   182,   182,   219,   182,   179,   188,   249,
      49,   250,   185,   251,   187,     3,   304,   192,   487,   488,
     267,    80,   271,   179,   276,   187,   179,   179,   495,   188,
     277,   179,   498,   327,   328,   500,   336,   337,   274,   179,
     389,   390,   179,   179,   182,   275,   179,   256,   256,   179,
     256,   299,   179,   308,   179,   307,   179,   314,   188,   179,
     182,   398,   399,   182,   182,   338,   344,   340,   182,   188,
     184,   184,   185,   184,   339,   341,   182,   187,   187,   182,
     182,   352,   156,   182,   356,   187,   182,   357,   358,   182,
      17,   182,   359,   182,   360,   365,   182,    44,    45,    46,
      47,    48,   366,   192,   369,   189,   193,   385,   439,   446,
     406,   184,   407,   408,   411,   409,   216,   187,   417,   420,
     422,   188,   188,   421,   425,   427,   189,   184,   464,   188,
     184,   184,   434,   450,   463,   184,   458,   465,   459,   466,
     467,  -143,   471,   184,   472,   479,   184,   184,   482,   481,
     184,   483,   486,   184,   492,   189,   184,   484,   184,   494,
     184,   188,   496,   184,    17,   315,   189,   185,   185,   478,
     185,    44,    45,    46,    47,    48,   499,   187,    23,    24,
     292,   485,   373,   114,   439,   446,   248,   300,   491,   112,
     380,    94,   401,   126,   478,   355,   262,   477,   485,   400,
     403,   491,    17,     2,   402,   405,     0,   462,   185,    44,
      45,    46,    47,    48,   368,     0,     0,     0,   189,   189,
       0,   188,     0,     0,   185,     0,   189,   185,   185,     0,
      49,     0,   185,     0,     0,    50,     0,     0,   294,   298,
     185,   113,     0,   185,   185,     0,     0,   185,     0,     0,
     185,   257,   257,   185,     0,   185,     0,   185,   189,     0,
     185,     0,     0,     0,     0,   318,     0,     0,     0,     0,
       0,     0,   187,   187,     0,   187,     0,    17,     0,   136,
     137,   138,   139,   140,    44,    45,    46,    47,    48,     0,
       0,     0,     0,     0,   345,   346,     0,     0,     0,     0,
       0,     0,   141,     0,     0,     0,     0,     0,     0,     0,
       0,   145,     0,   187,     0,   364,   188,   188,   189,   188,
       0,     0,   367,   257,   257,   257,   257,     0,     0,   187,
       0,     0,   187,   187,   149,   150,     0,   187,     0,     0,
     298,     0,     0,    30,     0,   187,     0,     0,   187,   187,
       0,     0,   187,     0,     0,   187,     0,   188,   187,     0,
     187,     0,   187,     0,     0,   187,     0,     0,   364,     0,
       0,     0,     0,   188,   258,   258,   188,   188,     0,     0,
       0,   188,     0,     0,     0,     0,     0,   404,     0,   188,
       0,     0,   188,   188,     0,     0,   188,   410,     0,   188,
       0,     0,   188,     0,   188,     0,   188,     0,     0,   188,
       0,     0,     0,   189,   189,     0,   189,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   257,   257,   257,   257,
     257,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     257,   257,   257,   257,     0,   257,   258,   258,   258,   258,
       0,     0,     0,   448,   189,     0,   410,     0,     0,     0,
       0,     0,   452,     0,   453,     0,     0,     0,     0,   298,
     189,     0,     0,   189,   189,     0,     0,     0,   189,     0,
       0,     0,     0,     0,   257,     0,   189,   257,     0,   189,
     189,     0,     0,   189,     0,     0,   189,     0,     0,   189,
       0,   189,     0,   189,     0,     0,   189,     0,     0,   475,
     476,     0,    17,     0,   136,   137,   138,   139,   140,    44,
      45,    46,    47,    48,     0,     0,     0,     0,     0,   490,
       0,     0,     0,   257,   257,     0,   257,   220,     0,     0,
       0,     0,     0,     0,     0,     0,   145,   221,   222,   258,
     258,   258,   258,   258,   258,   258,   258,   258,   258,   258,
     258,   258,   258,   258,   258,   258,   258,     0,   258,   149,
     150,    17,     0,   136,   137,   138,   139,   140,    30,     0,
       0,   223,   224,    17,     0,   136,   137,   138,   139,   140,
       0,     0,    17,     2,     0,     0,   141,     0,     0,    44,
      45,    46,    47,    48,     0,   145,     0,   258,   220,    17,
     258,   136,   137,   138,   139,   140,     0,   145,   221,   222,
      49,   295,   456,     0,     0,     3,     0,     0,   149,   150,
       0,   125,     0,     0,   220,     0,     0,    30,     0,     0,
     149,   150,     0,   145,   221,   222,     0,     0,     0,    30,
       0,   261,   223,   224,     0,     0,   258,   258,    17,   258,
     136,   137,   138,   139,   140,     0,   149,   150,     0,     0,
       0,     0,     0,     0,     0,    30,     0,     0,   223,   224,
       0,     0,     0,   220,    17,     0,   136,   137,   138,   139,
     140,     0,   145,   221,   222,     0,     0,     0,     0,   293,
      17,     0,   136,   137,   138,   139,   140,     0,     0,   220,
       0,     0,     0,     0,     0,   149,   150,     0,   145,   221,
     222,     0,   295,     0,    30,   220,   361,   223,   224,     0,
       0,     0,     0,     0,   145,   221,   222,     0,     0,     0,
       0,   149,   150,    17,     0,   136,   137,   138,   139,   140,
      30,     0,     0,   223,   224,     0,     0,   149,   150,     0,
       0,     0,     0,     0,     0,     0,    30,     0,   220,   223,
     224,     0,     0,     0,     0,     0,     0,   145,   221,   222,
       0,     0,     0,     0,   196,    17,     0,   136,   137,   138,
     139,   140,    17,     0,   136,   137,   138,   139,   140,     0,
     149,   150,     0,     0,     0,     0,     0,     0,     0,    30,
     220,   375,   223,   224,     0,     0,     0,   220,   377,   145,
     221,   222,     0,     0,     0,     0,   145,   221,   222,     0,
       0,    17,     0,   136,   137,   138,   139,   140,     0,     0,
       0,     0,   149,   150,     0,     0,     0,     0,     0,   149,
     150,    30,     0,     0,   223,   224,   220,   415,    30,     0,
       0,   223,   224,     0,     0,   145,   221,   222,    17,     0,
     136,   137,   138,   139,   140,  -275,  -275,  -275,  -275,  -275,
    -275,  -275,  -275,  -275,  -275,     0,     0,     0,   149,   150,
       0,     0,     0,   220,     0,     0,     0,    30,     0,     0,
     223,   224,   145,   221,   222,     0,  -275,     0,     0,     0,
     447,     0,     0,     0,    17,     0,   136,   137,   138,   139,
     140,     0,     0,     0,     0,   149,   150,     0,     0,     0,
       0,     0,     0,     0,    30,    17,     2,   223,   224,   220,
     454,     0,    44,    45,    46,    47,    48,     0,   145,   221,
     222,    17,     0,   136,   137,   138,   139,   140,     0,     0,
       0,     0,     0,    49,     0,     0,     0,     0,    50,     0,
       0,   149,   150,     0,     0,     0,   220,     0,     0,     0,
      30,     0,     0,   223,   224,   145,   221,   222,     0,     0,
       0,     0,     0,   489,    17,     0,   136,   137,   138,   139,
     140,     0,     0,     0,    17,    26,     0,     0,   149,   150,
       0,    44,    45,    46,    47,    48,     0,    30,     0,   220,
     223,   224,     0,     0,     0,     0,     0,     0,   145,   221,
     222,     0,   110,     0,     0,     0,   135,    27,   136,   137,
     138,   139,   140,    44,    45,    46,    47,    48,   208,     0,
       0,   149,   150,     0,     0,     0,     0,     0,     0,     0,
      30,   141,     0,   223,   224,   142,     0,   143,   144,     0,
     145,     0,     0,     0,    98,   209,     0,     0,   147,     0,
       0,     0,     0,   148,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   149,   150,     0,     0,     0,     0,   151,
     152,   153,    30,   135,     0,   136,   137,   138,   139,   140,
      44,    45,    46,    47,    48,   135,     0,   136,   137,   138,
     139,   140,    44,    45,    46,    47,    48,     0,   141,     0,
       0,     0,   142,     0,   143,   144,     0,   145,     0,     0,
     141,    98,   146,     0,   142,   147,   143,   144,     0,   145,
     148,     0,     0,    98,   272,     0,     0,   147,     0,     0,
     149,   150,   148,     0,     0,     0,   151,   152,   153,    30,
       0,     0,   149,   150,     0,     0,     0,     0,   151,   152,
     153,    30,   135,     0,   136,   137,   138,   139,   140,    44,
      45,    46,    47,    48,   135,     0,   136,   137,   138,   139,
     140,    44,    45,    46,    47,    48,     0,   141,     0,     0,
       0,   142,     0,   143,   144,     0,   145,     0,     0,   141,
      98,   310,     0,   142,   147,   143,   144,     0,   145,   148,
       0,     0,    98,   312,     0,     0,   147,     0,     0,   149,
     150,   148,     0,     0,     0,   151,   152,   153,    30,     0,
       0,   149,   150,     0,     0,     0,     0,   151,   152,   153,
      30,   135,     0,   136,   137,   138,   139,   140,    44,    45,
      46,    47,    48,   135,     0,   136,   137,   138,   139,   140,
       0,     0,     0,     0,     0,     0,   141,     0,     0,     0,
     142,     0,   143,   144,     0,   145,     0,     0,   141,    98,
     379,     0,   142,   147,   143,   144,     0,   145,   148,     0,
       0,    98,     0,     0,     0,   147,     0,     0,   149,   150,
     148,     0,     0,     0,   151,   152,   153,    30,     0,     0,
     149,   150,     0,     0,     0,     0,   151,   152,   153,    30,
     435,     0,   136,   137,   138,   139,   140,     0,  -274,  -274,
    -274,  -274,  -274,  -274,  -274,  -274,  -274,  -274,   269,     0,
      35,     0,     0,     0,     0,   141,     0,     0,     0,   436,
       0,   437,   438,   323,   145,     0,     0,     0,    98,  -274,
       0,     0,   147,     0,     0,     0,     0,   148,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   149,   150,     0,
       0,     0,     0,   151,   152,   153,    30,  -274,  -274,  -274,
    -274,  -274,  -274,  -274,  -274,  -274,  -274,   269,     0,    35,
    -276,  -276,  -276,  -276,  -276,  -276,  -276,  -276,  -276,  -276,
       0,     0,   270,     0,     0,     0,     0,     0,  -274,   280,
     281,   282,   283,   284,   285,   286,   287,   288,   289,     0,
       0,  -276,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     290
};

static const yytype_int16 yycheck[] =
{
       4,    52,   132,   295,   118,    56,   251,   251,   251,    29,
     159,   145,    51,   385,   308,   309,    16,    97,    38,    30,
      31,   119,   111,    39,   104,    29,    30,    31,    39,   149,
     150,   145,   112,    32,    38,    39,    31,   112,    98,    59,
      60,    38,    42,    42,    40,   120,    48,    43,    42,    38,
      42,    46,    30,    47,    56,    59,    60,    32,    33,   119,
     432,    81,   356,   212,    84,    42,   155,    42,     4,    47,
      30,   110,   111,    89,     3,    98,     5,    81,    89,    71,
      84,   406,     4,    78,    44,    89,   220,    84,   148,   109,
       4,    44,    91,    70,    98,    84,   119,    50,    94,   159,
      75,   221,   222,   223,   224,   109,   122,   118,    37,     0,
      46,   122,   132,   211,   118,   119,    91,    92,   122,   119,
      29,   201,    31,   203,    46,   148,   471,   421,   132,   204,
      29,     3,   424,     5,   145,    44,   159,    66,   463,    38,
      42,   145,    98,    72,   489,   149,   150,    41,    42,   494,
      42,   211,   212,   128,    46,   159,    29,   482,   483,   219,
      30,    60,   311,   119,   409,    37,    30,   492,    70,    71,
     353,   496,   355,    30,   499,     4,     4,    47,     6,     7,
       8,     9,    10,    47,   314,    84,    59,    60,   211,   212,
      47,   251,   148,   307,    29,    43,   219,    46,    47,    47,
      72,    29,   447,   159,   324,   325,   326,   211,   212,    44,
      38,    39,    40,     4,    42,    43,   220,   221,   222,   223,
     224,   466,   466,   466,    42,    29,   471,    31,   251,    30,
     148,    30,     4,    61,    62,    61,    62,    30,    29,    98,
      31,    30,    70,    44,   489,    73,    74,   251,    47,   494,
      30,   311,    30,    44,    47,   211,   212,    46,    47,    30,
     119,     4,   382,   219,    30,   316,   317,    47,    46,    47,
      61,    62,     4,    44,     6,     7,     8,     9,    10,    31,
       4,    47,   302,    52,    53,    54,    55,     4,   311,   148,
      50,    46,    44,    42,   314,   251,   307,    29,   302,     4,
     159,   219,   353,   307,   355,    65,    38,   311,     4,     4,
     314,   431,    63,    64,    65,    11,    12,    13,    14,    15,
     324,   325,   326,   327,   328,   329,   330,   331,   332,   333,
     334,   335,   336,   337,   338,   339,   340,   341,    70,   343,
      44,    73,    74,    29,    98,    47,   406,   407,    31,   409,
      61,    62,   211,   212,    46,   311,   332,   333,   334,   335,
     219,    41,     4,     5,    45,   119,    75,    76,    77,    11,
      12,    13,    14,    15,   329,   330,   331,    44,   382,   463,
      42,   385,    45,   406,   407,    49,   409,   447,    98,    29,
      32,    29,   251,    29,   148,    37,    46,    47,   482,   483,
       4,    43,    31,   463,    31,   159,   466,   467,   492,   119,
      44,   471,   496,    39,    40,   499,    17,    18,    46,   479,
     327,   328,   482,   483,   447,    46,   486,   431,   432,   489,
     434,    45,   492,    29,   494,    47,   496,    29,   148,   499,
     463,   336,   337,   466,   467,    60,    30,    58,   471,   159,
     406,   407,   311,   409,    59,    57,   479,   211,   212,   482,
     483,    44,   466,   486,    29,   219,   489,    35,    46,   492,
       4,   494,    46,   496,    46,     4,   499,    11,    12,    13,
      14,    15,     4,    47,    45,    98,    44,    30,   406,   407,
      30,   447,    30,    46,    44,    47,    30,   251,    29,    45,
      45,   211,   212,    29,    46,    46,   119,   463,    29,   219,
     466,   467,    49,    45,    49,   471,    46,    29,    46,    29,
      34,    34,    46,   479,    30,    30,   482,   483,    30,    46,
     486,    30,    30,   489,    34,   148,   492,    46,   494,    46,
     496,   251,    30,   499,     4,   463,   159,   406,   407,   467,
     409,    11,    12,    13,    14,    15,    30,   311,     8,     8,
     192,   479,   302,    60,   482,   483,   141,   198,   486,    59,
      30,    43,   339,    84,   492,   253,   151,   466,   496,   338,
     341,   499,     4,     5,   340,   343,    -1,   434,   447,    11,
      12,    13,    14,    15,   291,    -1,    -1,    -1,   211,   212,
      -1,   311,    -1,    -1,   463,    -1,   219,   466,   467,    -1,
      32,    -1,   471,    -1,    -1,    37,    -1,    -1,   193,   194,
     479,    43,    -1,   482,   483,    -1,    -1,   486,    -1,    -1,
     489,   149,   150,   492,    -1,   494,    -1,   496,   251,    -1,
     499,    -1,    -1,    -1,    -1,   220,    -1,    -1,    -1,    -1,
      -1,    -1,   406,   407,    -1,   409,    -1,     4,    -1,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    -1,
      -1,    -1,    -1,    -1,   249,   250,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    38,    -1,   447,    -1,   270,   406,   407,   311,   409,
      -1,    -1,   277,   221,   222,   223,   224,    -1,    -1,   463,
      -1,    -1,   466,   467,    61,    62,    -1,   471,    -1,    -1,
     295,    -1,    -1,    70,    -1,   479,    -1,    -1,   482,   483,
      -1,    -1,   486,    -1,    -1,   489,    -1,   447,   492,    -1,
     494,    -1,   496,    -1,    -1,   499,    -1,    -1,   323,    -1,
      -1,    -1,    -1,   463,   149,   150,   466,   467,    -1,    -1,
      -1,   471,    -1,    -1,    -1,    -1,    -1,   342,    -1,   479,
      -1,    -1,   482,   483,    -1,    -1,   486,   352,    -1,   489,
      -1,    -1,   492,    -1,   494,    -1,   496,    -1,    -1,   499,
      -1,    -1,    -1,   406,   407,    -1,   409,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   324,   325,   326,   327,
     328,   329,   330,   331,   332,   333,   334,   335,   336,   337,
     338,   339,   340,   341,    -1,   343,   221,   222,   223,   224,
      -1,    -1,    -1,   408,   447,    -1,   411,    -1,    -1,    -1,
      -1,    -1,   417,    -1,   419,    -1,    -1,    -1,    -1,   424,
     463,    -1,    -1,   466,   467,    -1,    -1,    -1,   471,    -1,
      -1,    -1,    -1,    -1,   382,    -1,   479,   385,    -1,   482,
     483,    -1,    -1,   486,    -1,    -1,   489,    -1,    -1,   492,
      -1,   494,    -1,   496,    -1,    -1,   499,    -1,    -1,   464,
     465,    -1,     4,    -1,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    -1,    -1,    -1,    -1,    -1,   484,
      -1,    -1,    -1,   431,   432,    -1,   434,    29,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    38,    39,    40,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,    -1,   343,    61,
      62,     4,    -1,     6,     7,     8,     9,    10,    70,    -1,
      -1,    73,    74,     4,    -1,     6,     7,     8,     9,    10,
      -1,    -1,     4,     5,    -1,    -1,    29,    -1,    -1,    11,
      12,    13,    14,    15,    -1,    38,    -1,   382,    29,     4,
     385,     6,     7,     8,     9,    10,    -1,    38,    39,    40,
      32,    42,    43,    -1,    -1,    37,    -1,    -1,    61,    62,
      -1,    43,    -1,    -1,    29,    -1,    -1,    70,    -1,    -1,
      61,    62,    -1,    38,    39,    40,    -1,    -1,    -1,    70,
      -1,    46,    73,    74,    -1,    -1,   431,   432,     4,   434,
       6,     7,     8,     9,    10,    -1,    61,    62,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    70,    -1,    -1,    73,    74,
      -1,    -1,    -1,    29,     4,    -1,     6,     7,     8,     9,
      10,    -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,
       4,    -1,     6,     7,     8,     9,    10,    -1,    -1,    29,
      -1,    -1,    -1,    -1,    -1,    61,    62,    -1,    38,    39,
      40,    -1,    42,    -1,    70,    29,    30,    73,    74,    -1,
      -1,    -1,    -1,    -1,    38,    39,    40,    -1,    -1,    -1,
      -1,    61,    62,     4,    -1,     6,     7,     8,     9,    10,
      70,    -1,    -1,    73,    74,    -1,    -1,    61,    62,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    70,    -1,    29,    73,
      74,    -1,    -1,    -1,    -1,    -1,    -1,    38,    39,    40,
      -1,    -1,    -1,    -1,    45,     4,    -1,     6,     7,     8,
       9,    10,     4,    -1,     6,     7,     8,     9,    10,    -1,
      61,    62,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    70,
      29,    30,    73,    74,    -1,    -1,    -1,    29,    30,    38,
      39,    40,    -1,    -1,    -1,    -1,    38,    39,    40,    -1,
      -1,     4,    -1,     6,     7,     8,     9,    10,    -1,    -1,
      -1,    -1,    61,    62,    -1,    -1,    -1,    -1,    -1,    61,
      62,    70,    -1,    -1,    73,    74,    29,    30,    70,    -1,
      -1,    73,    74,    -1,    -1,    38,    39,    40,     4,    -1,
       6,     7,     8,     9,    10,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    61,    62,
      -1,    -1,    -1,    29,    -1,    -1,    -1,    70,    -1,    -1,
      73,    74,    38,    39,    40,    -1,    50,    -1,    -1,    -1,
      46,    -1,    -1,    -1,     4,    -1,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    61,    62,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    70,     4,     5,    73,    74,    29,
      30,    -1,    11,    12,    13,    14,    15,    -1,    38,    39,
      40,     4,    -1,     6,     7,     8,     9,    10,    -1,    -1,
      -1,    -1,    -1,    32,    -1,    -1,    -1,    -1,    37,    -1,
      -1,    61,    62,    -1,    -1,    -1,    29,    -1,    -1,    -1,
      70,    -1,    -1,    73,    74,    38,    39,    40,    -1,    -1,
      -1,    -1,    -1,    46,     4,    -1,     6,     7,     8,     9,
      10,    -1,    -1,    -1,     4,     5,    -1,    -1,    61,    62,
      -1,    11,    12,    13,    14,    15,    -1,    70,    -1,    29,
      73,    74,    -1,    -1,    -1,    -1,    -1,    -1,    38,    39,
      40,    -1,    32,    -1,    -1,    -1,     4,    37,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    -1,
      -1,    61,    62,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      70,    29,    -1,    73,    74,    33,    -1,    35,    36,    -1,
      38,    -1,    -1,    -1,    42,    43,    -1,    -1,    46,    -1,
      -1,    -1,    -1,    51,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    61,    62,    -1,    -1,    -1,    -1,    67,
      68,    69,    70,     4,    -1,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,     4,    -1,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    -1,    29,    -1,
      -1,    -1,    33,    -1,    35,    36,    -1,    38,    -1,    -1,
      29,    42,    43,    -1,    33,    46,    35,    36,    -1,    38,
      51,    -1,    -1,    42,    43,    -1,    -1,    46,    -1,    -1,
      61,    62,    51,    -1,    -1,    -1,    67,    68,    69,    70,
      -1,    -1,    61,    62,    -1,    -1,    -1,    -1,    67,    68,
      69,    70,     4,    -1,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,     4,    -1,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    -1,    29,    -1,    -1,
      -1,    33,    -1,    35,    36,    -1,    38,    -1,    -1,    29,
      42,    43,    -1,    33,    46,    35,    36,    -1,    38,    51,
      -1,    -1,    42,    43,    -1,    -1,    46,    -1,    -1,    61,
      62,    51,    -1,    -1,    -1,    67,    68,    69,    70,    -1,
      -1,    61,    62,    -1,    -1,    -1,    -1,    67,    68,    69,
      70,     4,    -1,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,     4,    -1,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    -1,    -1,    29,    -1,    -1,    -1,
      33,    -1,    35,    36,    -1,    38,    -1,    -1,    29,    42,
      43,    -1,    33,    46,    35,    36,    -1,    38,    51,    -1,
      -1,    42,    -1,    -1,    -1,    46,    -1,    -1,    61,    62,
      51,    -1,    -1,    -1,    67,    68,    69,    70,    -1,    -1,
      61,    62,    -1,    -1,    -1,    -1,    67,    68,    69,    70,
       4,    -1,     6,     7,     8,     9,    10,    -1,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    -1,    -1,    -1,    -1,    29,    -1,    -1,    -1,    33,
      -1,    35,    36,    44,    38,    -1,    -1,    -1,    42,    50,
      -1,    -1,    46,    -1,    -1,    -1,    -1,    51,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    62,    -1,
      -1,    -1,    -1,    67,    68,    69,    70,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    -1,    44,    -1,    -1,    -1,    -1,    -1,    50,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      -1,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      50
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     5,    37,    66,    72,    80,    93,    94,    95,
      96,    97,    98,    99,   100,   126,     4,     4,    90,    91,
      92,     4,     0,    95,    98,     3,     5,    37,    72,    42,
      70,    71,   101,   102,   104,    31,    46,    78,    42,    70,
     127,   128,     4,     4,    11,    12,    13,    14,    15,    32,
      37,    82,    83,    84,    85,    86,    89,    90,    91,    99,
     105,   106,   107,   108,   113,   114,   121,   122,   123,    86,
      87,    90,    86,    88,   103,   102,   104,   104,     4,    46,
      43,    99,   108,   114,   129,   130,   131,   132,    88,    47,
     128,   101,   102,   104,   127,   128,     4,   115,    42,   135,
       4,   109,   110,   111,   115,    44,   171,   171,   171,    29,
      32,    82,   123,    43,   106,    46,   120,   135,    41,    42,
     118,   124,    47,   104,    46,    43,   130,    88,   102,   104,
     104,   128,    29,    44,   118,     4,     6,     7,     8,     9,
      10,    29,    33,    35,    36,    38,    43,    46,    51,    61,
      62,    67,    68,    69,    81,    82,    90,   101,   135,   136,
     137,   138,   139,   140,   142,   143,   144,   146,   147,   148,
     149,   151,   153,   154,   161,   162,   163,   164,   165,   166,
     168,   172,   173,   174,   175,   176,   177,   179,   180,   195,
     196,    46,    47,    44,    50,   118,    45,    44,    82,   116,
     117,   115,   109,   115,   118,   124,    87,   119,    16,    43,
     101,   125,   136,   124,    88,   104,    30,   116,    45,    49,
      29,    39,    40,    73,    74,    90,   166,   173,   175,   176,
     178,   179,   180,   181,   182,   183,   184,   185,   186,   187,
     188,   189,   190,   191,   192,   193,   194,   195,   198,    29,
      29,    29,    83,    86,    87,   140,    90,   172,   174,   178,
     178,    46,   198,     4,    46,     4,    46,     4,   109,    29,
      44,    31,    43,   137,    46,    46,    31,    44,    61,    62,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      50,   197,   110,    45,   198,    42,   112,   133,   198,    45,
     111,    30,    47,   118,    46,   118,   124,    47,    29,    29,
      43,   136,    43,    30,    29,   140,    83,    90,   198,   178,
     178,   178,   178,    44,    63,    64,    65,    39,    40,    75,
      76,    77,    52,    53,    54,    55,    17,    18,    60,    59,
      58,    57,    48,    56,    30,   198,   198,   139,   147,   156,
     157,   160,    44,   169,   170,   169,    29,    35,    46,    46,
      46,    30,   167,   198,   198,     4,     4,   198,   194,    45,
      43,   112,   134,   117,    87,    30,   167,    30,   167,    43,
      30,   116,    30,   171,   171,    30,   178,   178,   178,   183,
     183,   184,   184,   184,   185,   185,   185,   185,   186,   186,
     187,   188,   189,   190,   198,   191,    30,    30,    46,    47,
     198,    44,   170,   171,   171,    30,   167,    29,    30,    47,
      45,    29,    45,    43,    47,    46,    30,    46,    30,    30,
     178,    30,    30,   181,    49,     4,    33,    35,    36,   140,
     141,   142,   145,   150,   152,   155,   140,    46,   198,   147,
      45,    30,   198,   198,    30,   167,    43,   112,    46,    46,
     178,   181,   193,    49,    29,    29,    29,    34,   158,   159,
     160,    46,    30,    30,   141,   198,   198,   156,   140,    30,
     158,    46,    30,    30,    46,   140,    30,   141,   141,    46,
     198,   140,    34,   158,    46,   141,    30,   158,   141,    30,
     141
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,    79,    80,    81,    81,    81,    81,    81,    82,    82,
      83,    83,    84,    84,    84,    84,    85,    85,    86,    87,
      88,    89,    89,    89,    90,    90,    91,    92,    93,    93,
      93,    93,    94,    94,    95,    95,    96,    97,    98,    98,
      99,    99,    99,    99,   100,   100,   100,   100,   100,   100,
     100,   100,   101,   102,   103,   103,   104,   105,   105,   106,
     106,   106,   107,   107,   108,   108,   109,   109,   110,   110,
     111,   111,   111,   112,   112,   113,   114,   114,   114,   114,
     114,   114,   114,   114,   115,   115,   115,   115,   116,   116,
     117,   118,   119,   119,   120,   120,   121,   122,   122,   122,
     122,   123,   124,   124,   124,   124,   125,   125,   125,   125,
     126,   126,   126,   126,   127,   127,   128,   128,   129,   129,
     130,   130,   131,   132,   133,   133,   133,   134,   134,   135,
     135,   136,   136,   137,   137,   138,   139,   140,   140,   140,
     140,   140,   140,   141,   141,   141,   141,   141,   142,   142,
     142,   142,   142,   142,   142,   143,   144,   145,   146,   147,
     147,   147,   147,   147,   147,   148,   149,   150,   151,   152,
     153,   154,   154,   155,   155,   156,   156,   157,   157,   158,
     158,   159,   160,   160,   161,   161,   162,   162,   163,   163,
     164,   164,   165,   165,   165,   165,   165,   165,   166,   166,
     167,   167,   168,   168,   168,   168,   169,   169,   170,   171,
     171,   172,   172,   173,   173,   173,   173,   174,   174,   175,
     175,   175,   175,   176,   177,   178,   178,   178,   178,   178,
     179,   180,   181,   181,   181,   181,   182,   182,   182,   182,
     183,   183,   183,   183,   184,   184,   184,   185,   185,   185,
     185,   186,   186,   186,   186,   186,   187,   187,   187,   188,
     188,   189,   189,   190,   190,   191,   191,   192,   192,   193,
     193,   194,   194,   195,   196,   196,   196,   197,   197,   197,
     197,   197,   197,   197,   197,   197,   197,   197,   198
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     2,     2,     1,     1,     1,     3,     2,     1,
       1,     0,     2,     1,     1,     1,     3,     4,     1,     1,
       1,     1,     2,     2,     6,     5,     5,     4,     5,     3,
       4,     4,     2,     2,     1,     3,     3,     1,     2,     1,
       1,     1,     1,     1,     4,     3,     1,     3,     1,     3,
       1,     3,     4,     1,     1,     2,     4,     3,     3,     2,
       4,     3,     3,     2,     4,     3,     6,     5,     1,     3,
       2,     2,     1,     3,     1,     1,     2,     4,     3,     3,
       2,     4,     4,     3,     3,     2,     5,     4,     5,     4,
       5,     4,     4,     3,     2,     3,     3,     2,     1,     2,
       1,     1,     1,     2,     3,     4,     2,     1,     3,     3,
       2,     1,     2,     1,     1,     2,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     3,     2,     1,
       1,     1,     1,     1,     1,     5,     7,     7,     5,     5,
       7,     9,     8,     9,     8,     1,     0,     1,     1,     1,
       0,     1,     1,     3,     3,     2,     3,     2,     3,     2,
       1,     1,     1,     3,     1,     1,     1,     1,     5,     4,
       1,     3,     3,     4,     3,     4,     1,     2,     3,     2,
       3,     3,     3,     4,     3,     6,     5,     4,     4,     1,
       1,     1,     1,     2,     2,     1,     1,     2,     2,     1,
       2,     2,     1,     2,     2,     1,     5,     5,     4,     4,
       3,     3,     3,     1,     3,     3,     1,     3,     3,     1,
       3,     3,     3,     3,     3,     1,     3,     3,     1,     3,
       1,     3,     1,     3,     1,     3,     1,     3,     1,     5,
       1,     1,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* GOAL: COMPILATION_UNIT  */
#line 50 "./src/parser.ypp"
    { parse_tree_root = (yyvsp[0].a); }
#line 1940 "parser.tab.cpp"
    break;

  case 3: /* LITERAL: INTEGERLITERAL  */
#line 54 "./src/parser.ypp"
    { (yyval.a) = new ast("Literal", 
        vector<class ast*>({new ast((yyvsp[0].string_val), yylineno, 2)}),
        1, "int");
        lit_count++;
    }
#line 1950 "parser.tab.cpp"
    break;

  case 4: /* LITERAL: LONGLITERAL  */
#line 60 "./src/parser.ypp"
    { (yyval.a) = new ast("Literal", 
        vector<class ast*>({new ast((yyvsp[0].string_val), yylineno, 4)}),
        3, "long");
        lit_count++;
    }
#line 1960 "parser.tab.cpp"
    break;

  case 5: /* LITERAL: FLOATLITERAL  */
#line 66 "./src/parser.ypp"
    { (yyval.a) = new ast("Literal", 
        vector<class ast*>({new ast((yyvsp[0].string_val), yylineno, 6)}),
        5, "float");
        lit_count++;
    }
#line 1970 "parser.tab.cpp"
    break;

  case 6: /* LITERAL: DOUBLELITERAL  */
#line 72 "./src/parser.ypp"
    { (yyval.a) = new ast("Literal", 
        vector<class ast*>({new ast((yyvsp[0].string_val), yylineno, 8)}),
        7, "double");
        lit_count++;
    }
#line 1980 "parser.tab.cpp"
    break;

  case 7: /* LITERAL: BOOLEANLITERAL  */
#line 78 "./src/parser.ypp"
    { (yyval.a) = new ast("Literal", 
        vector<class ast*>({new ast((yyvsp[0].string_val), yylineno, 10)}),
        9, "bool");
        lit_count++;
    }
#line 1990 "parser.tab.cpp"
    break;

  case 8: /* TYPE: PRIMITIVE_TYPE  */
#line 87 "./src/parser.ypp"
    { (yyval.a) = new ast("Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        10, (yyvsp[0].a)->datatype);
    }
#line 1999 "parser.tab.cpp"
    break;

  case 9: /* TYPE: REFERENCE_TYPE  */
#line 92 "./src/parser.ypp"
    { (yyval.a) = new ast("Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        11, (yyvsp[0].a)->datatype);
    }
#line 2008 "parser.tab.cpp"
    break;

  case 10: /* PRIMITIVE_TYPE: NUMERIC_TYPE  */
#line 100 "./src/parser.ypp"
    { (yyval.a) = new ast("Primitive_Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        12, (yyvsp[0].a)->datatype);
    }
#line 2017 "parser.tab.cpp"
    break;

  case 11: /* PRIMITIVE_TYPE: BOOLEAN  */
#line 105 "./src/parser.ypp"
    { (yyval.a) = new ast("Primitive_Type", 
        vector<class ast*>({new ast("bool",yylineno, 14)}),
        13, "bool");
        lit_count++;
    }
#line 2027 "parser.tab.cpp"
    break;

  case 12: /* NUMERIC_TYPE: INT  */
#line 114 "./src/parser.ypp"
    { (yyval.a) = new ast("Numeric_Type", 
        vector<class ast*>({new ast("int",yylineno, 16)}),
        15, "int");
        key_count++;
    }
#line 2037 "parser.tab.cpp"
    break;

  case 13: /* NUMERIC_TYPE: FLOAT  */
#line 120 "./src/parser.ypp"
    { (yyval.a) = new ast("Numeric_Type", 
        vector<class ast*>({new ast("float",yylineno, 18)}),
        17, "float");
        key_count++;
    }
#line 2047 "parser.tab.cpp"
    break;

  case 14: /* NUMERIC_TYPE: LONG  */
#line 126 "./src/parser.ypp"
    {
        (yyval.a) = new ast("Numeric_Type", 
        vector<class ast*>({ new ast("long",yylineno, 20)}),
        19, "long");
        key_count++;
    }
#line 2058 "parser.tab.cpp"
    break;

  case 15: /* NUMERIC_TYPE: DOUBLE  */
#line 133 "./src/parser.ypp"
    { (yyval.a) = new ast("Numeric_Type", 
        vector<class ast*>({new ast("double",yylineno, 22)}),
        21, "double");
        key_count++;
    }
#line 2068 "parser.tab.cpp"
    break;

  case 16: /* REFERENCE_TYPE: CLASS_OR_INTERFACE_TYPE  */
#line 143 "./src/parser.ypp"
    { (yyval.a) = new ast("Reference_Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        24, (yyvsp[0].a)->datatype);
    }
#line 2077 "parser.tab.cpp"
    break;

  case 17: /* REFERENCE_TYPE: ARRAY_TYPE  */
#line 148 "./src/parser.ypp"
    { (yyval.a) = new ast("Reference_Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        25, (yyvsp[0].a)->datatype);
    }
#line 2086 "parser.tab.cpp"
    break;

  case 18: /* CLASS_OR_INTERFACE_TYPE: NAME  */
#line 156 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Or_Interface_Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        26);
    }
#line 2095 "parser.tab.cpp"
    break;

  case 19: /* CLASS_TYPE: CLASS_OR_INTERFACE_TYPE  */
#line 164 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        27);
    }
#line 2104 "parser.tab.cpp"
    break;

  case 20: /* INTERFACE_TYPE: CLASS_OR_INTERFACE_TYPE  */
#line 172 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Type", 
        vector<class ast*>({(yyvsp[0].a)}),
        28);
    }
#line 2113 "parser.tab.cpp"
    break;

  case 21: /* ARRAY_TYPE: PRIMITIVE_TYPE DIMS  */
#line 180 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Type", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        29, (yyvsp[-1].a)->datatype);
    }
#line 2122 "parser.tab.cpp"
    break;

  case 22: /* ARRAY_TYPE: NAME DIMS  */
#line 185 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Type", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        30, (yyvsp[-1].a)->datatype);
    }
#line 2131 "parser.tab.cpp"
    break;

  case 23: /* ARRAY_TYPE: ARRAY_TYPE DIMS  */
#line 190 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Type", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        31, (yyvsp[-1].a)->datatype);
    }
#line 2140 "parser.tab.cpp"
    break;

  case 24: /* NAME: SIMPLE_NAME  */
#line 198 "./src/parser.ypp"
    { (yyval.a) = new ast("Name", 
        vector<class ast*>({(yyvsp[0].a)}),
        32, (yyvsp[0].a)->datatype);
    }
#line 2149 "parser.tab.cpp"
    break;

  case 25: /* NAME: QUALIFIED_NAME  */
#line 203 "./src/parser.ypp"
    { (yyval.a) = new ast("Name", 
        vector<class ast*>({(yyvsp[0].a)}),
        33, (yyvsp[0].a)->datatype);
    }
#line 2158 "parser.tab.cpp"
    break;

  case 26: /* SIMPLE_NAME: IDENTIFIER  */
#line 211 "./src/parser.ypp"
    { (yyval.a) = new ast("Simple_Name", 
        vector<class ast*>({new ast((yyvsp[0].string_val),yylineno, 34)}),
        35, (yyvsp[0].string_val));
        id_count++;
    }
#line 2168 "parser.tab.cpp"
    break;

  case 27: /* QUALIFIED_NAME: NAME DOT IDENTIFIER  */
#line 220 "./src/parser.ypp"
    { (yyval.a) = new ast("Qualified_Name", 
        vector<class ast*>({(yyvsp[-2].a), new ast(".",yylineno, 37), new ast((yyvsp[0].string_val),yylineno, 38)}),
        36, (yyvsp[-2].a)->datatype );
        id_count++;
        sep_count++;
    }
#line 2179 "parser.tab.cpp"
    break;

  case 28: /* COMPILATION_UNIT: IMPORT_DECLARATIONS TYPE_DECLARATIONS  */
#line 230 "./src/parser.ypp"
    { (yyval.a) = new ast("Compilation_Unit", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        39);
    }
#line 2188 "parser.tab.cpp"
    break;

  case 29: /* COMPILATION_UNIT: IMPORT_DECLARATIONS  */
#line 235 "./src/parser.ypp"
    { (yyval.a) = new ast("Compilation_Unit", 
        vector<class ast*>({(yyvsp[0].a)}),
        40);
    }
#line 2197 "parser.tab.cpp"
    break;

  case 30: /* COMPILATION_UNIT: TYPE_DECLARATIONS  */
#line 240 "./src/parser.ypp"
    { (yyval.a) = new ast("Compilation_Unit", 
        vector<class ast*>({(yyvsp[0].a)}),
        41);
    }
#line 2206 "parser.tab.cpp"
    break;

  case 31: /* COMPILATION_UNIT: %empty  */
#line 245 "./src/parser.ypp"
    { (yyval.a) = NULL;
    }
#line 2213 "parser.tab.cpp"
    break;

  case 32: /* IMPORT_DECLARATIONS: IMPORT_DECLARATIONS IMPORT_DECLARATION  */
#line 251 "./src/parser.ypp"
    { (yyval.a) = new ast("Import_Declarations", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        43);
    }
#line 2222 "parser.tab.cpp"
    break;

  case 33: /* IMPORT_DECLARATIONS: IMPORT_DECLARATION  */
#line 256 "./src/parser.ypp"
    { (yyval.a) = new ast("Import_Declarations", 
        vector<class ast*>({(yyvsp[0].a)}),
        44);
    }
#line 2231 "parser.tab.cpp"
    break;

  case 34: /* IMPORT_DECLARATION: SINGLE_TYPE_IMPORT_DECLARATION  */
#line 264 "./src/parser.ypp"
    { (yyval.a) = new ast("Import_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        45);
    }
#line 2240 "parser.tab.cpp"
    break;

  case 35: /* IMPORT_DECLARATION: TYPE_IMPORT_ON_DEMAND_DECLARATION  */
#line 269 "./src/parser.ypp"
    { (yyval.a) = new ast("Import_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        46);
    }
#line 2249 "parser.tab.cpp"
    break;

  case 36: /* SINGLE_TYPE_IMPORT_DECLARATION: IMPORT NAME SEMICOLON  */
#line 277 "./src/parser.ypp"
    { (yyval.a) = new ast("Single_Type_Import_Declaration", 
        vector<class ast*>({new ast("import",yylineno, 48),(yyvsp[-1].a),new ast(";",yylineno, 49)}),
        47);
        key_count++;
        sep_count++;
    }
#line 2260 "parser.tab.cpp"
    break;

  case 37: /* TYPE_IMPORT_ON_DEMAND_DECLARATION: IMPORT NAME DOTMUL SEMICOLON  */
#line 287 "./src/parser.ypp"
    { (yyval.a) = new ast("Type_Import_On_Demand_Declaration", 
        vector<class ast*>({ new ast("import", yylineno, 51) , (yyvsp[-2].a), new ast(".*", yylineno, 52) , new ast(";", yylineno, 53)}),
        50);
        key_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 2273 "parser.tab.cpp"
    break;

  case 38: /* TYPE_DECLARATIONS: CLASS_DECLARATION  */
#line 299 "./src/parser.ypp"
    { (yyval.a) = new ast("Type_Declarations", 
        vector<class ast*>({(yyvsp[0].a)}),
        54);
    }
#line 2282 "parser.tab.cpp"
    break;

  case 39: /* TYPE_DECLARATIONS: INTERFACE_DECLARATION  */
#line 304 "./src/parser.ypp"
    { (yyval.a) = new ast("Type_Declarations", 
        vector<class ast*>({(yyvsp[0].a)}),
        55);
    }
#line 2291 "parser.tab.cpp"
    break;

  case 40: /* MODIFIERS: CLASSMODIFIER  */
#line 312 "./src/parser.ypp"
    { (yyval.a) = new ast("Modifiers", 
        vector<class ast*>({new ast((yyvsp[0].string_val),yylineno, 57)}),
        56);
        key_count++;
    }
#line 2301 "parser.tab.cpp"
    break;

  case 41: /* MODIFIERS: STATIC  */
#line 318 "./src/parser.ypp"
    { (yyval.a) = new ast("Modifiers", 
        vector<class ast*>({new ast("static",yylineno, 59)}),
        58);
        key_count++;
    }
#line 2311 "parser.tab.cpp"
    break;

  case 42: /* MODIFIERS: MODIFIERS CLASSMODIFIER  */
#line 324 "./src/parser.ypp"
    { (yyval.a) = new ast("Modifiers", 
        vector<class ast*>({(yyvsp[-1].a), new ast((yyvsp[0].string_val),yylineno, 61)}),
        60);
        key_count++;
    }
#line 2321 "parser.tab.cpp"
    break;

  case 43: /* MODIFIERS: MODIFIERS STATIC  */
#line 330 "./src/parser.ypp"
    { (yyval.a) = new ast("Modifiers", 
        vector<class ast*>({(yyvsp[-1].a), new ast("static",yylineno, 63)}),
        62);
        key_count++;
    }
#line 2331 "parser.tab.cpp"
    break;

  case 44: /* CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER SUPER INTERFACES CLASS_BODY  */
#line 339 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({(yyvsp[-5].a),new ast("class",yylineno, 65), new ast((yyvsp[-3].string_val),yylineno, 66), (yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        64);
        key_count++;
        id_count++;
    }
#line 2342 "parser.tab.cpp"
    break;

  case 45: /* CLASS_DECLARATION: CLASS IDENTIFIER SUPER INTERFACES CLASS_BODY  */
#line 346 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({new ast("class",yylineno, 68),new ast((yyvsp[-3].string_val),yylineno, 69), (yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        67);
        key_count++;
        id_count++;
    }
#line 2353 "parser.tab.cpp"
    break;

  case 46: /* CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER SUPER CLASS_BODY  */
#line 353 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({(yyvsp[-4].a),new ast("class",yylineno, 71), new ast((yyvsp[-2].string_val),yylineno, 72), (yyvsp[-1].a), (yyvsp[0].a)}),
        70);
        key_count++;
        id_count++;
    }
#line 2364 "parser.tab.cpp"
    break;

  case 47: /* CLASS_DECLARATION: CLASS IDENTIFIER SUPER CLASS_BODY  */
#line 360 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({new ast("class",yylineno, 74),new ast((yyvsp[-2].string_val),yylineno, 75), (yyvsp[-1].a), (yyvsp[0].a)}),
        73);
        key_count++;
        id_count++;
    }
#line 2375 "parser.tab.cpp"
    break;

  case 48: /* CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER INTERFACES CLASS_BODY  */
#line 367 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({(yyvsp[-4].a),new ast("class",yylineno, 77), new ast((yyvsp[-2].string_val),yylineno, 78), (yyvsp[-1].a), (yyvsp[0].a)}),
        76);
        key_count++;
        id_count++;
    }
#line 2386 "parser.tab.cpp"
    break;

  case 49: /* CLASS_DECLARATION: CLASS IDENTIFIER CLASS_BODY  */
#line 374 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({new ast("class",yylineno, 80),new ast((yyvsp[-1].string_val),yylineno, 81), (yyvsp[0].a)}),
        79);
        key_count++;
        id_count++;
    }
#line 2397 "parser.tab.cpp"
    break;

  case 50: /* CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER CLASS_BODY  */
#line 381 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({(yyvsp[-3].a),new ast("class",yylineno, 83), new ast((yyvsp[-1].string_val),yylineno, 84), (yyvsp[0].a)}),
        82);
        key_count++;
        id_count++;
    }
#line 2408 "parser.tab.cpp"
    break;

  case 51: /* CLASS_DECLARATION: CLASS IDENTIFIER INTERFACES CLASS_BODY  */
#line 388 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Declaration", 
        vector<class ast*>({new ast("class",yylineno, 86),new ast((yyvsp[-2].string_val),yylineno, 87), (yyvsp[-1].a), (yyvsp[0].a)}),
        85);
        key_count++;
        id_count++;
    }
#line 2419 "parser.tab.cpp"
    break;

  case 52: /* SUPER: EXTENDS CLASS_TYPE  */
#line 398 "./src/parser.ypp"
    { (yyval.a) = new ast("Super", 
        vector<class ast*>({new ast("extends",yylineno, 89),(yyvsp[0].a)}),
        88);
        key_count++;
    }
#line 2429 "parser.tab.cpp"
    break;

  case 53: /* INTERFACES: IMPLEMENTS INTERFACE_TYPE_LIST  */
#line 407 "./src/parser.ypp"
    { (yyval.a) = new ast("Interfaces", 
        vector<class ast*>({new ast("implements",yylineno, 91),(yyvsp[0].a)}),
        90);
        key_count++;
    }
#line 2439 "parser.tab.cpp"
    break;

  case 54: /* INTERFACE_TYPE_LIST: INTERFACE_TYPE  */
#line 416 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Type_List", 
        vector<class ast*>({(yyvsp[0].a)}),
        92);
    }
#line 2448 "parser.tab.cpp"
    break;

  case 55: /* INTERFACE_TYPE_LIST: INTERFACE_TYPE_LIST COMMA INTERFACE_TYPE  */
#line 421 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Type_List", 
        vector<class ast*>({(yyvsp[-2].a), new ast(",",yylineno, 94),(yyvsp[0].a)}),
        93);
        sep_count++;
    }
#line 2458 "parser.tab.cpp"
    break;

  case 56: /* CLASS_BODY: LBRACE CLASS_BODY_DECLARATIONS RBRACE  */
#line 430 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Body", 
        vector<class ast*>({new ast("{",yylineno, 96), (yyvsp[-1].a), new ast("}",yylineno, 97)}),
        95);
        sep_count++;
        sep_count++;
    }
#line 2469 "parser.tab.cpp"
    break;

  case 57: /* CLASS_BODY_DECLARATIONS: CLASS_BODY_DECLARATION  */
#line 440 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Body_Declarations", 
        vector<class ast*>({(yyvsp[0].a)}),
        98);
    }
#line 2478 "parser.tab.cpp"
    break;

  case 58: /* CLASS_BODY_DECLARATIONS: CLASS_BODY_DECLARATIONS CLASS_BODY_DECLARATION  */
#line 445 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Body_Declarations", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        99);
    }
#line 2487 "parser.tab.cpp"
    break;

  case 59: /* CLASS_BODY_DECLARATION: CLASS_MEMBER_DECLARATION  */
#line 453 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Body_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        100);
    }
#line 2496 "parser.tab.cpp"
    break;

  case 60: /* CLASS_BODY_DECLARATION: STATIC_INITIALIZER  */
#line 458 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Body_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        101);
    }
#line 2505 "parser.tab.cpp"
    break;

  case 61: /* CLASS_BODY_DECLARATION: CONSTRUCTOR_DECLARATION  */
#line 463 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Body_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        102);
    }
#line 2514 "parser.tab.cpp"
    break;

  case 62: /* CLASS_MEMBER_DECLARATION: FIELD_DECLARATION  */
#line 471 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Member_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        103);
    }
#line 2523 "parser.tab.cpp"
    break;

  case 63: /* CLASS_MEMBER_DECLARATION: METHOD_DECLARATION  */
#line 476 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Member_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        104);
    }
#line 2532 "parser.tab.cpp"
    break;

  case 64: /* FIELD_DECLARATION: MODIFIERS TYPE VARIABLE_DECLARATORS SEMICOLON  */
#line 484 "./src/parser.ypp"
    { (yyval.a) = new ast("Field_Declaration", 
        vector<class ast*>({(yyvsp[-3].a), (yyvsp[-2].a), (yyvsp[-1].a),new ast(";",yylineno, 106)}),
        105, (yyvsp[-2].a)->datatype);
        sep_count++;
    }
#line 2542 "parser.tab.cpp"
    break;

  case 65: /* FIELD_DECLARATION: TYPE VARIABLE_DECLARATORS SEMICOLON  */
#line 490 "./src/parser.ypp"
    { (yyval.a) = new ast("Field_Declaration", 
        vector<class ast*>({(yyvsp[-2].a), (yyvsp[-1].a),new ast(";",yylineno, 108)}),
        107, (yyvsp[-2].a)->datatype);
        sep_count++;
    }
#line 2552 "parser.tab.cpp"
    break;

  case 66: /* VARIABLE_DECLARATORS: VARIABLE_DECLARATOR  */
#line 499 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Declarators", 
        vector<class ast*>({(yyvsp[0].a)}),
        109, (yyvsp[0].a)->datatype);
    }
#line 2561 "parser.tab.cpp"
    break;

  case 67: /* VARIABLE_DECLARATORS: VARIABLE_DECLARATORS COMMA VARIABLE_DECLARATOR  */
#line 504 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Declarators", 
        vector<class ast*>({(yyvsp[-2].a),new ast(",",yylineno, 111), (yyvsp[0].a)}),
        110, (yyvsp[-2].a)->datatype  );
        sep_count++;
    }
#line 2571 "parser.tab.cpp"
    break;

  case 68: /* VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID  */
#line 513 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Declarator", 
        vector<class ast*>({(yyvsp[0].a)}),
        112  );
    }
#line 2580 "parser.tab.cpp"
    break;

  case 69: /* VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID ASSIGN VARIABLE_INITIALIZER  */
#line 518 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Declarator", 
        vector<class ast*>({(yyvsp[-2].a),new ast("=",yylineno, 114), (yyvsp[0].a)}),
        113, (yyvsp[0].a)->datatype);
        opt_count++;
    }
#line 2590 "parser.tab.cpp"
    break;

  case 70: /* VARIABLE_DECLARATOR_ID: IDENTIFIER  */
#line 527 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Declarator_Id", 
        vector<class ast*>({new ast((yyvsp[0].string_val),yylineno, 116)}),
        115);
        id_count++;
    }
#line 2600 "parser.tab.cpp"
    break;

  case 71: /* VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET RBRACKET  */
#line 533 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Declarator_Id", 
        vector<class ast*>({(yyvsp[-2].a),new ast("[",yylineno, 118), new ast("]",yylineno, 119)}),
        117);
        sep_count++;
        sep_count++;
    }
#line 2611 "parser.tab.cpp"
    break;

  case 72: /* VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET EXPRESSION RBRACKET  */
#line 540 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Declarator_Id", 
        vector<class ast*>({(yyvsp[-3].a),new ast("[",yylineno, 555), (yyvsp[-1].a), new ast("]",yylineno, 556)}),
        554);
        sep_count++;
        sep_count++;
    }
#line 2622 "parser.tab.cpp"
    break;

  case 73: /* VARIABLE_INITIALIZER: EXPRESSION  */
#line 550 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Initializer", 
        vector<class ast*>({(yyvsp[0].a)}),
        120, (yyvsp[0].a)->datatype);
    }
#line 2631 "parser.tab.cpp"
    break;

  case 74: /* VARIABLE_INITIALIZER: ARRAY_INITIALIZER  */
#line 555 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Initializer", 
        vector<class ast*>({(yyvsp[0].a)}),
        121, (yyvsp[0].a)->datatype);
    }
#line 2640 "parser.tab.cpp"
    break;

  case 75: /* METHOD_DECLARATION: METHOD_HEADER METHOD_BODY  */
#line 563 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Declaration", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        122, (yyvsp[-1].a)->datatype);
    }
#line 2649 "parser.tab.cpp"
    break;

  case 76: /* METHOD_HEADER: MODIFIERS TYPE METHOD_DECLARATOR THROWS  */
#line 571 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({(yyvsp[-3].a), (yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        123, (yyvsp[-2].a)->datatype);
    }
#line 2658 "parser.tab.cpp"
    break;

  case 77: /* METHOD_HEADER: MODIFIERS TYPE METHOD_DECLARATOR  */
#line 576 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({(yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        124, (yyvsp[-1].a)->datatype);
    }
#line 2667 "parser.tab.cpp"
    break;

  case 78: /* METHOD_HEADER: TYPE METHOD_DECLARATOR THROWS  */
#line 581 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({(yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        125, (yyvsp[-2].a)->datatype);
    }
#line 2676 "parser.tab.cpp"
    break;

  case 79: /* METHOD_HEADER: TYPE METHOD_DECLARATOR  */
#line 586 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        126, (yyvsp[-1].a)->datatype);
    }
#line 2685 "parser.tab.cpp"
    break;

  case 80: /* METHOD_HEADER: MODIFIERS VOID METHOD_DECLARATOR THROWS  */
#line 591 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({(yyvsp[-3].a), new ast("void",yylineno, 128), (yyvsp[-1].a), (yyvsp[0].a)}),
        127);
        key_count++;
    }
#line 2695 "parser.tab.cpp"
    break;

  case 81: /* METHOD_HEADER: MODIFIERS VOID METHOD_DECLARATOR  */
#line 597 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({(yyvsp[-2].a), new ast("void",yylineno, 130), (yyvsp[0].a)}),
        129);
        key_count++;
    }
#line 2705 "parser.tab.cpp"
    break;

  case 82: /* METHOD_HEADER: VOID METHOD_DECLARATOR THROWS  */
#line 603 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({ new ast("void",yylineno, 132),(yyvsp[-1].a), (yyvsp[0].a)}),
        131);
        key_count++;
    }
#line 2715 "parser.tab.cpp"
    break;

  case 83: /* METHOD_HEADER: VOID METHOD_DECLARATOR  */
#line 609 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Header", 
        vector<class ast*>({new ast("void",yylineno, 134), (yyvsp[0].a)}),
        133);
        key_count++;
    }
#line 2725 "parser.tab.cpp"
    break;

  case 84: /* METHOD_DECLARATOR: IDENTIFIER LPAREN FORMAL_PARAMETER_LIST RPAREN  */
#line 620 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Declarator", 
        vector<class ast*>({new ast((yyvsp[-3].string_val),yylineno, 136),new ast("(",yylineno, 137), (yyvsp[-1].a),new ast(")",yylineno, 138)}),
        135);
        id_count++;
        sep_count++;
        sep_count++;
    }
#line 2737 "parser.tab.cpp"
    break;

  case 85: /* METHOD_DECLARATOR: IDENTIFIER LPAREN RPAREN  */
#line 628 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Declarator", 
        vector<class ast*>({new ast((yyvsp[-2].string_val),yylineno, 140), new ast("(",yylineno, 141),new ast(")",yylineno, 142)}),
        139);
        id_count++;
        sep_count++;
        sep_count++;
    }
#line 2749 "parser.tab.cpp"
    break;

  case 86: /* METHOD_DECLARATOR: IDENTIFIER LBRACKET RBRACKET LPAREN FORMAL_PARAMETER_LIST RPAREN  */
#line 636 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Declarator", 
        vector<class ast*>({new ast((yyvsp[-5].string_val),yylineno, 558), new ast ("[", yylineno, 559), new ast ("]", yylineno, 560), new ast("(",yylineno, 561), (yyvsp[-1].a), new ast(")",yylineno, 562)}),
        557);
        id_count++;
        sep_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 2763 "parser.tab.cpp"
    break;

  case 87: /* METHOD_DECLARATOR: IDENTIFIER LBRACKET RBRACKET LPAREN RPAREN  */
#line 646 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Declarator", 
        vector<class ast*>({new ast((yyvsp[-4].string_val),yylineno, 564), new ast ("[", yylineno, 565), new ast ("]", yylineno, 566), new ast("(",yylineno, 567),new ast(")",yylineno, 568)}),
        563);
        id_count++;
        sep_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 2777 "parser.tab.cpp"
    break;

  case 88: /* FORMAL_PARAMETER_LIST: FORMAL_PARAMETER  */
#line 659 "./src/parser.ypp"
    { (yyval.a) = new ast("Formal_Parameter_List", 
        vector<class ast*>({(yyvsp[0].a)}),
        146);
    }
#line 2786 "parser.tab.cpp"
    break;

  case 89: /* FORMAL_PARAMETER_LIST: FORMAL_PARAMETER_LIST COMMA FORMAL_PARAMETER  */
#line 664 "./src/parser.ypp"
    { (yyval.a) = new ast("Formal_Parameter_List", 
        vector<class ast*>({(yyvsp[-2].a), new ast(",",yylineno, 148),(yyvsp[0].a)}),
        147);
        sep_count++;
    }
#line 2796 "parser.tab.cpp"
    break;

  case 90: /* FORMAL_PARAMETER: TYPE VARIABLE_DECLARATOR_ID  */
#line 673 "./src/parser.ypp"
    { (yyval.a) = new ast("Formal_Parameter", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        149, (yyvsp[-1].a)->datatype);
    }
#line 2805 "parser.tab.cpp"
    break;

  case 91: /* THROWS: THROW CLASS_TYPE_LIST  */
#line 681 "./src/parser.ypp"
    { (yyval.a) = new ast("Throws", 
        vector<class ast*>({new ast("throws",yylineno, 151),(yyvsp[0].a)}),
        150);
        key_count++;
    }
#line 2815 "parser.tab.cpp"
    break;

  case 92: /* CLASS_TYPE_LIST: CLASS_TYPE  */
#line 690 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Type_List", 
        vector<class ast*>({(yyvsp[0].a)}),
        152);
    }
#line 2824 "parser.tab.cpp"
    break;

  case 93: /* CLASS_TYPE_LIST: CLASS_TYPE_LIST COMMA CLASS_TYPE  */
#line 695 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Type_List", 
        vector<class ast*>({(yyvsp[-2].a), new ast(",",yylineno, 154),(yyvsp[0].a)}),
        153);
        sep_count++;
    }
#line 2834 "parser.tab.cpp"
    break;

  case 94: /* METHOD_BODY: BLOCK  */
#line 704 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Body", 
        vector<class ast*>({(yyvsp[0].a)}),
        155);
    }
#line 2843 "parser.tab.cpp"
    break;

  case 95: /* METHOD_BODY: SEMICOLON  */
#line 709 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Body", 
        vector<class ast*>({new ast(";",yylineno, 157)}),
        156);
        sep_count++;
    }
#line 2853 "parser.tab.cpp"
    break;

  case 96: /* STATIC_INITIALIZER: STATIC BLOCK  */
#line 718 "./src/parser.ypp"
    { (yyval.a) = new ast("Static_Initializer", 
        vector<class ast*>({new ast("static",yylineno, 159),(yyvsp[0].a)}),
        158);
        key_count++;
    }
#line 2863 "parser.tab.cpp"
    break;

  case 97: /* CONSTRUCTOR_DECLARATION: MODIFIERS CONSTRUCTOR_DECLARATOR THROWS CONSTRUCTOR_BODY  */
#line 727 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Declaration", 
        vector<class ast*>({(yyvsp[-3].a), (yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        160);
    }
#line 2872 "parser.tab.cpp"
    break;

  case 98: /* CONSTRUCTOR_DECLARATION: MODIFIERS CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY  */
#line 732 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Declaration", 
        vector<class ast*>({(yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        161);
    }
#line 2881 "parser.tab.cpp"
    break;

  case 99: /* CONSTRUCTOR_DECLARATION: CONSTRUCTOR_DECLARATOR THROWS CONSTRUCTOR_BODY  */
#line 737 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Declaration", 
        vector<class ast*>({(yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        162);
    }
#line 2890 "parser.tab.cpp"
    break;

  case 100: /* CONSTRUCTOR_DECLARATION: CONSTRUCTOR_DECLARATOR CONSTRUCTOR_BODY  */
#line 742 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Declaration", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        163);
    }
#line 2899 "parser.tab.cpp"
    break;

  case 101: /* CONSTRUCTOR_DECLARATOR: SIMPLE_NAME LPAREN FORMAL_PARAMETER_LIST RPAREN  */
#line 750 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Declarator", 
        vector<class ast*>({(yyvsp[-3].a),new ast("(",yylineno, 165),(yyvsp[-1].a),new ast(")",yylineno, 166)}),
        164);
        sep_count++;
        sep_count++;
    }
#line 2910 "parser.tab.cpp"
    break;

  case 102: /* CONSTRUCTOR_BODY: LBRACE EXPLICIT_CONSTRUCTOR_INVOCATION BLOCK_STATEMENTS RBRACE  */
#line 760 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Body", 
        vector<class ast*>({new ast("{",yylineno, 168),(yyvsp[-2].a),(yyvsp[-1].a),new ast("}",yylineno, 169)}),
        167);
        sep_count++;
        sep_count++;
    }
#line 2921 "parser.tab.cpp"
    break;

  case 103: /* CONSTRUCTOR_BODY: LBRACE EXPLICIT_CONSTRUCTOR_INVOCATION RBRACE  */
#line 767 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Body", 
        vector<class ast*>({new ast("{",yylineno, 171),(yyvsp[-1].a),new ast("}",yylineno, 172)}),
        170);
        sep_count++;
        sep_count++;
    }
#line 2932 "parser.tab.cpp"
    break;

  case 104: /* CONSTRUCTOR_BODY: LBRACE BLOCK_STATEMENTS RBRACE  */
#line 774 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Body", 
        vector<class ast*>({new ast("{",yylineno, 174),(yyvsp[-1].a),new ast("}",yylineno, 175)}),
        173);
        sep_count++;
        sep_count++;
    }
#line 2943 "parser.tab.cpp"
    break;

  case 105: /* CONSTRUCTOR_BODY: LBRACE RBRACE  */
#line 781 "./src/parser.ypp"
    { (yyval.a) = new ast("Constructor_Body", 
        vector<class ast*>({new ast("{",yylineno, 177), new ast("}",yylineno, 178)}),
        176);
        sep_count++;
        sep_count++;
    }
#line 2954 "parser.tab.cpp"
    break;

  case 106: /* EXPLICIT_CONSTRUCTOR_INVOCATION: THIS LPAREN ARGUMENT_LIST RPAREN SEMICOLON  */
#line 791 "./src/parser.ypp"
    { (yyval.a) = new ast("Explicit_Constructor_Invocation", 
        vector<class ast*>({new ast("this",yylineno, 180),new ast("(",yylineno,181),(yyvsp[-2].a),new ast(")",yylineno, 182),new ast(";",yylineno, 183)}),
        179);
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 2966 "parser.tab.cpp"
    break;

  case 107: /* EXPLICIT_CONSTRUCTOR_INVOCATION: THIS LPAREN RPAREN SEMICOLON  */
#line 799 "./src/parser.ypp"
    { (yyval.a) = new ast("Explicit_Constructor_Invocation", 
        vector<class ast*>({new ast("this",yylineno,185),new ast("(",yylineno,186),new ast(")",yylineno,187),new ast(";",yylineno,188)}),
        184);
        key_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 2979 "parser.tab.cpp"
    break;

  case 108: /* EXPLICIT_CONSTRUCTOR_INVOCATION: SUPER LPAREN ARGUMENT_LIST RPAREN SEMICOLON  */
#line 808 "./src/parser.ypp"
    { (yyval.a) = new ast("Explicit_Constructor_Invocation", 
        vector<class ast*>({new ast("super",yylineno,190),new ast("(",yylineno,191),(yyvsp[-2].a),new ast(")",yylineno,192),new ast(";",yylineno,193)}),
        189);
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 2991 "parser.tab.cpp"
    break;

  case 109: /* EXPLICIT_CONSTRUCTOR_INVOCATION: SUPER LPAREN RPAREN SEMICOLON  */
#line 816 "./src/parser.ypp"
    { (yyval.a) = new ast("Explicit_Constructor_Invocation", 
        vector<class ast*>({new ast("super",yylineno,194),new ast("(",yylineno,196),new ast(")",yylineno,197),new ast(";",yylineno,198)}),
        194);
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 3003 "parser.tab.cpp"
    break;

  case 110: /* INTERFACE_DECLARATION: MODIFIERS INTERFACE IDENTIFIER EXTENDS_INTERFACES INTERFACE_BODY  */
#line 829 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Declaration", 
        vector<class ast*>({(yyvsp[-4].a),new ast("interface",yylineno,200), new ast((yyvsp[-2].string_val),yylineno,201), (yyvsp[-1].a), (yyvsp[0].a)}),
        199);
        key_count++;
        id_count++;
    }
#line 3014 "parser.tab.cpp"
    break;

  case 111: /* INTERFACE_DECLARATION: MODIFIERS INTERFACE IDENTIFIER INTERFACE_BODY  */
#line 836 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Declaration", 
        vector<class ast*>({(yyvsp[-3].a),new ast("interface",yylineno,203), new ast((yyvsp[-1].string_val),yylineno,204), (yyvsp[0].a)}),
        202);
        key_count++;
        id_count++;
    }
#line 3025 "parser.tab.cpp"
    break;

  case 112: /* INTERFACE_DECLARATION: INTERFACE IDENTIFIER EXTENDS_INTERFACES INTERFACE_BODY  */
#line 843 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Declaration", 
        vector<class ast*>({new ast("interface",yylineno,206), new ast((yyvsp[-2].string_val),yylineno,207), (yyvsp[-1].a), (yyvsp[0].a)}),
        205);
        key_count++;
        id_count++;
    }
#line 3036 "parser.tab.cpp"
    break;

  case 113: /* INTERFACE_DECLARATION: INTERFACE IDENTIFIER INTERFACE_BODY  */
#line 850 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Declaration", 
        vector<class ast*>({new ast("interface",yylineno,209), new ast((yyvsp[-1].string_val),yylineno,210), (yyvsp[0].a)}),
        208);
        key_count++;
        id_count++;
    }
#line 3047 "parser.tab.cpp"
    break;

  case 114: /* EXTENDS_INTERFACES: EXTENDS INTERFACE_TYPE  */
#line 860 "./src/parser.ypp"
    { (yyval.a) = new ast("Extends_Interfaces", 
        vector<class ast*>({new ast("extends",yylineno,212), (yyvsp[0].a)}),
        211);
        key_count++;
    }
#line 3057 "parser.tab.cpp"
    break;

  case 115: /* EXTENDS_INTERFACES: EXTENDS_INTERFACES COMMA INTERFACE_TYPE  */
#line 866 "./src/parser.ypp"
    { (yyval.a) = new ast("Extends_Interfaces", 
        vector<class ast*>({(yyvsp[-2].a), new ast(",",yylineno,214), (yyvsp[0].a)}),
        213);
        sep_count++;
    }
#line 3067 "parser.tab.cpp"
    break;

  case 116: /* INTERFACE_BODY: LBRACE INTERFACE_MEMBER_DECLARATIONS RBRACE  */
#line 875 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Body", 
        vector<class ast*>({ new ast("{",yylineno,216) ,(yyvsp[-1].a), new ast("}",yylineno,217)}),
        215);
        sep_count++;
        sep_count++;
    }
#line 3078 "parser.tab.cpp"
    break;

  case 117: /* INTERFACE_BODY: LBRACE RBRACE  */
#line 882 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Body", 
        vector<class ast*>({new ast("{",yylineno,219), new ast("}",yylineno,220)}),
        218);
        sep_count++;
        sep_count++;
    }
#line 3089 "parser.tab.cpp"
    break;

  case 118: /* INTERFACE_MEMBER_DECLARATIONS: INTERFACE_MEMBER_DECLARATION  */
#line 892 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Member_Declarations", 
        vector<class ast*>({(yyvsp[0].a)}),
        221);
    }
#line 3098 "parser.tab.cpp"
    break;

  case 119: /* INTERFACE_MEMBER_DECLARATIONS: INTERFACE_MEMBER_DECLARATIONS INTERFACE_MEMBER_DECLARATION  */
#line 897 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Member_Declarations", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        222);
    }
#line 3107 "parser.tab.cpp"
    break;

  case 120: /* INTERFACE_MEMBER_DECLARATION: CONSTANT_DECLARATION  */
#line 905 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Member_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        223);
    }
#line 3116 "parser.tab.cpp"
    break;

  case 121: /* INTERFACE_MEMBER_DECLARATION: ABSTRACT_METHOD_DECLARATION  */
#line 910 "./src/parser.ypp"
    { (yyval.a) = new ast("Interface_Member_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        224);
    }
#line 3125 "parser.tab.cpp"
    break;

  case 122: /* CONSTANT_DECLARATION: FIELD_DECLARATION  */
#line 918 "./src/parser.ypp"
    {
    (yyval.a) = new ast("Constant_Declaration", 
        vector<class ast*>({(yyvsp[0].a)}),
        225);
    }
#line 3135 "parser.tab.cpp"
    break;

  case 123: /* ABSTRACT_METHOD_DECLARATION: METHOD_HEADER SEMICOLON  */
#line 927 "./src/parser.ypp"
    { (yyval.a) = new ast("Abstract_Method_Declaration", 
        vector<class ast*>({(yyvsp[-1].a), new ast(";",yylineno,227)}),
        226);
        sep_count++;
    }
#line 3145 "parser.tab.cpp"
    break;

  case 124: /* ARRAY_INITIALIZER: LBRACE VARIABLE_INITIALIZERS RBRACE  */
#line 937 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Initializer", 
        vector<class ast*>({new ast("{",yylineno,229), (yyvsp[-1].a) , new ast("}",yylineno,230)}),
        228);
        sep_count++;
        sep_count++;
    }
#line 3156 "parser.tab.cpp"
    break;

  case 125: /* ARRAY_INITIALIZER: LBRACE VARIABLE_INITIALIZERS COMMA RBRACE  */
#line 944 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Initializer", 
        vector<class ast*>({new ast("{",yylineno,232), (yyvsp[-2].a) ,new ast(",",yylineno,233), new ast("}",yylineno,234)}),
        231);
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 3168 "parser.tab.cpp"
    break;

  case 126: /* ARRAY_INITIALIZER: LBRACE RBRACE  */
#line 952 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Initializer", 
        vector<class ast*>({new ast("{",yylineno,236) , new ast("}",yylineno,237)}),
        235);
        sep_count++;
        sep_count++;
    }
#line 3179 "parser.tab.cpp"
    break;

  case 127: /* VARIABLE_INITIALIZERS: VARIABLE_INITIALIZER  */
#line 962 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Initializers", 
        vector<class ast*>({(yyvsp[0].a)}),
        238, (yyvsp[0].a)->datatype);
    }
#line 3188 "parser.tab.cpp"
    break;

  case 128: /* VARIABLE_INITIALIZERS: VARIABLE_INITIALIZERS COMMA VARIABLE_INITIALIZER  */
#line 967 "./src/parser.ypp"
    { (yyval.a) = new ast("Variable_Initializers", 
        vector<class ast*>({(yyvsp[-2].a), new ast(",",yylineno,240), (yyvsp[0].a)}),
        239, (yyvsp[-2].a)->datatype);
        sep_count++;
    }
#line 3198 "parser.tab.cpp"
    break;

  case 129: /* BLOCK: LBRACE BLOCK_STATEMENTS RBRACE  */
#line 976 "./src/parser.ypp"
    { (yyval.a) = new ast("Block", 
        vector<class ast*>({new ast("{",yylineno,242), (yyvsp[-1].a), new ast("}",yylineno,243)}),
        241);
        sep_count++;
        sep_count++;
    }
#line 3209 "parser.tab.cpp"
    break;

  case 130: /* BLOCK: LBRACE RBRACE  */
#line 983 "./src/parser.ypp"
    { (yyval.a) = new ast("Block", 
        vector<class ast*>({new ast("{",yylineno,245), new ast("}",yylineno,246)}),
        244);
        sep_count++;
        sep_count++;
    }
#line 3220 "parser.tab.cpp"
    break;

  case 131: /* BLOCK_STATEMENTS: BLOCK_STATEMENT  */
#line 993 "./src/parser.ypp"
    { (yyval.a) = new ast("Block_Statements", 
        vector<class ast*>({(yyvsp[0].a)}),
        247);
    }
#line 3229 "parser.tab.cpp"
    break;

  case 132: /* BLOCK_STATEMENTS: BLOCK_STATEMENTS BLOCK_STATEMENT  */
#line 998 "./src/parser.ypp"
    { (yyval.a) = new ast("Block_Statements", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        248);
    }
#line 3238 "parser.tab.cpp"
    break;

  case 133: /* BLOCK_STATEMENT: LOCAL_VARIABLE_DECLARATION_STATEMENT  */
#line 1006 "./src/parser.ypp"
    { (yyval.a) = new ast("Block_Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        249);
    }
#line 3247 "parser.tab.cpp"
    break;

  case 134: /* BLOCK_STATEMENT: STATEMENT  */
#line 1011 "./src/parser.ypp"
    { (yyval.a) = new ast("Block_Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        250);
    }
#line 3256 "parser.tab.cpp"
    break;

  case 135: /* LOCAL_VARIABLE_DECLARATION_STATEMENT: LOCAL_VARIABLE_DECLARATION SEMICOLON  */
#line 1019 "./src/parser.ypp"
    { (yyval.a) = new ast("Local_Variable_Declaration_Statement", 
        vector<class ast*>({(yyvsp[-1].a), new ast(";",yylineno,252)}),
        251, (yyvsp[-1].a)->datatype);
        sep_count++;
    }
#line 3266 "parser.tab.cpp"
    break;

  case 136: /* LOCAL_VARIABLE_DECLARATION: TYPE VARIABLE_DECLARATORS  */
#line 1028 "./src/parser.ypp"
    { (yyval.a) = new ast("Local_Variable_Declaration", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        253, (yyvsp[-1].a)->datatype);
    }
#line 3275 "parser.tab.cpp"
    break;

  case 137: /* STATEMENT: STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT  */
#line 1036 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        254);
    }
#line 3284 "parser.tab.cpp"
    break;

  case 138: /* STATEMENT: LABELED_STATEMENT  */
#line 1041 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        255);
    }
#line 3293 "parser.tab.cpp"
    break;

  case 139: /* STATEMENT: IF_THEN_STATEMENT  */
#line 1046 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        256);
    }
#line 3302 "parser.tab.cpp"
    break;

  case 140: /* STATEMENT: IF_THEN_ELSE_STATEMENT  */
#line 1051 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        257);
    }
#line 3311 "parser.tab.cpp"
    break;

  case 141: /* STATEMENT: WHILE_STATEMENT  */
#line 1056 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        258);
    }
#line 3320 "parser.tab.cpp"
    break;

  case 142: /* STATEMENT: FOR_STATEMENT  */
#line 1061 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement", 
        vector<class ast*>({(yyvsp[0].a)}),
        259);
    }
#line 3329 "parser.tab.cpp"
    break;

  case 143: /* STATEMENT_NO_SHORT_IF: STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT  */
#line 1069 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_No_Short_If", 
        vector<class ast*>({(yyvsp[0].a)}),
        260);
    }
#line 3338 "parser.tab.cpp"
    break;

  case 144: /* STATEMENT_NO_SHORT_IF: LABELED_STATEMENT_NO_SHORT_IF  */
#line 1074 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_No_Short_If", 
        vector<class ast*>({(yyvsp[0].a)}),
        261);
    }
#line 3347 "parser.tab.cpp"
    break;

  case 145: /* STATEMENT_NO_SHORT_IF: IF_THEN_ELSE_STATEMENT_NO_SHORT_IF  */
#line 1079 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_No_Short_If", 
        vector<class ast*>({(yyvsp[0].a)}),
        262);
    }
#line 3356 "parser.tab.cpp"
    break;

  case 146: /* STATEMENT_NO_SHORT_IF: WHILE_STATEMENT_NO_SHORT_IF  */
#line 1084 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_No_Short_If", 
        vector<class ast*>({(yyvsp[0].a)}),
        263);
    }
#line 3365 "parser.tab.cpp"
    break;

  case 147: /* STATEMENT_NO_SHORT_IF: FOR_STATEMENT_NO_SHORT_IF  */
#line 1089 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_No_Short_If", 
        vector<class ast*>({(yyvsp[0].a)}),
        264);
    }
#line 3374 "parser.tab.cpp"
    break;

  case 148: /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT: BLOCK  */
#line 1097 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Without_Trailing_Substatement", 
        vector<class ast*>({(yyvsp[0].a)}),
        265);
    }
#line 3383 "parser.tab.cpp"
    break;

  case 149: /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT: EMPTY_STATEMENT  */
#line 1102 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Without_Trailing_Substatement", 
        vector<class ast*>({(yyvsp[0].a)}),
        266);
    }
#line 3392 "parser.tab.cpp"
    break;

  case 150: /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT: EXPRESSION_STATEMENT  */
#line 1107 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Without_Trailing_Substatement", 
        vector<class ast*>({(yyvsp[0].a)}),
        267);
    }
#line 3401 "parser.tab.cpp"
    break;

  case 151: /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT: BREAK_STATEMENT  */
#line 1112 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Without_Trailing_Substatement", 
        vector<class ast*>({(yyvsp[0].a)}),
        268);
    }
#line 3410 "parser.tab.cpp"
    break;

  case 152: /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT: CONTINUE_STATEMENT  */
#line 1117 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Without_Trailing_Substatement", 
        vector<class ast*>({(yyvsp[0].a)}),
        269);
    }
#line 3419 "parser.tab.cpp"
    break;

  case 153: /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT: DO_STATEMENT  */
#line 1122 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Without_Trailing_Substatement", 
        vector<class ast*>({(yyvsp[0].a)}),
        270);
    }
#line 3428 "parser.tab.cpp"
    break;

  case 154: /* STATEMENT_WITHOUT_TRAILING_SUBSTATEMENT: RETURN_STATEMENT  */
#line 1127 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Without_Trailing_Substatement", 
        vector<class ast*>({(yyvsp[0].a)}),
        271);
    }
#line 3437 "parser.tab.cpp"
    break;

  case 155: /* EMPTY_STATEMENT: SEMICOLON  */
#line 1135 "./src/parser.ypp"
    { (yyval.a) = new ast("Empty_Statement", 
        vector<class ast*>({new ast(";",yylineno,273)}),
        272);
        sep_count++;
    }
#line 3447 "parser.tab.cpp"
    break;

  case 156: /* LABELED_STATEMENT: IDENTIFIER COLON STATEMENT  */
#line 1144 "./src/parser.ypp"
    { (yyval.a) = new ast("Labeled_Statement", 
        vector<class ast*>({new ast((yyvsp[-2].string_val),yylineno,275),new ast(":",yylineno,276), (yyvsp[0].a)}),
        274);
        id_count++;
        sep_count++;
    }
#line 3458 "parser.tab.cpp"
    break;

  case 157: /* LABELED_STATEMENT_NO_SHORT_IF: IDENTIFIER COLON STATEMENT_NO_SHORT_IF  */
#line 1154 "./src/parser.ypp"
    { (yyval.a) = new ast("Labeled_Statement_No_Short_If", 
        vector<class ast*>({new ast((yyvsp[-2].string_val),yylineno,278),new ast(":",yylineno,279), (yyvsp[0].a)}),
        277);
        id_count++;
        sep_count++;
    }
#line 3469 "parser.tab.cpp"
    break;

  case 158: /* EXPRESSION_STATEMENT: STATEMENT_EXPRESSION SEMICOLON  */
#line 1164 "./src/parser.ypp"
    { (yyval.a) = new ast("Expression_Statement", 
        vector<class ast*>({(yyvsp[-1].a), new ast(";",yylineno,281)}),
        280);
        sep_count++;
    }
#line 3479 "parser.tab.cpp"
    break;

  case 159: /* STATEMENT_EXPRESSION: ASSIGNMENT  */
#line 1173 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        282);
    }
#line 3488 "parser.tab.cpp"
    break;

  case 160: /* STATEMENT_EXPRESSION: PRE_INCREMENT_EXPRESSION  */
#line 1178 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        283);
    }
#line 3497 "parser.tab.cpp"
    break;

  case 161: /* STATEMENT_EXPRESSION: PRE_DECREMENT_EXPRESSION  */
#line 1183 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        284);
    }
#line 3506 "parser.tab.cpp"
    break;

  case 162: /* STATEMENT_EXPRESSION: POST_INCREMENT_EXPRESSION  */
#line 1188 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        285);
    }
#line 3515 "parser.tab.cpp"
    break;

  case 163: /* STATEMENT_EXPRESSION: METHOD_INVOCATION  */
#line 1193 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        286);
    }
#line 3524 "parser.tab.cpp"
    break;

  case 164: /* STATEMENT_EXPRESSION: CLASS_INSTANCE_CREATION_EXPRESSION  */
#line 1198 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        287);
    }
#line 3533 "parser.tab.cpp"
    break;

  case 165: /* IF_THEN_STATEMENT: IF LPAREN EXPRESSION RPAREN STATEMENT  */
#line 1206 "./src/parser.ypp"
    { (yyval.a) = new ast("If_Then_Statement", 
        vector<class ast*>({new ast("if",yylineno,289),new ast("(",yylineno,290), (yyvsp[-2].a),new ast(")",yylineno,291), (yyvsp[0].a)}),
        288);
        key_count++;
        sep_count++;
        sep_count++;
    }
#line 3545 "parser.tab.cpp"
    break;

  case 166: /* IF_THEN_ELSE_STATEMENT: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT  */
#line 1217 "./src/parser.ypp"
    { (yyval.a) = new ast("If_Then_Else_Statement", 
        vector<class ast*>({new ast("if",yylineno,293),new ast("(",yylineno,294), (yyvsp[-4].a),new ast(")",yylineno,295), (yyvsp[-2].a), new ast("else",yylineno,296), (yyvsp[0].a)}),
        292);
        key_count++;
        sep_count++;
        sep_count++;
        key_count++;
    }
#line 3558 "parser.tab.cpp"
    break;

  case 167: /* IF_THEN_ELSE_STATEMENT_NO_SHORT_IF: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT_NO_SHORT_IF  */
#line 1229 "./src/parser.ypp"
    { (yyval.a) = new ast("If_Then_Else_Statement_No_Short_If", 
        vector<class ast*>({new ast("if",yylineno,198),new ast("(",yylineno,299), (yyvsp[-4].a),new ast(")",yylineno,300), (yyvsp[-2].a), new ast("else",yylineno,301), (yyvsp[0].a)}),
        297);
        key_count++;
        sep_count++;
        sep_count++;
        key_count++;
    }
#line 3571 "parser.tab.cpp"
    break;

  case 168: /* WHILE_STATEMENT: WHILE LPAREN EXPRESSION RPAREN STATEMENT  */
#line 1241 "./src/parser.ypp"
    { (yyval.a) = new ast("While_Statement", 
        vector<class ast*>({new ast("while",yylineno,303),new ast("(",yylineno,304), (yyvsp[-2].a),new ast(")",yylineno,305), (yyvsp[0].a)}),
        302);
        key_count++;
        sep_count++;
        sep_count++;
    }
#line 3583 "parser.tab.cpp"
    break;

  case 169: /* WHILE_STATEMENT_NO_SHORT_IF: WHILE LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF  */
#line 1252 "./src/parser.ypp"
    { (yyval.a) = new ast("While_Statement_No_Short_If", 
        vector<class ast*>({new ast("while",yylineno,307),new ast("(",yylineno,308), (yyvsp[-2].a),new ast(")",yylineno,309), (yyvsp[0].a)}),
        306);
        key_count++;
        sep_count++;
        sep_count++;
    }
#line 3595 "parser.tab.cpp"
    break;

  case 170: /* DO_STATEMENT: DO STATEMENT WHILE LPAREN EXPRESSION RPAREN SEMICOLON  */
#line 1263 "./src/parser.ypp"
    { (yyval.a) = new ast("Do_Statement", 
        vector<class ast*>({new ast("do",yylineno,311), (yyvsp[-5].a), new ast("while",yylineno,312),new ast("(",yylineno,313), (yyvsp[-2].a),new ast(")",yylineno,314) ,new ast(";",yylineno,315)}),
        310);
        key_count++;
        key_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 3609 "parser.tab.cpp"
    break;

  case 171: /* FOR_STATEMENT: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT  */
#line 1276 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Statement", 
        vector<class ast*>({new ast("for",yylineno,317), new ast("(",yylineno,318), (yyvsp[-6].a), new ast(";",yylineno,319), (yyvsp[-4].a), new ast(";",yylineno,320), (yyvsp[-2].a), new ast(")",yylineno,321), (yyvsp[0].a)}),
        316);
        key_count++;
        sep_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 3623 "parser.tab.cpp"
    break;

  case 172: /* FOR_STATEMENT: FOR LPAREN FOR_INIT_OPT SEMICOLON SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT  */
#line 1286 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Statement", 
        vector<class ast*>({new ast("for",yylineno,323), new ast("(",yylineno,324), (yyvsp[-5].a), new ast(";",yylineno,325), new ast(";",yylineno,326), (yyvsp[-2].a), new ast(")",yylineno,327), (yyvsp[0].a)}),
        322);
        key_count++;
        sep_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 3637 "parser.tab.cpp"
    break;

  case 173: /* FOR_STATEMENT_NO_SHORT_IF: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT_NO_SHORT_IF  */
#line 1299 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Statement_No_Short_If", 
        vector<class ast*>({new ast("for",yylineno,329), new ast("(",yylineno,330), (yyvsp[-6].a), new ast(";",yylineno,331), (yyvsp[-4].a), new ast(";",yylineno,332), (yyvsp[-2].a), new ast(")",yylineno,333), (yyvsp[0].a)}),
        328);
        key_count++;
        sep_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 3651 "parser.tab.cpp"
    break;

  case 174: /* FOR_STATEMENT_NO_SHORT_IF: FOR LPAREN FOR_INIT_OPT SEMICOLON SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT_NO_SHORT_IF  */
#line 1309 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Statement_No_Short_If", 
        vector<class ast*>({new ast("for",yylineno,335), new ast("(",yylineno,336), (yyvsp[-5].a), new ast(";",yylineno,337), new ast(";",yylineno,338), (yyvsp[-2].a), new ast(")",yylineno,339), (yyvsp[0].a)}),
        334);
        key_count++;
        sep_count++;
        sep_count++;
        sep_count++;
        sep_count++;
    }
#line 3665 "parser.tab.cpp"
    break;

  case 175: /* FOR_INIT_OPT: FOR_INIT  */
#line 1324 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Init_Opt", 
        vector<class ast*>({(yyvsp[0].a)}),
        340, (yyvsp[0].a)->datatype);
    }
#line 3674 "parser.tab.cpp"
    break;

  case 176: /* FOR_INIT_OPT: %empty  */
#line 1329 "./src/parser.ypp"
    { (yyval.a) = NULL;
    }
#line 3681 "parser.tab.cpp"
    break;

  case 177: /* FOR_INIT: STATEMENT_EXPRESSION_LIST  */
#line 1335 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Init", 
        vector<class ast*>({(yyvsp[0].a)}),
        341, (yyvsp[0].a)->datatype);
    }
#line 3690 "parser.tab.cpp"
    break;

  case 178: /* FOR_INIT: LOCAL_VARIABLE_DECLARATION  */
#line 1340 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Init", 
        vector<class ast*>({(yyvsp[0].a)}),
        342, (yyvsp[0].a)->datatype);
    }
#line 3699 "parser.tab.cpp"
    break;

  case 179: /* FOR_UPDATE_OPT: FOR_UPDATE  */
#line 1348 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Update_Opt", 
        vector<class ast*>({(yyvsp[0].a)}),
        343);
    }
#line 3708 "parser.tab.cpp"
    break;

  case 180: /* FOR_UPDATE_OPT: %empty  */
#line 1353 "./src/parser.ypp"
    { (yyval.a) = NULL;
    }
#line 3715 "parser.tab.cpp"
    break;

  case 181: /* FOR_UPDATE: STATEMENT_EXPRESSION_LIST  */
#line 1359 "./src/parser.ypp"
    { (yyval.a) = new ast("For_Update", 
        vector<class ast*>({(yyvsp[0].a)}),
        344);
    }
#line 3724 "parser.tab.cpp"
    break;

  case 182: /* STATEMENT_EXPRESSION_LIST: STATEMENT_EXPRESSION  */
#line 1367 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression_List", 
        vector<class ast*>({(yyvsp[0].a)}),
        345, (yyvsp[0].a)->datatype);
    }
#line 3733 "parser.tab.cpp"
    break;

  case 183: /* STATEMENT_EXPRESSION_LIST: STATEMENT_EXPRESSION_LIST COMMA STATEMENT_EXPRESSION  */
#line 1372 "./src/parser.ypp"
    { (yyval.a) = new ast("Statement_Expression_List", 
        vector<class ast*>({(yyvsp[-2].a), new ast(",",yylineno,347), (yyvsp[0].a)}),
        346, (yyvsp[-2].a)->datatype);
        sep_count++;
    }
#line 3743 "parser.tab.cpp"
    break;

  case 184: /* BREAK_STATEMENT: BREAK IDENTIFIER SEMICOLON  */
#line 1381 "./src/parser.ypp"
    { (yyval.a) = new ast("Break_Statement", 
        vector<class ast*>({new ast("break",yylineno,349), new ast((yyvsp[-1].string_val), yylineno,350), new ast(";",yylineno,351)}),
        348);
        key_count++;
        id_count++;
        sep_count++;
    }
#line 3755 "parser.tab.cpp"
    break;

  case 185: /* BREAK_STATEMENT: BREAK SEMICOLON  */
#line 1390 "./src/parser.ypp"
    { (yyval.a) = new ast("Break_Statement", 
        vector<class ast*>({new ast("break",yylineno,353), new ast(";",yylineno,354)}),
        352);
        key_count++;
        sep_count++;
    }
#line 3766 "parser.tab.cpp"
    break;

  case 186: /* CONTINUE_STATEMENT: CONTINUE IDENTIFIER SEMICOLON  */
#line 1400 "./src/parser.ypp"
    { (yyval.a) = new ast("Continue_Statement", 
        vector<class ast*>({new ast("continue",yylineno,356), new ast((yyvsp[-1].string_val), yylineno,357), new ast(";",yylineno,358)}),
        355);
        key_count++;
        id_count++;
        sep_count++;
    }
#line 3778 "parser.tab.cpp"
    break;

  case 187: /* CONTINUE_STATEMENT: CONTINUE SEMICOLON  */
#line 1409 "./src/parser.ypp"
    { (yyval.a) = new ast("Continue_Statement", 
        vector<class ast*>({new ast("continue",yylineno,360), new ast(";",yylineno,361)}),
        359);
        key_count++;
        sep_count++;
    }
#line 3789 "parser.tab.cpp"
    break;

  case 188: /* RETURN_STATEMENT: RETURN EXPRESSION SEMICOLON  */
#line 1419 "./src/parser.ypp"
    { (yyval.a) = new ast("Return_Statement", 
        vector<class ast*>({new ast("return",yylineno,363), (yyvsp[-1].a), new ast(";",yylineno,364)}),
        362, (yyvsp[-1].a)->datatype);
        key_count++;
        sep_count++;
    }
#line 3800 "parser.tab.cpp"
    break;

  case 189: /* RETURN_STATEMENT: RETURN SEMICOLON  */
#line 1426 "./src/parser.ypp"
    { (yyval.a) = new ast("Return_Statement", 
        vector<class ast*>({new ast("return",yylineno,366), new ast(";",yylineno,367)}),
        365);
        key_count++;
        sep_count++;
    }
#line 3811 "parser.tab.cpp"
    break;

  case 190: /* PRIMARY: PRIMARY_NO_NEW_ARRAY  */
#line 1437 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary", 
        vector<class ast*>({(yyvsp[0].a)}),
        368, (yyvsp[0].a)->datatype);
    }
#line 3820 "parser.tab.cpp"
    break;

  case 191: /* PRIMARY: ARRAY_CREATION_EXPRESSION  */
#line 1442 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary", 
        vector<class ast*>({(yyvsp[0].a)}),
        369, (yyvsp[0].a)->datatype);
    }
#line 3829 "parser.tab.cpp"
    break;

  case 192: /* PRIMARY_NO_NEW_ARRAY: LITERAL  */
#line 1450 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary_No_New_Array", 
        vector<class ast*>({(yyvsp[0].a)}),
        370, (yyvsp[0].a)->datatype);
    }
#line 3838 "parser.tab.cpp"
    break;

  case 193: /* PRIMARY_NO_NEW_ARRAY: LPAREN EXPRESSION RPAREN  */
#line 1455 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary_No_New_Array", 
        vector<class ast*>({new ast("(",yylineno,372), (yyvsp[-1].a), new ast(")",yylineno,373)}),
        371, (yyvsp[-1].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 3849 "parser.tab.cpp"
    break;

  case 194: /* PRIMARY_NO_NEW_ARRAY: CLASS_INSTANCE_CREATION_EXPRESSION  */
#line 1462 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary_No_New_Array", 
        vector<class ast*>({(yyvsp[0].a)}),
        374);
    }
#line 3858 "parser.tab.cpp"
    break;

  case 195: /* PRIMARY_NO_NEW_ARRAY: FIELD_ACCESS  */
#line 1467 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary_No_New_Array", 
        vector<class ast*>({(yyvsp[0].a)}),
        375, (yyvsp[0].a)->datatype);
    }
#line 3867 "parser.tab.cpp"
    break;

  case 196: /* PRIMARY_NO_NEW_ARRAY: ARRAY_ACCESS  */
#line 1472 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary_No_New_Array", 
        vector<class ast*>({(yyvsp[0].a)}),
        376, (yyvsp[0].a)->datatype);
    }
#line 3876 "parser.tab.cpp"
    break;

  case 197: /* PRIMARY_NO_NEW_ARRAY: METHOD_INVOCATION  */
#line 1477 "./src/parser.ypp"
    { (yyval.a) = new ast("Primary_No_New_Array", 
        vector<class ast*>({(yyvsp[0].a)}),
        377, (yyvsp[0].a)->datatype);
    }
#line 3885 "parser.tab.cpp"
    break;

  case 198: /* CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN ARGUMENT_LIST RPAREN  */
#line 1485 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Instance_Creation_Expression", 
        vector<class ast*>({new ast("new",yylineno,379), (yyvsp[-3].a), new ast("(",yylineno,380), (yyvsp[-1].a), new ast(")",yylineno,381)}),
        378);
        key_count++;
        sep_count++;
        sep_count++;
    }
#line 3897 "parser.tab.cpp"
    break;

  case 199: /* CLASS_INSTANCE_CREATION_EXPRESSION: NEW CLASS_TYPE LPAREN RPAREN  */
#line 1493 "./src/parser.ypp"
    { (yyval.a) = new ast("Class_Instance_Creation_Expression", 
        vector<class ast*>({new ast("new",yylineno,383), (yyvsp[-2].a), new ast("(",yylineno,384), new ast(")",yylineno,385)}),
        382);
        key_count++;
        sep_count++;
        sep_count++;
    }
#line 3909 "parser.tab.cpp"
    break;

  case 200: /* ARGUMENT_LIST: EXPRESSION  */
#line 1504 "./src/parser.ypp"
    { (yyval.a) = new ast("Argument_List", 
        vector<class ast*>({(yyvsp[0].a)}),
        386, (yyvsp[0].a)->datatype);
    }
#line 3918 "parser.tab.cpp"
    break;

  case 201: /* ARGUMENT_LIST: ARGUMENT_LIST COMMA EXPRESSION  */
#line 1509 "./src/parser.ypp"
    { (yyval.a) = new ast("Argument_List", 
        vector<class ast*>({(yyvsp[-2].a), new ast(",",yylineno,388), (yyvsp[0].a)}),
        387, (yyvsp[-2].a)->datatype);
        sep_count++;
    }
#line 3928 "parser.tab.cpp"
    break;

  case 202: /* ARRAY_CREATION_EXPRESSION: NEW PRIMITIVE_TYPE DIM_EXPRS  */
#line 1518 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Creation_Expression", 
        vector<class ast*>({new ast("new",yylineno,390),(yyvsp[-1].a), (yyvsp[0].a)}),
        389, (yyvsp[-1].a)->datatype);
        key_count++;
    }
#line 3938 "parser.tab.cpp"
    break;

  case 203: /* ARRAY_CREATION_EXPRESSION: NEW PRIMITIVE_TYPE DIM_EXPRS DIMS  */
#line 1524 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Creation_Expression", 
        vector<class ast*>({new ast("new",yylineno,392),(yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        391, (yyvsp[-2].a)->datatype);
        key_count++;
    }
#line 3948 "parser.tab.cpp"
    break;

  case 204: /* ARRAY_CREATION_EXPRESSION: NEW CLASS_OR_INTERFACE_TYPE DIM_EXPRS  */
#line 1530 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Creation_Expression", 
        vector<class ast*>({new ast("new",yylineno,394),(yyvsp[-1].a), (yyvsp[0].a)}),
        393, (yyvsp[-1].a)->datatype);
        key_count++;
    }
#line 3958 "parser.tab.cpp"
    break;

  case 205: /* ARRAY_CREATION_EXPRESSION: NEW CLASS_OR_INTERFACE_TYPE DIM_EXPRS DIMS  */
#line 1536 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Creation_Expression", 
        vector<class ast*>({new ast("new",yylineno,396),(yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        395, (yyvsp[-2].a)->datatype);
        key_count++;
    }
#line 3968 "parser.tab.cpp"
    break;

  case 206: /* DIM_EXPRS: DIM_EXPR  */
#line 1545 "./src/parser.ypp"
    { (yyval.a) = new ast("Dim_Exprs", 
        vector<class ast*>({(yyvsp[0].a)}),
        397);
    }
#line 3977 "parser.tab.cpp"
    break;

  case 207: /* DIM_EXPRS: DIM_EXPRS DIM_EXPR  */
#line 1550 "./src/parser.ypp"
    { (yyval.a) = new ast("Dim_Exprs", 
        vector<class ast*>({(yyvsp[-1].a), (yyvsp[0].a)}),
        398);
    }
#line 3986 "parser.tab.cpp"
    break;

  case 208: /* DIM_EXPR: LBRACKET EXPRESSION RBRACKET  */
#line 1558 "./src/parser.ypp"
    { (yyval.a) = new ast("Dim_Expr", 
        vector<class ast*>({new ast("[",yylineno,400), (yyvsp[-1].a), new ast("]",yylineno,401)}),
        399);
        sep_count++;
        sep_count++;
    }
#line 3997 "parser.tab.cpp"
    break;

  case 209: /* DIMS: LBRACKET RBRACKET  */
#line 1568 "./src/parser.ypp"
    { (yyval.a) = new ast("Dims", 
        vector<class ast*>({new ast("[",yylineno,403), new ast("]",yylineno,404)}),
        402);
        sep_count++;
        sep_count++;
    }
#line 4008 "parser.tab.cpp"
    break;

  case 210: /* DIMS: DIMS LBRACKET RBRACKET  */
#line 1575 "./src/parser.ypp"
    { (yyval.a) = new ast("Dims", 
        vector<class ast*>({(yyvsp[-2].a), new ast("[",yylineno,406), new ast("]",yylineno,407)}),
        405);
        sep_count++;
        sep_count++;
    }
#line 4019 "parser.tab.cpp"
    break;

  case 211: /* FIELD_ACCESS: PRIMARY DOT IDENTIFIER  */
#line 1585 "./src/parser.ypp"
    { (yyval.a) = new ast("Field_Access", 
        vector<class ast*>({(yyvsp[-2].a), new ast(".",yylineno,409), new ast((yyvsp[0].string_val),yylineno,410)}),
        408, (yyvsp[-2].a)->datatype);
        sep_count++;
        id_count++;
    }
#line 4030 "parser.tab.cpp"
    break;

  case 212: /* FIELD_ACCESS: SUPER DOT IDENTIFIER  */
#line 1592 "./src/parser.ypp"
    { (yyval.a) = new ast("Field_Access", 
        vector<class ast*>({(yyvsp[-2].a), new ast(".",yylineno,412), new ast((yyvsp[0].string_val),yylineno,413)}),
        411, (yyvsp[-2].a)->datatype);
        sep_count++;
        id_count++;
    }
#line 4041 "parser.tab.cpp"
    break;

  case 213: /* METHOD_INVOCATION: NAME LPAREN ARGUMENT_LIST RPAREN  */
#line 1602 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Invocation", 
        vector<class ast*>({(yyvsp[-3].a),new ast("(",yylineno,415), (yyvsp[-1].a), new ast(")",yylineno,416)}),
        414, (yyvsp[-3].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4052 "parser.tab.cpp"
    break;

  case 214: /* METHOD_INVOCATION: NAME LPAREN RPAREN  */
#line 1609 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Invocation", 
        vector<class ast*>({(yyvsp[-2].a),new ast("(",yylineno,418), new ast(")",yylineno,419)}),
        417, (yyvsp[-2].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4063 "parser.tab.cpp"
    break;

  case 215: /* METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN ARGUMENT_LIST RPAREN  */
#line 1616 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Invocation", 
        vector<class ast*>({(yyvsp[-5].a), new ast(".",yylineno,421), new ast((yyvsp[-3].string_val),yylineno,422), new ast("(",yylineno,423), (yyvsp[-1].a), new ast(")",yylineno,424)}),
        420, (yyvsp[-5].a)->datatype);
        sep_count++;
        id_count++;
        sep_count++;
        sep_count++;
    }
#line 4076 "parser.tab.cpp"
    break;

  case 216: /* METHOD_INVOCATION: PRIMARY DOT IDENTIFIER LPAREN RPAREN  */
#line 1625 "./src/parser.ypp"
    { (yyval.a) = new ast("Method_Invocation", 
        vector<class ast*>({(yyvsp[-4].a), new ast(".",yylineno,426), new ast((yyvsp[-2].string_val),yylineno,427), new ast("(",yylineno,428), new ast(")",yylineno,429)}),
        425, (yyvsp[-4].a)->datatype);
        sep_count++;
        id_count++;
        sep_count++;
        sep_count++;
    }
#line 4089 "parser.tab.cpp"
    break;

  case 217: /* ARRAY_ACCESS: PRIMARY_NO_NEW_ARRAY LBRACKET EXPRESSION RBRACKET  */
#line 1637 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Access", 
        vector<class ast*>({(yyvsp[-3].a), new ast("[",yylineno,431),(yyvsp[-1].a), new ast("]",yylineno,432)}),
        430, (yyvsp[-3].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4100 "parser.tab.cpp"
    break;

  case 218: /* ARRAY_ACCESS: NAME LBRACKET EXPRESSION RBRACKET  */
#line 1644 "./src/parser.ypp"
    { (yyval.a) = new ast("Array_Access", 
        vector<class ast*>({(yyvsp[-3].a), new ast("[",yylineno,434),(yyvsp[-1].a), new ast("]",yylineno,435)}),
        433, (yyvsp[-3].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4111 "parser.tab.cpp"
    break;

  case 219: /* POSTFIX_EXPRESSION: PRIMARY  */
#line 1654 "./src/parser.ypp"
    { (yyval.a) = new ast("Postfix_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        436, (yyvsp[0].a)->datatype);
    }
#line 4120 "parser.tab.cpp"
    break;

  case 220: /* POSTFIX_EXPRESSION: POST_INCREMENT_EXPRESSION  */
#line 1659 "./src/parser.ypp"
    { (yyval.a) = new ast("Postfix_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        437, (yyvsp[0].a)->datatype);
    }
#line 4129 "parser.tab.cpp"
    break;

  case 221: /* POSTFIX_EXPRESSION: POST_DECREMENT_EXPRESSION  */
#line 1664 "./src/parser.ypp"
    { (yyval.a) = new ast("Postfix_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        438, (yyvsp[0].a)->datatype);
    }
#line 4138 "parser.tab.cpp"
    break;

  case 222: /* POSTFIX_EXPRESSION: NAME  */
#line 1669 "./src/parser.ypp"
    {   (yyval.a) = new ast("Postfix_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        439, (yyvsp[0].a)->datatype);
    }
#line 4147 "parser.tab.cpp"
    break;

  case 223: /* POST_INCREMENT_EXPRESSION: POSTFIX_EXPRESSION PLUSPLUS  */
#line 1677 "./src/parser.ypp"
    { (yyval.a) = new ast("Post_Increment_Expression", 
        vector<class ast*>({(yyvsp[-1].a), new ast("++",yylineno,441)}),
        440, (yyvsp[-1].a)->datatype);
        opt_count++;
    }
#line 4157 "parser.tab.cpp"
    break;

  case 224: /* POST_DECREMENT_EXPRESSION: POSTFIX_EXPRESSION MINUSMINUS  */
#line 1686 "./src/parser.ypp"
    { (yyval.a) = new ast("Post_Decrement_Expression", 
        vector<class ast*>({(yyvsp[-1].a) , new ast("--",yylineno,443)}),
        442, (yyvsp[-1].a)->datatype);
        opt_count++;
    }
#line 4167 "parser.tab.cpp"
    break;

  case 225: /* UNARY_EXPRESSION: PRE_INCREMENT_EXPRESSION  */
#line 1695 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        444, (yyvsp[0].a)->datatype);
    }
#line 4176 "parser.tab.cpp"
    break;

  case 226: /* UNARY_EXPRESSION: PRE_DECREMENT_EXPRESSION  */
#line 1700 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        445, (yyvsp[0].a)->datatype);
    }
#line 4185 "parser.tab.cpp"
    break;

  case 227: /* UNARY_EXPRESSION: PLUS UNARY_EXPRESSION  */
#line 1705 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression", 
        vector<class ast*>({new ast("+",yylineno,447),(yyvsp[0].a)}),
        446, (yyvsp[0].a)->datatype);
        opt_count++;
    }
#line 4195 "parser.tab.cpp"
    break;

  case 228: /* UNARY_EXPRESSION: MINUS UNARY_EXPRESSION  */
#line 1711 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression", 
        vector<class ast*>({new ast("-",yylineno,449),(yyvsp[0].a)}),
        448, (yyvsp[0].a)->datatype);
        opt_count++;
    }
#line 4205 "parser.tab.cpp"
    break;

  case 229: /* UNARY_EXPRESSION: UNARY_EXPRESSION_NOT_PLUS_MINUS  */
#line 1717 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        450, (yyvsp[0].a)->datatype);
    }
#line 4214 "parser.tab.cpp"
    break;

  case 230: /* PRE_INCREMENT_EXPRESSION: PLUSPLUS UNARY_EXPRESSION  */
#line 1726 "./src/parser.ypp"
    { (yyval.a) = new ast("Pre_Increment_Expression", 
        vector<class ast*>({new ast("++",yylineno,452), (yyvsp[0].a)}),
        451, (yyvsp[0].a)->datatype);
    }
#line 4223 "parser.tab.cpp"
    break;

  case 231: /* PRE_DECREMENT_EXPRESSION: MINUSMINUS UNARY_EXPRESSION  */
#line 1734 "./src/parser.ypp"
    { (yyval.a) = new ast("Pre_Decrement_Expression", 
        vector<class ast*>({new ast("--",yylineno,454), (yyvsp[0].a)}),
        453, (yyvsp[0].a)->datatype);
        opt_count++;
    }
#line 4233 "parser.tab.cpp"
    break;

  case 232: /* UNARY_EXPRESSION_NOT_PLUS_MINUS: POSTFIX_EXPRESSION  */
#line 1743 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression_Not_Plus_Minus", 
        vector<class ast*>({(yyvsp[0].a)}),
        455, (yyvsp[0].a)->datatype);
    }
#line 4242 "parser.tab.cpp"
    break;

  case 233: /* UNARY_EXPRESSION_NOT_PLUS_MINUS: BANG UNARY_EXPRESSION  */
#line 1748 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression_Not_Plus_Minus", 
        vector<class ast*>({ new ast("!",yylineno,457), (yyvsp[0].a)}),
        456, (yyvsp[0].a)->datatype);
        opt_count++;
    }
#line 4252 "parser.tab.cpp"
    break;

  case 234: /* UNARY_EXPRESSION_NOT_PLUS_MINUS: TILDE UNARY_EXPRESSION  */
#line 1754 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression_Not_Plus_Minus", 
        vector<class ast*>({ new ast("~",yylineno,459), (yyvsp[0].a)}),
        458, (yyvsp[0].a)->datatype);
        opt_count++;
    }
#line 4262 "parser.tab.cpp"
    break;

  case 235: /* UNARY_EXPRESSION_NOT_PLUS_MINUS: CAST_EXPRESSION  */
#line 1760 "./src/parser.ypp"
    { (yyval.a) = new ast("Unary_Expression_Not_Plus_Minus", 
        vector<class ast*>({(yyvsp[0].a)}),
        460, (yyvsp[0].a)->datatype);
    }
#line 4271 "parser.tab.cpp"
    break;

  case 236: /* CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE DIMS RPAREN UNARY_EXPRESSION  */
#line 1768 "./src/parser.ypp"
    { (yyval.a) = new ast("Cast_Expression", 
        vector<class ast*>({ new ast("(",yylineno,462), (yyvsp[-3].a), (yyvsp[-2].a), new ast(")",yylineno,463) , (yyvsp[0].a)}),
        461, (yyvsp[-3].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4282 "parser.tab.cpp"
    break;

  case 237: /* CAST_EXPRESSION: LPAREN NAME DIMS RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS  */
#line 1775 "./src/parser.ypp"
    { (yyval.a) = new ast("Cast_Expression", 
        vector<class ast*>({ new ast("(",yylineno,465), (yyvsp[-3].a), (yyvsp[-2].a), new ast(")",yylineno,466) , (yyvsp[0].a)}),
        464, (yyvsp[-3].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4293 "parser.tab.cpp"
    break;

  case 238: /* CAST_EXPRESSION: LPAREN PRIMITIVE_TYPE RPAREN UNARY_EXPRESSION  */
#line 1782 "./src/parser.ypp"
    { (yyval.a) = new ast("Cast_Expression", 
        vector<class ast*>({ new ast("(",yylineno,468), (yyvsp[-2].a), new ast(")",yylineno,469) , (yyvsp[0].a)}),
        467, (yyvsp[-2].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4304 "parser.tab.cpp"
    break;

  case 239: /* CAST_EXPRESSION: LPAREN EXPRESSION RPAREN UNARY_EXPRESSION_NOT_PLUS_MINUS  */
#line 1789 "./src/parser.ypp"
    { (yyval.a) = new ast("Cast_Expression", 
        vector<class ast*>({ new ast("(",yylineno,471), (yyvsp[-2].a), new ast(")",yylineno,472) , (yyvsp[0].a)}),
        470, (yyvsp[-2].a)->datatype);
        sep_count++;
        sep_count++;
    }
#line 4315 "parser.tab.cpp"
    break;

  case 240: /* MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION MUL UNARY_EXPRESSION  */
#line 1799 "./src/parser.ypp"
    { (yyval.a) = new ast("Multiplicative_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("*",yylineno,474), (yyvsp[0].a)}),
        473, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4325 "parser.tab.cpp"
    break;

  case 241: /* MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION DIV UNARY_EXPRESSION  */
#line 1805 "./src/parser.ypp"
    { (yyval.a) = new ast("Multiplicative_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("/",yylineno,476), (yyvsp[0].a)}),
        475, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4335 "parser.tab.cpp"
    break;

  case 242: /* MULTIPLICATIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION MOD UNARY_EXPRESSION  */
#line 1811 "./src/parser.ypp"
    { (yyval.a) = new ast("Multiplicative_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("%",yylineno,478), (yyvsp[0].a)}),
        477, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4345 "parser.tab.cpp"
    break;

  case 243: /* MULTIPLICATIVE_EXPRESSION: UNARY_EXPRESSION  */
#line 1817 "./src/parser.ypp"
    { (yyval.a) = new ast("Multiplicative_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        479, (yyvsp[0].a)->datatype);
    }
#line 4354 "parser.tab.cpp"
    break;

  case 244: /* ADDITIVE_EXPRESSION: ADDITIVE_EXPRESSION PLUS MULTIPLICATIVE_EXPRESSION  */
#line 1825 "./src/parser.ypp"
    { (yyval.a) = new ast("Additive_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("+",yylineno,481),(yyvsp[0].a)}),
        480, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4364 "parser.tab.cpp"
    break;

  case 245: /* ADDITIVE_EXPRESSION: ADDITIVE_EXPRESSION MINUS MULTIPLICATIVE_EXPRESSION  */
#line 1831 "./src/parser.ypp"
    { (yyval.a) = new ast("Additive_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("-",yylineno,483),(yyvsp[0].a)}),
        482, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4374 "parser.tab.cpp"
    break;

  case 246: /* ADDITIVE_EXPRESSION: MULTIPLICATIVE_EXPRESSION  */
#line 1837 "./src/parser.ypp"
    { (yyval.a) = new ast("Additive_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        484, (yyvsp[0].a)->datatype);
    }
#line 4383 "parser.tab.cpp"
    break;

  case 247: /* SHIFT_EXPRESSION: SHIFT_EXPRESSION LEFT_SHIFT ADDITIVE_EXPRESSION  */
#line 1845 "./src/parser.ypp"
    { (yyval.a) = new ast("Shift_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("<<",yylineno,486),(yyvsp[0].a)}),
        485, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4393 "parser.tab.cpp"
    break;

  case 248: /* SHIFT_EXPRESSION: SHIFT_EXPRESSION RIGHT_SHIFT ADDITIVE_EXPRESSION  */
#line 1851 "./src/parser.ypp"
    { (yyval.a) = new ast("Shift_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast(">>",yylineno,488),(yyvsp[0].a)}),
        487, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4403 "parser.tab.cpp"
    break;

  case 249: /* SHIFT_EXPRESSION: ADDITIVE_EXPRESSION  */
#line 1857 "./src/parser.ypp"
    { (yyval.a) = new ast("Shift_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        489, (yyvsp[0].a)->datatype);
    }
#line 4412 "parser.tab.cpp"
    break;

  case 250: /* SHIFT_EXPRESSION: SHIFT_EXPRESSION UNSIGNED_RIGHT_SHIFT ADDITIVE_EXPRESSION  */
#line 1862 "./src/parser.ypp"
    { (yyval.a) = new ast("Shift_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast(">>>",yylineno,491),(yyvsp[0].a)}),
        490, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4422 "parser.tab.cpp"
    break;

  case 251: /* RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION LESS SHIFT_EXPRESSION  */
#line 1871 "./src/parser.ypp"
    { (yyval.a) = new ast("Relational_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("<",yylineno,493),(yyvsp[0].a)}),
        492, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4432 "parser.tab.cpp"
    break;

  case 252: /* RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION GREATER SHIFT_EXPRESSION  */
#line 1877 "./src/parser.ypp"
    { (yyval.a) = new ast("Relational_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast(">",yylineno,495),(yyvsp[0].a)}),
        494, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4442 "parser.tab.cpp"
    break;

  case 253: /* RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION LESS_EQUAL SHIFT_EXPRESSION  */
#line 1883 "./src/parser.ypp"
    { (yyval.a) = new ast("Relational_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("<=",yylineno,497),(yyvsp[0].a)}),
        496, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4452 "parser.tab.cpp"
    break;

  case 254: /* RELATIONAL_EXPRESSION: RELATIONAL_EXPRESSION GREATER_EQUAL SHIFT_EXPRESSION  */
#line 1889 "./src/parser.ypp"
    { (yyval.a) = new ast("Relational_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast(">=",yylineno,499),(yyvsp[0].a)}),
        498, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4462 "parser.tab.cpp"
    break;

  case 255: /* RELATIONAL_EXPRESSION: SHIFT_EXPRESSION  */
#line 1895 "./src/parser.ypp"
    { (yyval.a) = new ast("Relational_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        500, (yyvsp[0].a)->datatype);
    }
#line 4471 "parser.tab.cpp"
    break;

  case 256: /* EQUALITY_EXPRESSION: EQUALITY_EXPRESSION EQEQ RELATIONAL_EXPRESSION  */
#line 1903 "./src/parser.ypp"
    { (yyval.a) = new ast("Equality_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("==",yylineno,502),(yyvsp[0].a)}),
        501, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4481 "parser.tab.cpp"
    break;

  case 257: /* EQUALITY_EXPRESSION: EQUALITY_EXPRESSION NOT_EQUAL RELATIONAL_EXPRESSION  */
#line 1909 "./src/parser.ypp"
    { (yyval.a) = new ast("Equality_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("!=",yylineno,504),(yyvsp[0].a)}),
        503, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4491 "parser.tab.cpp"
    break;

  case 258: /* EQUALITY_EXPRESSION: RELATIONAL_EXPRESSION  */
#line 1915 "./src/parser.ypp"
    { (yyval.a) = new ast("Equality_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        505, (yyvsp[0].a)->datatype);
    }
#line 4500 "parser.tab.cpp"
    break;

  case 259: /* AND_EXPRESSION: AND_EXPRESSION AND EQUALITY_EXPRESSION  */
#line 1923 "./src/parser.ypp"
    { (yyval.a) = new ast("And_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("&",yylineno,507),(yyvsp[0].a)}),
        506, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4510 "parser.tab.cpp"
    break;

  case 260: /* AND_EXPRESSION: EQUALITY_EXPRESSION  */
#line 1929 "./src/parser.ypp"
    { (yyval.a) = new ast("And_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        508, (yyvsp[0].a)->datatype);
    }
#line 4519 "parser.tab.cpp"
    break;

  case 261: /* EXCLUSIVE_OR_EXPRESSION: EXCLUSIVE_OR_EXPRESSION XOR AND_EXPRESSION  */
#line 1937 "./src/parser.ypp"
    { (yyval.a) = new ast("Exclusive_Or_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("^",yylineno,510),(yyvsp[0].a)}),
        509, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4529 "parser.tab.cpp"
    break;

  case 262: /* EXCLUSIVE_OR_EXPRESSION: AND_EXPRESSION  */
#line 1943 "./src/parser.ypp"
    { (yyval.a) = new ast("Exclusive_Or_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        511, (yyvsp[0].a)->datatype);
    }
#line 4538 "parser.tab.cpp"
    break;

  case 263: /* INCLUSIVE_OR_EXPRESSION: INCLUSIVE_OR_EXPRESSION OR EXCLUSIVE_OR_EXPRESSION  */
#line 1951 "./src/parser.ypp"
    { (yyval.a) = new ast("Inclusive_Or_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("|",yylineno,513),(yyvsp[0].a)}),
        512, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4548 "parser.tab.cpp"
    break;

  case 264: /* INCLUSIVE_OR_EXPRESSION: EXCLUSIVE_OR_EXPRESSION  */
#line 1957 "./src/parser.ypp"
    { (yyval.a) = new ast("Inclusive_Or_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        514, (yyvsp[0].a)->datatype);
    }
#line 4557 "parser.tab.cpp"
    break;

  case 265: /* CONDITIONAL_AND_EXPRESSION: CONDITIONAL_AND_EXPRESSION ANDAND INCLUSIVE_OR_EXPRESSION  */
#line 1965 "./src/parser.ypp"
    { (yyval.a) = new ast("Conditional_And_Expression", 
        vector<class ast*>({(yyvsp[-2].a), new ast("&&",yylineno,516),(yyvsp[0].a)}),
        515, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4567 "parser.tab.cpp"
    break;

  case 266: /* CONDITIONAL_AND_EXPRESSION: INCLUSIVE_OR_EXPRESSION  */
#line 1971 "./src/parser.ypp"
    { (yyval.a) = new ast("Conditional_And_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        517, (yyvsp[0].a)->datatype);
    }
#line 4576 "parser.tab.cpp"
    break;

  case 267: /* CONDITIONAL_OR_EXPRESSION: CONDITIONAL_OR_EXPRESSION OROR CONDITIONAL_AND_EXPRESSION  */
#line 1979 "./src/parser.ypp"
    { (yyval.a) = new ast("Conditional_Or_Expression", 
        vector<class ast*>({(yyvsp[-2].a),new ast("||",yylineno,519), (yyvsp[0].a)}),
        518, (yyvsp[-2].a)->datatype);
        opt_count++;
    }
#line 4586 "parser.tab.cpp"
    break;

  case 268: /* CONDITIONAL_OR_EXPRESSION: CONDITIONAL_AND_EXPRESSION  */
#line 1985 "./src/parser.ypp"
    { (yyval.a) = new ast("Conditional_Or_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        520, (yyvsp[0].a)->datatype);
    }
#line 4595 "parser.tab.cpp"
    break;

  case 269: /* CONDITIONAL_EXPRESSION: CONDITIONAL_OR_EXPRESSION QMARK EXPRESSION COLON CONDITIONAL_EXPRESSION  */
#line 1993 "./src/parser.ypp"
    { (yyval.a) = new ast("Conditional_Expression", 
        vector<class ast*>({(yyvsp[-4].a), new ast("?",yylineno,522),(yyvsp[-2].a), new ast(":",yylineno,523),(yyvsp[0].a)}),
        521, (yyvsp[-4].a)->datatype);
        opt_count++;
        sep_count++;
    }
#line 4606 "parser.tab.cpp"
    break;

  case 270: /* CONDITIONAL_EXPRESSION: CONDITIONAL_OR_EXPRESSION  */
#line 2000 "./src/parser.ypp"
    { (yyval.a) = new ast("Conditional_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        524, (yyvsp[0].a)->datatype);
    }
#line 4615 "parser.tab.cpp"
    break;

  case 271: /* ASSIGNMENT_EXPRESSION: ASSIGNMENT  */
#line 2008 "./src/parser.ypp"
     {
        (yyval.a) = new ast("Assignment_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        525, (yyvsp[0].a)->datatype);
     }
#line 4625 "parser.tab.cpp"
    break;

  case 272: /* ASSIGNMENT_EXPRESSION: CONDITIONAL_EXPRESSION  */
#line 2014 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        526, (yyvsp[0].a)->datatype);
    }
#line 4634 "parser.tab.cpp"
    break;

  case 273: /* ASSIGNMENT: LEFT_HAND_SIDE ASSIGNMENT_OPERATOR ASSIGNMENT_EXPRESSION  */
#line 2022 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment", 
        vector<class ast*>({(yyvsp[-2].a), (yyvsp[-1].a), (yyvsp[0].a)}),
        527, (yyvsp[-2].a)->datatype);
    }
#line 4643 "parser.tab.cpp"
    break;

  case 274: /* LEFT_HAND_SIDE: NAME  */
#line 2030 "./src/parser.ypp"
    { (yyval.a) = new ast("Left_Hand_Side", 
        vector<class ast*>({(yyvsp[0].a)}),
        528, (yyvsp[0].a)->datatype);
    }
#line 4652 "parser.tab.cpp"
    break;

  case 275: /* LEFT_HAND_SIDE: FIELD_ACCESS  */
#line 2035 "./src/parser.ypp"
    { (yyval.a) = new ast("Left_Hand_Side", 
        vector<class ast*>({(yyvsp[0].a)}),
        529, (yyvsp[0].a)->datatype);
    }
#line 4661 "parser.tab.cpp"
    break;

  case 276: /* LEFT_HAND_SIDE: ARRAY_ACCESS  */
#line 2040 "./src/parser.ypp"
    { (yyval.a) = new ast("Left_Hand_Side", 
        vector<class ast*>({(yyvsp[0].a)}),
        530, (yyvsp[0].a)->datatype);
    }
#line 4670 "parser.tab.cpp"
    break;

  case 277: /* ASSIGNMENT_OPERATOR: ASSIGN  */
#line 2048 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("=",yylineno, 532)}),
        531);
        opt_count++;
    }
#line 4680 "parser.tab.cpp"
    break;

  case 278: /* ASSIGNMENT_OPERATOR: MUL_ASSIGN  */
#line 2054 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("*=",yylineno, 534)}),
        533);
        // opt_count++;
        opt_count++;
    }
#line 4691 "parser.tab.cpp"
    break;

  case 279: /* ASSIGNMENT_OPERATOR: DIV_ASSIGN  */
#line 2061 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("/=",yylineno,536)}),
        535);
        // opt_count++;
        opt_count++;
    }
#line 4702 "parser.tab.cpp"
    break;

  case 280: /* ASSIGNMENT_OPERATOR: MOD_ASSIGN  */
#line 2068 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("%=",yylineno,538)}),
        537);
        // opt_count++;
        opt_count++;
    }
#line 4713 "parser.tab.cpp"
    break;

  case 281: /* ASSIGNMENT_OPERATOR: ADD_ASSIGN  */
#line 2075 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("+=",yylineno,540)}),
        539);
        // opt_count++;
        opt_count++;
    }
#line 4724 "parser.tab.cpp"
    break;

  case 282: /* ASSIGNMENT_OPERATOR: SUB_ASSIGN  */
#line 2082 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("-=",yylineno,542)}),
        541);
        opt_count++;
        // opt_count++;
    }
#line 4735 "parser.tab.cpp"
    break;

  case 283: /* ASSIGNMENT_OPERATOR: LEFT_ASSIGN  */
#line 2089 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("<<=",yylineno,544)}),
        543);
        opt_count++;
        // opt_count++;

    }
#line 4747 "parser.tab.cpp"
    break;

  case 284: /* ASSIGNMENT_OPERATOR: RIGHT_ASSIGN  */
#line 2097 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast(">>=",yylineno,546)}),
        545);
        opt_count++;
        // opt_count++;
    }
#line 4758 "parser.tab.cpp"
    break;

  case 285: /* ASSIGNMENT_OPERATOR: AND_ASSIGN  */
#line 2104 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("&=",yylineno,548)}),
        547);
        opt_count++;
        // opt_count++;
    }
#line 4769 "parser.tab.cpp"
    break;

  case 286: /* ASSIGNMENT_OPERATOR: XOR_ASSIGN  */
#line 2111 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("^=",yylineno,550)}),
        549);
        opt_count++;
        // opt_count++;
    }
#line 4780 "parser.tab.cpp"
    break;

  case 287: /* ASSIGNMENT_OPERATOR: OR_ASSIGN  */
#line 2118 "./src/parser.ypp"
    { (yyval.a) = new ast("Assignment_Operator", 
        vector<class ast*>({new ast("|=",yylineno,552)}),
        551);
        opt_count++;
        // opt_count++;
    }
#line 4791 "parser.tab.cpp"
    break;

  case 288: /* EXPRESSION: ASSIGNMENT_EXPRESSION  */
#line 2128 "./src/parser.ypp"
    { (yyval.a) = new ast("Expression", 
        vector<class ast*>({(yyvsp[0].a)}),
        553, (yyvsp[0].a)->datatype);
    }
#line 4800 "parser.tab.cpp"
    break;


#line 4804 "parser.tab.cpp"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 2133 "./src/parser.ypp"


#pragma GCC diagnostic pop

// Max ID: 568
