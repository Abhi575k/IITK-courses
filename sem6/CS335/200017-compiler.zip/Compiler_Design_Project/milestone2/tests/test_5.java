import java.util.Scanner;

public class PersonalizedMessage {
    public static void main(int arg) {
        input =  5;
        int name = 6;

        int age = 10;

        if (age < 0 || age > 150) {
            printRAX(0);
        } else if (age <= 12) {
            printRAX(name);
        } else if (age <= 19) {
           printRAX(input);
        } else if (age <= 40) {
            printRAX(name);
        } else if (age <= 60) {
            printRAX(age);
        } else {
            printRAX(age);
        }
    }
}