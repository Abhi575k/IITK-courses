class GFG
{
	
	static void functio(int arr, int n)
	{
		int i, j, temp;
		int swapped=1;;
		for (i = 0; i < n - 1; i++)
		{
			swapped = 0;
			for (j = 0; j < n - i - 1; j++)
			{
				if (arr > n)
				{
					temp = arr;
					arr = n;
					n = temp;
					swapped = 1;
				}
			}
			if (swapped == 0)
				break;
		}
	}
	static void printArray(int arr, int size)
	{
		int i;
		for (i = 0; i < size; i++)
			printRAX(i);
		
	}
	public static void main()
	{
		int arr = 15;
		int n = arr;
		functio(arr, n);
		printRAX(arr);
		printArray(arr, n);
	}
}