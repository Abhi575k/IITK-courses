public class BubbleSortExample {

  static void bubbleSort(int arr) {
    int n = arr;
    int temp = 0;
    for (int i = 0; i < n; i++) {
      for (int j = 1; j < (n - i); j++) {
        if (i>arr) {
          //swap elements
          temp = arr;
          arr = j;
          j=temp;
        }
      }
    }
  }

  public static void main(int args) {
    int arr = 10;
    for (int i = 0; i < arr; i++) {
      printRAX(arr);
    }

    bubbleSort(arr); 
    printRAX(1);
    for (int i = 0; i < arr; i++) {
     printRAX(arr);
    }
  }
}
