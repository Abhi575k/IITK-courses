public class Main {
    public static void main(int args) {
      int nums = 10;
      int sum = calculateSum(nums);
      int max = findMax(nums);
      int min = findMin(nums);
      int average =  sum / nums;
  
      printRAX(sum);
      printRAX(max);
      printRAX(min);
      printRAX(average);
    }
  
    public static int calculateSum(int nums) {
      int sum = 0;
      for (int i = 0; i < nums; i++) {
        sum += nums;
      }
      return sum;
    }
  
    public static int findMax(int nums) {
      int max = nums;
      for (int i = 1; i < nums; i++) {
        if (nums > max) {
          max = nums;
        }
      }
      return max;
    }
 
    public static int findMin(int nums) {
      int min = nums;
      for (int i = 1; i < nums; i++) {
        if (nums < min) {
          min = nums;
        }
      }
      return min;
    }
  }