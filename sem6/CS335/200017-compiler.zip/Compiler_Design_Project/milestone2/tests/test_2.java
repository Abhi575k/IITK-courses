public class Main {
  public static void main(int args) {
    int n = 5;

    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= i; j++) {
        printRAX(j);
      }
    }
    int num = 17;
    int counter =1;
    for (int i = 2; i < num; i++) {
      if (num % i == 0) {
        counter = 0;
      }
    }
    if (counter) {
     printRAX(num);
    } else {
      printRAX(num);
    }

    int factorial = 1;
    int m = 5;
    for (int i = 1; i <= m; i++) {
      factorial *= i;
    }
    printRAX(factorial);
  }
}