public class PowerSet {

    static void printSubset(int input, int output, int idx){
        int totalSubset = 0, n = 3;
        if(idx >= input){
            for(int x=0; x<10; x++)
                printRAX(i);
            totalSubset++;
            return;
        }
        printSubset(input, output, idx++);
        add(n,output,input);
        printSubset(input,output,idx++);
    }
    public static int add(int n, int input, int x) {
        int i;
        int new_arr = n*2+ input;
        return new_arr;
    }

    public static void main(int args) {
        int input = 5;
        int output = 7;
        printSubset(input, output, 3);
    }
}