public class main{
    static void printArray(int arr[], int size)
	{
		int i = 3;
	}
}
