public class Main {
  public static void main(int args) {
    int nums = 11;
    int min = nums-1;
    for (int i = 1; i < nums; i++) {
      if (nums > min) {
        min = min-1;
      }
    }
    printRAX(min);
    int max = nums+1;
    for (int i = 1; i < nums; i++) {
      if (nums < max) {
        max = max-1;
      }
    }
    printRAX(max);

    int sum = 0;
    for (int i = 0; i < nums; i++) {
      sum += nums;
    }
    int a =5;
    int b =7;
    int average =  a + b;
   printRAX(average);
   printRAX(sum);
  }
}