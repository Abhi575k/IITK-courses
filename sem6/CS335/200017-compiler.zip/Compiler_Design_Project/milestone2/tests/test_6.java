public class Main {
    public static void main(int arg) {
      int num1 = 5;
      int num2 = 10;
      int pi = 3;
      int istrue = 1;
  
     
      int sum = num1 + num2;
      int diff = num2 - num1;
      int product = num1 * num2;
      int quotient =  num2 / num1;
      int remainder = num2 % num1;
      printRAX(sum);
      printRAX(diff);
      printRAX(product);
      printRAX(quotient);
      printRAX(remainder);
      if (isTrue) {
        printRAX(0);
      } else {
        printRAX(1);
      }
      int radius = 2;
      int area = pi * radius*radius;
     printRAX(area);
    }
  }