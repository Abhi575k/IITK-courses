#ifndef TYPECHECK_H
#define TYPECHECK_H

#include <bits/stdc++.h>
#include "symboltable.h"

using namespace std;

// bool intCheck(ast *ast_root, SymbolTable *rootTable);
// bool longCheck(ast *ast_root, SymbolTable *rootTable);
// bool floatCheck(ast *ast_root, SymbolTable *rootTable);
// bool doubleCheck(ast *ast_root, SymbolTable *rootTable);
// bool boolCheck(ast *ast_root, SymbolTable *rootTable);
// int countBracketSequence(ast *ast_root, SymbolTable *rootTable);
// bool checkAllTypes(ast *ast_root, SymbolTable *rootTable);

string getType(ast *ast_root);

string getVarName(ast *ast_root);

int getDimsCount(ast *ast_root);

#endif