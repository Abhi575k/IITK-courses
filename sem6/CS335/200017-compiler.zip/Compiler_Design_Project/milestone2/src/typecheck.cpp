#include "typecheck.h"

// bool intCheck(ast *ast_root, SymbolTable *rootTable){
//     bool flag = true;
//     if(ast_root->datatype){
//         if(ast_root->label=="int"||rootTable->isInt(ast_root->label))
//             return true;
//         else
//             return false;
//     }

//     for (auto u: ast_root->children){
//         flag &= intCheck(u, rootTable);
//     }
//     return flag;
// }
// bool longCheck(ast *ast_root, SymbolTable *rootTable){
//     bool flag = true;
//     if(ast_root->datatype){
//         if(ast_root->label=="long"||rootTable->isLong(ast_root->label))
//             return true;
//         else
//             return false;
//     }

//     for (auto u: ast_root->children){
//         flag &= intCheck(u, rootTable);
//     }
//     return flag;
// }
// bool floatCheck(ast *ast_root, SymbolTable *rootTable){
//     bool flag = true;
//     if(ast_root->datatype){
//         if(ast_root->label=="float"||rootTable->isFloat(ast_root->label))
//             return true;
//         else
//             return false;
//     }

//     for (auto u: ast_root->children){
//         flag &= intCheck(u, rootTable);
//     }
//     return flag;
// }
// bool doubleCheck(ast *ast_root, SymbolTable *rootTable){
//     bool flag = true;
//     if(ast_root->datatype){
//         if(ast_root->label=="double"||rootTable->isDouble(ast_root->label))
//             return true;
//         else
//             return false;
//     }

//     for (auto u: ast_root->children){
//         flag &= intCheck(u, rootTable);
//     }
//     return flag;
// }
// bool boolCheck(ast *ast_root, SymbolTable *rootTable){
//     bool flag = true;
//     if(ast_root->datatype){
//         if(ast_root->label=="bool"||rootTable->isBool(ast_root->label))
//             return true;
//         else
//             return false;
//     }

//     for (auto u: ast_root->children){
//         flag &= intCheck(u, rootTable);
//     }
//     return flag;
// }
// int countBracketSequence(ast *ast_root, SymbolTable *rootTable)
// {
//     bool flag = true;
//     if (ast_root->label == "Bracket_Sequence1")
//     {
//         flag = flag && intCheck(ast_root->children[1], rootTable);
//         if (flag)
//             return 1 + countBracketSequence(ast_root->children[3], rootTable);
//         else
//             yyerror("Error in Bracket Sequence (Index not integer)");
//     }
//     else if (ast_root->label == "Bracket_Sequence2")
//     {
//         return 1 + countBracketSequence(ast_root->children[2], rootTable);
//     }
//     else if (ast_root->label == "Bracket_Sequence3")
//     {
//         flag = flag && intCheck(ast_root->children[1], rootTable);
//         if (flag)
//             return 1;
//         else
//             yyerror("Error in Bracket Sequence (Index not integer)");
//     }
//     return 1;
// }

// bool checkAllTypes(ast *ast_root, SymbolTable *rootTable){
//     // if(intCheck(ast_root, rootTable)||longCheck(ast_root, rootTable)||floatCheck(ast_root, rootTable)||doubleCheck(ast_root, rootTable)||boolCheck(ast_root, rootTable)){
//     //     return true;
//     // }
//     // else
//     // {
//     //     return false;
//     // }
//     return true;
// }


// // VARIABLE_INITIALIZER: EXPRESSION
//     else if(root->id == 120){
//         root->children[0]->datatype = root->datatype;
//         createSymbolTable(root->children[0], rootTable);
//     }
//     // VARIABLE_INITIALIZER: ARRAY_INITIALIZER

string getType(ast *ast_root){
    if(ast_root==NULL) return "";
    // TYPE: PRIMITIVE_TYPE
    if(ast_root->id == 10){
        return getType(ast_root->children[0]);
    }
    // TYPE: REFERENCE_TYPE
    else if(ast_root->id == 11){
        return getType(ast_root->children[0]);
    }
    // PRIMITIVE_TYPE: NUMERIC_TYPE
    else if(ast_root->id == 12){
        return getType(ast_root->children[0]);
    }
    // PRIMITIVE_TYPE: BOOLEAN
    else if(ast_root->id == 13){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: INT
    else if(ast_root->id == 15){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: FLOAT
    else if(ast_root->id == 17){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: LONG
    else if(ast_root->id == 19){
        return ast_root->children[0]->label;
    }
    // NUMERIC_TYPE: DOUBLE
    else if(ast_root->id == 21){
        return ast_root->children[0]->label;
    }
    // REFERENCE_TYPE: CLASS_OR_INTERFACE_TYPE
    else if(ast_root->id == 24){
        return getType(ast_root->children[0]);
    }
    // REFERENCE_TYPE: ARRAY_TYPE
    else if(ast_root->id == 25){
        return getType(ast_root->children[0]);
    }
    // CLASS_OR_INTERFACE_TYPE: NAME
    else if(ast_root->id == 26){
        return getType(ast_root->children[0]);
    }
    // NAME: SIMPLE_NAME
    else if(ast_root->id == 32){
        return getType(ast_root->children[0]);
    }
    // SIMPLE_NAME: IDENTIFIER
    else if(ast_root->id == 35){
        return ast_root->children[0]->label;
    }
    // ARRAY_TYPE: PRIMITIVE_TYPE DIMS
    else if(ast_root->id == 29){
        return getType(ast_root->children[0]);
    }
    // ARRAY_TYPE: NAME DIMS
    else if(ast_root->id == 30){
        return getType(ast_root->children[0]);
    }
    // ARRAY_TYPE: ARRAY_TYPE DIMS
    else if(ast_root->id == 31){
        return getType(ast_root->children[0]);
    }
    else{
        yyerror("Error in getType: Type not supported\n");
    }
    return "";
}

string getVarName(ast *ast_root){
    // LEFT_HAND_SIDE: NAME
    if(ast_root->id == 528){
        return getVarName(ast_root->children[0]);
    }
    // LEFT_HAND_SIDE: FIELD_ACCESS
    else if(ast_root->id == 529){
        return getVarName(ast_root->children[0]);
    }
    // LEFT_HAND_SIDE: ARRAY_ACCESS
    else if(ast_root->id == 530){
        return getVarName(ast_root->children[0]);
    }
    // FIELD_ACCESS: PRIMARY DOT IDENTIFIER
    else if(ast_root->id == 533){
        return getVarName(ast_root->children[0]) + "." + ast_root->children[2]->label;
    }
    // NAME: SIMPLE_NAME
    else if(ast_root->id == 32){
        return getVarName(ast_root->children[0]);
    }
    // NAME: QUALIFIED_NAME
    else if(ast_root->id == 33){
        return getVarName(ast_root->children[0]);
    }
    // SIMPLE_NAME: IDENTIFIER
    else if(ast_root->id == 35){
        return ast_root->children[0]->label;
    }
    // QUALIFIED_NAME: NAME DOT IDENTIFIER
    else if(ast_root->id == 36){
        return getVarName(ast_root->children[0]) + "." + ast_root->children[2]->label;
    }
    // PRIMARY: PRIMARY_NO_NEW_ARRAY
    else if(ast_root->id == 368){
        return getVarName(ast_root->children[0]);
    }
    // PRIMARY_NO_NEW_ARRAY: FIELD_ACCESS
    else if(ast_root->id == 375){
        return getVarName(ast_root->children[0]);
    }
    // // PRIMARY_NO_NEW_ARRAY: ARRAY_ACCESS
    // else if(ast_root->id == 376){
    //     return getVarName(ast_root->children[0]);
    // }
    // // ARRAY_ACCESS: PRIMARY_NO_NEW_ARRAY LBRACKET EXPRESSION RBRACKET
    // else if(ast_root->id == 430){
    //     return getVarName(ast_root->children[0]);
    // }
    // // ARRAY_ACCESS: NAME LBRACKET EXPRESSION RBRACKET
    // else if(ast_root->id == 433){
    //     return getVarName(ast_root->children[0]);
    // }
    // // PRIMARY: ARRAY_CREATION_EXPRESSION
    // else if(ast_root->id == 369){
    //     return getVarName(ast_root->children[0]);
    // }

}

int getDimsCount(ast *ast_root){
    // TYPE: REFERENCE_TYPE
    if(ast_root->id == 11){
        return getDimsCount(ast_root->children[0]);
    }
    // REFERENCE_TYPE: ARRAY_TYPE
    else if(ast_root->id == 25){
        return getDimsCount(ast_root->children[0]);
    }
    // ARRAY_TYPE: PRIMITIVE_TYPE DIMS
    else if(ast_root->id == 29){
        return getDimsCount(ast_root->children[1]);
    }
    // ARRAY_TYPE: NAME DIMS
    else if(ast_root->id == 30){
        return getDimsCount(ast_root->children[1]);
    }
    // ARRAY_TYPE: ARRAY_TYPE DIMS
    else if(ast_root->id == 31){
        return getDimsCount(ast_root->children[1]);
    }
    // DIMS: LBRACKET RBRACKET
    else if(ast_root->id == 402){
        return 1;
    }
    // DIMS: DIMS LBRACKET RBRACKET
    else if(ast_root->id == 405){
        return 1 + getDimsCount(ast_root->children[0]);
    }
    return 0;
}