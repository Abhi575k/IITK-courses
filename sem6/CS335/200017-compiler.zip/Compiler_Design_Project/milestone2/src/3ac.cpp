#include "3ac.h"

int t_cnt = 0;

threeAC::threeAC(){
    this->op = "";
    this->arg1 = "";
    this->arg2 = "";
    this->result = "";
    this->lineno = 0;
}

void threeAC::print(){
    for (auto u : threeACList) u->print();
    cout << result << " = " << arg1 << " " << op << " " << arg2 << "\n";
    return;
}

void create3AC(ast *root, threeAC *tac){
    // EXPRESSION: ASSIGNMENT_EXPRESSION
    if(root==NULL) return;
    if(root->id == 553){
        create3AC(root->children[0], tac);
    }
    // ASSIGNMENT_EXPRESSION: ASSIGNMENT
    else if(root->id == 525){
        tac->result = getVarName(root->children[0]);
        // ASSIGNMENT_OPERATOR: ASSIGN
        if(root->children[1]->children[0]->id == 531){
            tac->arg1 = "$0";
            tac->op = " + ";
        }
        // ASSIGNMENT_OPERATOR: MUL_ASSIGN
        else if(root->children[1]->children[0]->id == 533){
            tac->arg1 = tac->result;
            tac->op = " * ";
        }
        // ASSIGNMENT_OPERATOR: DIV_ASSIGN
        else if(root->children[1]->children[0]->id == 535){
            tac->arg1 = tac->result;
            tac->op = " / ";
        }
        // ASSIGNMENT_OPERATOR: MOD_ASSIGN
        else if(root->children[1]->children[0]->id == 537){
            tac->arg1 = tac->result;
            tac->op = " % ";
        }
        // ASSIGNMENT_OPERATOR: ADD_ASSIGN
        else if(root->children[1]->children[0]->id == 539){
            tac->arg1 = tac->result;
            tac->op = " + ";
        }
        // ASSIGNMENT_OPERATOR: SUB_ASSIGN
        else if(root->children[1]->children[0]->id == 541){
            tac->arg1 = tac->result;
            tac->op = " - ";
        }
        // ASSIGNMENT_OPERATOR: LEFT_ASSIGN
        else if(root->children[1]->children[0]->id == 543){
            tac->arg1 = tac->result;
            tac->op = " << ";
        }
        // ASSIGNMENT_OPERATOR: RIGHT_ASSIGN
        else if(root->children[1]->children[0]->id == 545){
            tac->arg1 = tac->result;
            tac->op = " >> ";
        }
        // ASSIGNMENT_OPERATOR: AND_ASSIGN
        else if(root->children[1]->children[0]->id == 547){
            tac->arg1 = tac->result;
            tac->op = " & ";
        }
        // ASSIGNMENT_OPERATOR: XOR_ASSIGN
        else if(root->children[1]->children[0]->id == 549){
            tac->arg1 = tac->result;
            tac->op = " ^ ";
        }
        // ASSIGNMENT_OPERATOR: OR_ASSIGN
        else if(root->children[1]->children[0]->id == 551){
            tac->arg1 = tac->result;
            tac->op = " | ";
        }
        tac->arg2 = "t" + to_string(t_cnt);
        t_cnt++;
        threeAC *tac0 = new threeAC();
        tac0->result = tac->arg2;
        tac->threeACList.push_back(tac0);
        create3AC(root->children[2], tac0);
        
    }
    // ASSIGNMENT_EXPRESSION: CONDITIONAL_EXPRESSION
    else{
        create3AC(root->children[0], tac);
    }
}