#ifndef COMMANDLINE_H
#define COMMANDLINE_H

#include <bits/stdc++.h>

using namespace std;

bool checkArguements(int argc, char* argv[]);

bool checkHelp(int argc, char* argv[]);

bool printAst(int argc, char* argv[], string &ast_output_file);

bool checkInput(int argc, char* argv[], string &input_file);

bool checkOutput(int argc, char* argv[], string &output_file);

bool checkVerbose(int argc, char* argv[]);

void printError();

void printUsage();

#endif