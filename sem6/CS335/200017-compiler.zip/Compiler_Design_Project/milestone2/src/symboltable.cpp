#include "symboltable.h"

int if_count = 0;
int while_count = 0;
int for_count = 0;

SymbolTableEntry::SymbolTableEntry(string name, string type, int line_of_dec, bool is_variable, int dims)
{
    this->name = name;
    this->type = type;
    this->line_of_dec = line_of_dec;
    this->dims = dims;
    this->is_variable = is_variable;
}

void SymbolTableEntry::printEntry()
{
    cout << name << "\t" << type << "\t" << line_of_dec << "\t" << dims << "\t";
    if (is_variable)
        cout << "true" << endl;
    else
        cout << "false" << endl;
}

SymbolTable::SymbolTable(SymbolTable *parent, string name)
{
    this->parent = parent;
    this->name = name;
}

void SymbolTable::addChild(SymbolTable *child)
{
    children.push_back(child);
}

void SymbolTable::addEntry(SymbolTableEntry *entry)
{
    entries[entry->name] = entry;
}

SymbolTableEntry *SymbolTable::getEntry(string name)
{
    if (entries.find(name) != entries.end())
    {
        return entries[name];
    }
    else
    {
        return NULL;
    }
}

void SymbolTable::printTable()
{
    if(name == "Global Table") cout << "\n[VERBOSE]Table Content:\n\n";
    cout << "Symbol Table: " << name << endl;
    cout << "Name\tType\tLine\tDims\tVariable" << endl;
    for (auto u : entries)
    {
        u.second->printEntry();
    }
    if(function_params.size()!=0){
        cout << "Function Params: " << name << endl;
        cout << "Name\tType\tLine\tDims\tVariable" << endl;
        for (auto u: function_params){
            u->printEntry();
        }
    }
    for (auto u : children)
    {
        u->printTable();
    }
}

void SymbolTable::printTableTree(int level)
{
    if(name == "Global Table") cout << "\n[VERBOSE]Table Structure:\n\n";
    for (int i = 0; i < level; i++)
        cout << "\t";
    cout << name << endl;
    for (auto u : children)
    {
        u->printTableTree(level + 1);
    }
}

void SymbolTable::addParam(SymbolTableEntry *param)
{
    function_params.push_back(param);
}

bool SymbolTable::isInt(string name)
{
    if (entries.find(name) != entries.end())
    {
        if (entries[name]->type == "int"&&entries[name]->is_variable)
            return true;
        else
            return false;
    }
    else
    {
        if(parent == NULL)
            return false;
        else
            return parent->isInt(name);
    }
}

bool SymbolTable::isLong(string name)
{
    if (entries.find(name) != entries.end())
    {
        if (entries[name]->type == "long"&&entries[name]->is_variable)
            return true;
        else
            return false;
    }
    else
    {
        if(parent == NULL)
            return false;
        else
            return parent->isLong(name);
    }
}

bool SymbolTable::isFloat(string name)
{
    if (entries.find(name) != entries.end())
    {
        if (entries[name]->type == "float"&&entries[name]->is_variable)
            return true;
        else
            return false;
    }
    else
    {
        if(parent == NULL)
            return false;
        else
            return parent->isFloat(name);
    }
}

bool SymbolTable::isDouble(string name)
{
    if (entries.find(name) != entries.end())
    {
        if (entries[name]->type == "double"&&entries[name]->is_variable)
            return true;
        else
            return false;
    }
    else
    {
        if(parent == NULL)
            return false;
        else
            return parent->isDouble(name);
    }
}

bool SymbolTable::isBool(string name){
    if (entries.find(name) != entries.end())
    {
        if (entries[name]->type == "bool"&&entries[name]->is_variable)
            return true;
        else
            return false;
    }
    else
    {
        if(parent == NULL)
            return false;
        else
            return parent->isBool(name);
    }
}

void checkEntry(SymbolTable *rootTable, string name)
{
    if (rootTable == NULL)
    {
        return;
    }
    else if (rootTable->getEntry(name) != NULL)
    {
        yyerror("Variable already declared");
    }
    else
    {
        checkEntry(rootTable->parent, name);
    }
    return;
}

void createSymbolTable(ast *root, SymbolTable *rootTable)
{
    // EXPRESSION
    if (root->id == 553)
    {
        if (0)
            yyerror("Type mismatch", root->children[0]->lineno);
        else
        {
            for (auto u : root->children)
            {
                createSymbolTable(u, rootTable);
            }
        }
    }
    // CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER SUPER INTERFACES CLASS_BODY
    else if (root->id == 64)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[2]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[5], child);
    }
    // CLASS_DECLARATION: CLASS IDENTIFIER SUPER INTERFACES CLASS_BODY
    else if(root->id == 67)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[1]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[4], child);
    }
    // CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER SUPER CLASS_BODY
    else if(root->id == 70)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[2]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[4], child);
    }
    // CLASS_DECLARATION: CLASS IDENTIFIER SUPER CLASS_BODY
    else if(root->id == 73)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[1]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[3], child);
    }
    // CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER INTERFACES CLASS_BODY
    else if(root->id == 76)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[2]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[4], child);
    }
    // CLASS_DECLARATION: CLASS IDENTIFIER CLASS_BODY
    else if(root->id == 79)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[1]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[2], child);
    }
    // CLASS_DECLARATION: MODIFIERS CLASS IDENTIFIER CLASS_BODY
    else if(root->id == 82)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[2]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[3], child);
    }
    // CLASS_DECLARATION: CLASS IDENTIFIER INTERFACES CLASS_BODY
    else if(root->id == 85)
    {
        SymbolTable *child;
        child = new SymbolTable(rootTable, root->children[1]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[3], child);
    }
    // CLASS_BODY: LBRACE CLASS_BODY_DECLARATIONS RBRACE
    else if(root->id == 95){
        createSymbolTable(root->children[1], rootTable);
    }
    // CLASS_BODY_DECLARATIONS: CLASS_BODY_DECLARATION
    else if(root->id == 98){
        createSymbolTable(root->children[0], rootTable);
    }
    // CLASS_BODY_DECLARATIONS: CLASS_BODY_DECLARATIONS CLASS_BODY_DECLARATION
    else if(root->id == 99){
        createSymbolTable(root->children[0], rootTable);
        createSymbolTable(root->children[1], rootTable);
    }
    // CLASS_BODY_DECLARATION: CLASS_MEMBER_DECLARATION
    else if(root->id == 100){
        createSymbolTable(root->children[0], rootTable);
    }
    // CLASS_BODY_DECLARATION: STATIC_INITIALIZER
    else if(root->id == 101){
        createSymbolTable(root->children[0], rootTable);
    }
    // CLASS_BODY_DECLARATION: CONSTRUCTOR_DECLARATION
    else if(root->id == 102){
        createSymbolTable(root->children[0], rootTable);
    }
    // CLASS_MEMBER_DECLARATION: FIELD_DECLARATION
    else if(root->id == 103){
        createSymbolTable(root->children[0], rootTable);
    }
    // CLASS_MEMBER_DECLARATION: METHOD_DECLARATION
    else if(root->id == 104){
        createSymbolTable(root->children[0], rootTable);
    }
    // FIELD_DECLARATION: MODIFIERS TYPE VARIABLE_DECLARATORS SEMICOLON
    else if(root->id == 105){
        root->children[2]->datatype = getType(root->children[1]);
        root->children[2]->dims = getDimsCount(root->children[1]);
        createSymbolTable(root->children[2], rootTable);
    }
    // FIELD_DECLARATION: TYPE VARIABLE_DECLARATORS SEMICOLON
    else if(root->id == 107){
        root->children[1]->datatype = getType(root->children[0]);
        root->children[1]->dims = getDimsCount(root->children[0]);
        createSymbolTable(root->children[1], rootTable);
    }
    // VARIABLE_DECLARATORS: VARIABLE_DECLARATOR
    else if(root->id == 109){
        root->children[0]->datatype = root->datatype;
        createSymbolTable(root->children[0], rootTable);
    }
    // VARIABLE_DECLARATORS: VARIABLE_DECLARATORS COMMA VARIABLE_DECLARATOR
    else if(root->id == 110){
        root->children[0]->datatype = root->datatype;
        root->children[2]->datatype = root->datatype;
        createSymbolTable(root->children[0], rootTable);
        createSymbolTable(root->children[2], rootTable);
    }
    // VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID
    else if(root->id == 112){
        root->children[0]->datatype = root->datatype;
        createSymbolTable(root->children[0], rootTable);
    }
    // VARIABLE_DECLARATOR: VARIABLE_DECLARATOR_ID ASSIGN VARIABLE_INITIALIZER
    else if(root->id == 113){
        root->children[0]->datatype = root->datatype;
        root->children[2]->datatype = root->datatype;
        createSymbolTable(root->children[0], rootTable);
        createSymbolTable(root->children[2], rootTable);
    }
    // VARIABLE_DECLARATOR_ID: IDENTIFIER
    else if(root->id == 115){
        root->children[0]->datatype = root->datatype;
        root->children[0]->dims = root->dims;
        root->children[0]->is_function_param = root->is_function_param;
        createSymbolTable(root->children[0], rootTable);
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET RBRACKET
    else if(root->id == 117){
        root->children[0]->datatype = root->datatype;
        root->children[0]->dims = root->dims + 1;
        root->children[0]->is_function_param = root->is_function_param;
        createSymbolTable(root->children[0], rootTable);
    }
    // VARIABLE_DECLARATOR_ID: VARIABLE_DECLARATOR_ID LBRACKET EXPRESSION RBRACKET
    else if(root->id == 554){
        root->children[0]->datatype = root->datatype;
        root->children[0]->dims = root->dims + 1;
        root->children[0]->is_function_param = root->is_function_param;
        createSymbolTable(root->children[0], rootTable);
    }
    // IDENTIFIER
    else if(root->id == 116){
        SymbolTableEntry *child = new SymbolTableEntry(root->label, root->datatype, root->lineno, true, root->dims);
        if(root->is_function_param) rootTable->addParam(child);
        else rootTable->addEntry(child);
    }
    // METHOD_DECLARATION: METHOD_HEADER METHOD_BODY
    else if(root->id == 122){
        SymbolTable *child;
        if(root->children[0]->id==123 || root->children[0]->id==124 || root->children[0]->id==127 || root->children[0]->id==129){
            child = new SymbolTable(rootTable, root->children[0]->children[2]->children[0]->label);
        }
        else child = new SymbolTable(rootTable, root->children[0]->children[1]->children[0]->label);
        rootTable->addChild(child);
        createSymbolTable(root->children[0], rootTable);
        createSymbolTable(root->children[1], child);
    }
    // METHOD_HEADER: MODIFIERS TYPE METHOD_DECLARATOR THROWS
    else if(root->id == 123){
        root->children[2]->datatype = getType(root->children[1]);
        root->children[2]->dims = getDimsCount(root->children[1]);
        createSymbolTable(root->children[2], rootTable);
    }
    // METHOD_HEADER: MODIFIERS TYPE METHOD_DECLARATOR
    else if(root->id == 124){
        root->children[2]->datatype = getType(root->children[1]);
        root->children[2]->dims = getDimsCount(root->children[1]);
        createSymbolTable(root->children[2], rootTable);
    }
    // METHOD_HEADER: TYPE METHOD_DECLARATOR THROWS
    else if(root->id == 125){
        root->children[1]->datatype = getType(root->children[0]);
        root->children[1]->dims = getDimsCount(root->children[0]);
        createSymbolTable(root->children[1], rootTable);
    }
    // METHOD_HEADER: TYPE METHOD_DECLARATOR
    else if(root->id == 126){
        root->children[1]->datatype = getType(root->children[0]);
        root->children[1]->dims = getDimsCount(root->children[0]);
        createSymbolTable(root->children[1], rootTable);
    }
    // METHOD_HEADER: MODIFIERS VOID METHOD_DECLARATOR THROWS
    else if(root->id == 127){
        root->children[2]->datatype = "void";
        createSymbolTable(root->children[2], rootTable);
    }
    // METHOD_HEADER: MODIFIERS VOID METHOD_DECLARATOR
    else if(root->id == 129){
        root->children[2]->datatype = "void";
        createSymbolTable(root->children[2], rootTable);
    }
    // METHOD_HEADER: VOID METHOD_DECLARATOR THROWS
    else if(root->id == 131){
        root->children[1]->datatype = "void";
        createSymbolTable(root->children[1], rootTable);
    }
    // METHOD_HEADER: VOID METHOD_DECLARATOR
    else if(root->id == 133){
        root->children[1]->datatype = "void";
        createSymbolTable(root->children[1], rootTable);
    }
    // METHOD_DECLARATOR: IDENTIFIER LPAREN FORMAL_PARAMETER_LIST RPAREN
    else if(root->id == 135){
        root->children[0]->datatype = root->datatype;
        root->children[0]->dims = root->dims;
        root->children[0]->is_variable = false;
        createSymbolTable(root->children[0], rootTable);
        SymbolTable *child;
        for (auto u: rootTable->children){
            if(u->name == root->children[0]->label){
                child = u;
                break;
            }
        }
        createSymbolTable(root->children[2], child);
    }
    // METHOD_DECLARATOR: IDENTIFIER LPAREN RPAREN
    else if(root->id == 139){
        root->children[0]->datatype = root->datatype;
        root->children[0]->dims = root->dims;
        root->children[0]->is_variable = false;
        createSymbolTable(root->children[0], rootTable);
    }
    // METHOD_DECLARATOR: IDENTIFIER LBRACKET RBRACKET LPAREN FORMAL_PARAMETER_LIST RPAREN
    else if(root->id == 557){
        root->children[0]->datatype = root->datatype;
        root->children[0]->dims = root->dims + 1;
        root->children[0]->is_variable = false;
        createSymbolTable(root->children[0], rootTable);
        SymbolTable *child;
        for (auto u: rootTable->children){
            if(u->name == root->children[0]->label){
                child = u;
                break;
            }
        }
        createSymbolTable(root->children[4], child);
    }
    // METHOD_DECLARATOR: IDENTIFIER LBRACKET RBRACKET LPAREN RPAREN
    else if(root->id == 563){
        root->children[0]->datatype = root->datatype;
        root->children[0]->dims = root->dims + 1;
        root->children[0]->is_variable = false;
        createSymbolTable(root->children[0], rootTable);
    }
    // IDENTIFIER
    else if(root->id == 136 || root->id == 140 || root->id == 558 || root->id == 564){
        SymbolTableEntry *child = new SymbolTableEntry(root->label, root->datatype, root->lineno, false, root->dims);
        rootTable->addEntry(child);
    }
    // FORMAL_PARAMETER_LIST: FORMAL_PARAMETERS
    else if(root->id == 146){
        createSymbolTable(root->children[0], rootTable);
    }
    // FORMAL_PARAMETER_LIST: FORMAL_PARAMETER_LIST COMMA FORMAL_PARAMETERS
    else if(root->id == 147){
        createSymbolTable(root->children[0], rootTable);
        createSymbolTable(root->children[2], rootTable);
    }
    // FORMAL_PARAMETER: TYPE VARIABLE_DECLARATOR_ID
    else if(root->id == 149){
        root->children[1]->datatype = getType(root->children[0]);
        root->children[1]->is_function_param = true;
        root->children[1]->dims = getDimsCount(root->children[0]);
        createSymbolTable(root->children[1], rootTable);
    }
    // METHOD_BODY: BLOCK
    else if(root->id == 150){
        createSymbolTable(root->children[0], rootTable);
    }
    // BLOCK: LBRACE BLOCK_STATEMENTS RBRACE
    else if(root->id == 241){
        createSymbolTable(root->children[1], rootTable);
    }
    // BLOCK: LBRACE RBRACE
    else if(root->id == 244){
        return;
    }
    else if(root->id == 288){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_if" + to_string(if_count));
        rootTable->addChild(child);
        if_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[4], child);
    }
    // IF_THEN_ELSE_STATEMENT: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT
    else if(root->id == 292){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_if" + to_string(if_count));
        rootTable->addChild(child);
        if_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[4], child);
        createSymbolTable(root->children[6], child);
    }
    // IF_THEN_ELSE_STATEMENT_NO_SHORT_IF: IF LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF ELSE STATEMENT_NO_SHORT_IF
    else if(root->id == 297){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_if" + to_string(if_count));
        rootTable->addChild(child);
        if_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[4], child);
        createSymbolTable(root->children[6], child);
    }
    // WHILE_STATEMENT: WHILE LPAREN EXPRESSION RPAREN STATEMENT
    else if(root->id == 301){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_while" + to_string(while_count));
        rootTable->addChild(child);
        while_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[4], child);
    }
    // WHILE_STATEMENT_NO_SHORT_IF: WHILE LPAREN EXPRESSION RPAREN STATEMENT_NO_SHORT_IF
    else if(root->id == 305){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_while" + to_string(while_count));
        rootTable->addChild(child);
        while_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[4], child);
    }
    // FOR_STATEMENT: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT
    else if(root->id == 316){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_for" + to_string(for_count));
        rootTable->addChild(child);
        for_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[4], child);
        createSymbolTable(root->children[6], child);
        createSymbolTable(root->children[8], child);
    }
    // FOR_STATEMENT: FOR LPAREN FOR_INIT_OPT SEMICOLON SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT
    else if(root->id == 322){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_for" + to_string(for_count));
        rootTable->addChild(child);
        for_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[5], child);
        createSymbolTable(root->children[7], child);
    }
    // FOR_STATEMENT_NO_SHORT_IF: FOR LPAREN FOR_INIT_OPT SEMICOLON EXPRESSION SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT_NO_SHORT_IF
    else if(root->id == 328){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_for" + to_string(for_count));
        rootTable->addChild(child);
        for_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[4], child);
        createSymbolTable(root->children[6], child);
        createSymbolTable(root->children[8], child);
    }
    // FOR_STATEMENT_NO_SHORT_IF: FOR LPAREN FOR_INIT_OPT SEMICOLON  SEMICOLON FOR_UPDATE_OPT RPAREN STATEMENT_NO_SHORT_IF
    else if(root->id == 334){
        SymbolTable *child = new SymbolTable (rootTable, rootTable->name + "_for" + to_string(for_count));
        rootTable->addChild(child);
        for_count++;
        createSymbolTable(root->children[2], child);
        createSymbolTable(root->children[5], child);
        createSymbolTable(root->children[7], child);
    }
    // LOCAL_VARIABLE_DECLARATION: TYPE VARIABLE_DECLARATORS
    else if(root->id == 253){
        root->children[1]->datatype = getType(root->children[0]);
        root->children[1]->dims = getDimsCount(root->children[0]);
        createSymbolTable(root->children[1], rootTable);
    }
    else
    {
        for (auto u : root->children)
        {
            createSymbolTable(u, rootTable);
        }
    }
    return;
}
