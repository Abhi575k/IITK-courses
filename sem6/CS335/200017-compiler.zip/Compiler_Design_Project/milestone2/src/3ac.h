#ifndef _3AC_H
#define _3AC_H

#include <bits/stdc++.h>
#include "typecheck.h"

using namespace std;

class threeAC{
public:
    string op;
    string arg1;
    string arg2;
    string result;
    int lineno;

    vector<threeAC *> threeACList;

    threeAC();
    void print();
};

void create3AC(ast *root, threeAC *tac);

#endif