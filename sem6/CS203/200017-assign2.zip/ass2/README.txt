Usage:
    python3 1.py <n_samples> <n_experiments>
