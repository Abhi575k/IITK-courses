import numpy as np
import matplotlib.pyplot as plt
import sys

n = len(sys.argv)

if n != 3:
    print("Usage: python3 1.py <n_samples> <n_experiments>")
    exit()

# Define the random variable X with range having 5 elements and their probabilities
elements = np.array([1, 2, 3, 4, 5])
probabilities = np.array([0.1, 0.2, 0.4, 0.2, 0.1])  # Probabilities as multiples of 1/1000

# Function to generate random samples from X
def generate_samples(n):
    return np.random.choice(elements, size=n, replace=True, p=probabilities)

def exp_and_plot(n_samples, n_experiments, bin_cnt):
    # Array to store sample means for each experiment
    sample_means = np.zeros(n_experiments)
    # Perform experiments
    for i in range(n_experiments):
        samples = generate_samples(n_samples)
        sample_means[i] = np.mean(samples)

    # Plot the sample means
    plt.hist(sample_means, bins=bin_cnt, density=True, alpha=0.1)
    plt.xlabel('Sample Mean')
    plt.ylabel('Density')
    plt.title('Sample Means from Random Variable X')
    plt.show()

# Number of samples to draw for each experiment
n_samples = int(sys.argv[1])

# Number of experiments to perform
n_experiments = int(sys.argv[2])

exp_and_plot(n_samples, n_experiments, 100)