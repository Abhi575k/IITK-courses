#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

#define LEN 1024

using namespace std;

int main(int argc, char *argv[]) {

	int port = 8080;
    string ip = "127.0.0.1";

    for (int i=1; i<argc; i++) {
        if(!strcmp(argv[i], "-p")){
            port = atoi(argv[i+1]);
            i++;
        }else if(!strcmp(argv[i], "-i")){
            ip = argv[i+1];
            i++;
        }else{
            cout << "Usage: " << argv[0] << " -p <port> -i <ip>\n";
            return 0;
        }
    }

	// socket file descriptor
	int sockfd;
	struct sockaddr_in servaddr, cliaddr;
	
	// AF_INET = IPv4
    // SOCK_DGRAM = UDP
    // 0 = default protocol
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	
	servaddr.sin_family = AF_INET;

    // server port
	servaddr.sin_port = htons(port);

    // server IP address
	inet_aton(ip.c_str(), &servaddr.sin_addr);
	
	// Bind the socket with the server address
	bind(sockfd,(const struct sockaddr *)&servaddr,sizeof(servaddr));
	
	socklen_t len;

	while(1){
        char sendbuf[LEN], recvbuf[LEN];

		recvfrom(sockfd,
            (char *)recvbuf,
            LEN,
            MSG_WAITALL,
            (struct sockaddr *) &cliaddr,
            &len
        );

		cout << "Client: " << recvbuf << "\n";

		if(recvbuf[0]=='!'){
			cout << "Connection closed from client side\n";
			cout << "Continue? (y/n): ";

			char ch;
			cin >> ch;

			if(ch=='n')
				break;
			else 
				continue;
		}

		string temp;

        cout << "Enter message: ";
        cin >> temp;

		strcpy(sendbuf, temp.c_str());

        sendto(sockfd,
            (const char *)sendbuf,
            LEN,
            MSG_CONFIRM,
            (const struct sockaddr *) &cliaddr,
            sizeof(cliaddr)
        );
        
        if(sendbuf[0]=='!')
            break;
        
    }

	close(sockfd);
	
	return 0;
}
