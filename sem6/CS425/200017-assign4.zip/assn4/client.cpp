#include <bits/stdc++.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

#define LEN 1024

using namespace std;

int main(int argc, char *argv[]) {

    int port = 8080;
    string ip = "127.0.0.1";

    for (int i=1; i<argc; i++) {
        if(!strcmp(argv[i], "-p")){
            port = atoi(argv[i+1]);
            i++;
        }else if(!strcmp(argv[i], "-i")){
            ip = argv[i+1];
            i++;
        }else{
            cout << "Usage: " << argv[0] << " -p <port> -i <ip>\n";
            return 0;
        }
    }

    // socket file descriptor
	int sockfd;
	struct sockaddr_in servaddr;

    // AF_INET = IPv4
    // SOCK_DGRAM = UDP
    // 0 = default protocol
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);

	servaddr.sin_family = AF_INET;

    // server port
	servaddr.sin_port = htons(port);

    // server IP address
	inet_aton(ip.c_str(), &servaddr.sin_addr);
	
	socklen_t len;

    while(1){
        char sendbuf[LEN], recvbuf[LEN];

        string temp;

        cout << "Enter message: ";
        cin >> temp;

        strcpy(sendbuf, temp.c_str());

        sendto(sockfd,
            (const char *)sendbuf,
            LEN,
            MSG_CONFIRM,
            (const struct sockaddr *) &servaddr,
            sizeof(servaddr)
        );

        if(sendbuf[0]=='!'||recvbuf[0]=='!')
            break;

        recvfrom(sockfd,
            (char *)recvbuf,
            LEN,
            MSG_WAITALL,
            (struct sockaddr *) &servaddr,
            &len
        );
        
        if(sendbuf[0]=='!'||recvbuf[0]=='!')
            break;
        
        cout << "Server: " << recvbuf << "\n";
    }

	close(sockfd);
	return 0;
}
