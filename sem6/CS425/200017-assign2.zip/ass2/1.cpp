#include <bits/stdc++.h>

using namespace std;


string generateMessage(int);
string findRemainder(string, string);
string appendZeros(string, int);
void printAll(string, string, string);
string createError(string);
bool isDivisible(string, string);

int main(){
    //  D = message, P = generator polynomial, T = transmitted message
    string D, P, T;

    //  Generate a random message   (a)
    D = generateMessage(10);

    //  Generator polynomial as given in question
    P = "110101";

    int P_len = P.length();

    //  Find the CRC
    string CRC = findRemainder(appendZeros(D, P_len - 1), P);

    //  Generate the 15-bit transmitted message
    T = D + CRC;

    printAll(D, P, T);

    //  Create a random error in the transmitted message
    T = createError(T);

    cout << "After error! \nReceived Message: " << T <<"\n";

    if(isDivisible(T, P)){
        cout << "No error detected\n";
    }
    else{
        cout << "Error detected\n";
    }

    return 0;
}

string generateMessage(int n){
    string D = "";
    for(int i = 0; i < n; i++){
        int x = rand() % 2;
        D += (x + '0');
    }
    return D;
}

string findRemainder(string M, string P){
    int M_len = M.length(), P_len = P.length();
    string temp = M.substr(0, P_len);
    int i = 0;
    while(i < M_len - P_len + 1){
        if(temp[0] == '1'){
            for(int j = 1; j < P_len; j++){
                if(temp[j] == P[j]){
                    temp[j - 1] = '0';
                }
                else{
                    temp[j - 1] = '1';
                }
            }
        }
        else{
            for(int j = 1; j < P_len; j++){
                temp[j - 1] = temp[j];
            }
        }
        temp[P_len - 1] = M[i + P_len];
        i++;
    }
    return temp;
}

string appendZeros(string D, int n){
    for(int i = 0; i < n; i++){
        D += '0';
    }
    return D;
}

void printAll(string D, string P, string T){
    cout << "Message: " << D << '\n';
    cout << "Generator polynomial: " << P << '\n';
    cout << "Transmitted message: " << T << '\n';
}

string createError(string D){
    int n = D.length();
    int x = rand() % n;
    if(D[x] == '0'){
        D[x] = '1';
    }else{
        D[x] = '0';
    }
    int y = rand() % 2;
    if(y == 1) return createError(D);
    else return D;
}

bool isDivisible(string T, string P){
    int T_len = T.length(), P_len = P.length();
    string temp = T.substr(0, P_len);
    int i = 0;
    while(i < T_len - P_len + 1){
        if(temp[0] == '1'){
            for(int j = 1; j < P_len; j++){
                if(temp[j] == P[j]){
                    temp[j - 1] = '0';
                }
                else{
                    temp[j - 1] = '1';
                }
            }
        }
        else{
            for(int j = 1; j < P_len; j++){
                temp[j - 1] = temp[j];
            }
        }
        temp[P_len - 1] = T[i + P_len];
        i++;
    }
    for(int i = 0; i < P_len - 1; i++){
        if(temp[i] == '1') return false;
    }
    return true;
}