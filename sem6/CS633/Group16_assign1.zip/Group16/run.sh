#!/bin/bash

mpicxx code.cpp -o binary

host1="csews8"
host2="csews9"
host3="csews10"

echo "hosts,elements,1,2,3,4,5,6,7,8,9,10"

for i in 256 25600 262144 2097152 8388608 16777216 33554432
do
    echo -n "$host1-$host2,$i,"
    for j in seq {1..9}
    do
        mpirun -np 2 -hosts $host1,$host2 ./binary $i
        if (( $j < 9 ));
        then
            echo -n ","
        fi
    done
    echo ""
done

for i in 256 25600 262144 2097152 8388608 16777216 33554432
do
    echo -n "$host2-$host3,$i,"
    for j in seq {1..9}
    do
        mpirun -np 2 -hosts $host2,$host3 ./binary $i
        if (( $j < 9 ));
        then
            echo -n ","
        fi
    done
    echo ""
done

for i in 256 25600 262144 2097152 8388608 16777216 33554432
do
    echo -n "$host3-$host1,$i,"
    for j in seq {1..9}
    do
        mpirun -np 2 -hosts $host3,$host1 ./binary $i
        if (( $j < 9 ));
        then
            echo -n ","
        fi
    done
    echo ""
done

rm binary
