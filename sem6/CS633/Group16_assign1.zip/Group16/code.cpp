#include<bits/stdc++.h>
#include "mpi.h"

using namespace std;

int main(int argc, char *argv[]){
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int msg_size=stoi(argv[1]);
    int *msg=new int[msg_size];
    for(int i=0;i<msg_size;i++){
        msg[i]=i;
    }

    double start=MPI_Wtime();

    if(rank==0){
        MPI_Send(msg, msg_size, MPI_INT, 1, 0, MPI_COMM_WORLD);
    }else if(rank==1){
        MPI_Recv(msg, msg_size, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }else{
        cout<<"Invalid rank\n";
    }

    double mxtime,end=MPI_Wtime();
    double time=end-start;
    MPI_Reduce(&time, &mxtime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    if(!rank) cout<<fixed<<setprecision(9)<<mxtime;

    delete[] msg;
    MPI_Finalize();
    return 0;
}